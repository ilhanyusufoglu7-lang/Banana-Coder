from __future__ import annotations

import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-gui-test-home-"))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication, QDialog, QPushButton

    QT_AVAILABLE = True
except Exception:  # pragma: no cover - PyQt5 opsiyonel
    QT_AVAILABLE = False

from banana import preview
from banana.cli import _handle_slash, _launch_gui, build_parser, main
from banana.config import Config
from tests.mock_api import MockAPI


class FakeUI:
    def __init__(self) -> None:
        self.infos: list[str] = []
        self.errors: list[str] = []

    def info(self, message: str) -> None:
        self.infos.append(message)

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.errors.append(message)


def _pump(*, seconds: float = 0.0, until=None, timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + (timeout if until is not None else seconds)
    while time.monotonic() < deadline:
        if QT_AVAILABLE:
            app = QApplication.instance()
            if app is not None:
                app.processEvents()
        if until is not None and until():
            return True
        time.sleep(0.01)
    return until() if until is not None else True


class GuiCommandTests(unittest.TestCase):
    def _runtime(self, cwd: Path) -> SimpleNamespace:
        return SimpleNamespace(
            ui=FakeUI(),
            provider_name="openai",
            model="test-model",
            config=SimpleNamespace(local_model_path=None, show_reasoning=False),
            approver=SimpleNamespace(mode="ask"),
            agent=SimpleNamespace(ctx=SimpleNamespace(cwd=cwd)),
        )

    def test_parser_accepts_gui_flag(self) -> None:
        args = build_parser().parse_args(["--gui"])
        self.assertTrue(args.gui)

    def test_launch_gui_builds_detached_command(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            runtime = self._runtime(cwd)
            with mock.patch.dict(os.environ, {}, clear=False):
                os.environ.pop("BANANA_GUI", None)
                with mock.patch("banana.cli.subprocess.Popen") as popen:
                    popen.return_value.pid = 4242
                    _launch_gui(runtime)
            popen.assert_called_once()
            command = popen.call_args.args[0]
            self.assertEqual(command[:4], [sys.executable, "-m", "banana", "--gui"])
            self.assertEqual(command[command.index("-C") + 1], str(cwd.resolve()))
            model_flag = command.index("-C") + 2
            self.assertEqual(command[model_flag], "-m")
            self.assertEqual(command[model_flag + 1], "openai/test-model")
            self.assertIn("--ask", command)
            self.assertEqual(popen.call_args.kwargs["cwd"], str(cwd.resolve()))
            self.assertTrue(popen.call_args.kwargs["start_new_session"])
            self.assertIn("pid 4242", runtime.ui.infos[-1])

    def test_launch_gui_is_blocked_inside_gui(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            runtime = self._runtime(Path(raw))
            with mock.patch.dict(os.environ, {"BANANA_GUI": "1"}):
                with mock.patch("banana.cli.subprocess.Popen") as popen:
                    _launch_gui(runtime)
            popen.assert_not_called()
            self.assertIn("zaten acik", runtime.ui.infos[-1])

    def test_slash_gui_dispatches_with_argument(self) -> None:
        runtime = SimpleNamespace(ui=FakeUI())
        with mock.patch("banana.cli._launch_gui") as launch:
            result = _handle_slash(runtime, "/gui src")
        self.assertIsNone(result)
        launch.assert_called_once_with(runtime, "src")

    def test_main_routes_gui_flag(self) -> None:
        saved = os.environ.get("BANANA_GUI")
        old_cwd = Path.cwd()
        try:
            with tempfile.TemporaryDirectory() as raw:
                cwd = Path(raw)
                with mock.patch("banana.gui.run_gui", return_value=0) as run:
                    with self.assertRaises(SystemExit) as caught:
                        main(
                            [
                                "--gui",
                                "-C",
                                str(cwd),
                                "-m",
                                "openai/test-model",
                                "--yolo",
                            ]
                        )
                self.assertEqual(caught.exception.code, 0)
                run.assert_called_once()
                args = run.call_args.args[0]
                self.assertTrue(args.gui)
                self.assertEqual(args.workdir, str(cwd))
        finally:
            os.chdir(old_cwd)
            if saved is None:
                os.environ.pop("BANANA_GUI", None)
            else:
                os.environ["BANANA_GUI"] = saved

    def test_gui_with_prompt_is_rejected(self) -> None:
        old_cwd = Path.cwd()
        try:
            with tempfile.TemporaryDirectory() as raw:
                with self.assertRaises(SystemExit) as caught:
                    main(["--gui", "-p", "merhaba", "-C", raw])
                self.assertEqual(caught.exception.code, 2)
        finally:
            os.chdir(old_cwd)


class MarkdownTests(unittest.TestCase):
    def test_html_is_escaped_and_markdown_rendered(self) -> None:
        from banana.gui import render_markdown

        rendered = render_markdown(
            "<script>alert(1)</script> **kalin** ve `kod`"
        )
        self.assertNotIn("<script>", rendered)
        self.assertIn("&lt;script&gt;", rendered)
        self.assertIn("font-weight:600", rendered)
        self.assertIn("kalin", rendered)
        self.assertIn("kod", rendered)

    def test_fenced_code_block_is_preserved(self) -> None:
        from banana.gui import render_markdown

        rendered = render_markdown("```python\nprint('x')\n```")
        self.assertIn("print", rendered)
        self.assertIn("'x'", rendered)
        self.assertIn("font-family", rendered)


class GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if not QT_AVAILABLE:
            raise unittest.SkipTest("PyQt5 yok")
        from banana.gui import _configure_application

        cls.mock = MockAPI().start()
        cls.qapp = QApplication.instance() or QApplication([sys.argv[0]])
        _configure_application(cls.qapp)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.mock.stop()

    def _make_app(self, cwd: Path, home: Path):
        try:
            from banana.gui import GuiApp
        except Exception as exc:  # pragma: no cover - PyQt5 yoksa
            raise unittest.SkipTest(f"PyQt5 yok: {exc}")

        config = Config.load(home / "config.json")
        config.set_api_key("openai", "test-openai")
        config.model = "openai/test-model"
        config.base_urls["openai"] = f"http://127.0.0.1:{self.mock.port}/v1"
        config.save()
        preview.init(config.config_path, enabled=False)

        args = build_parser().parse_args(
            ["--gui", "-C", str(cwd), "-m", "openai/test-model", "--yolo"]
        )
        try:
            app = GuiApp(args, config, cwd)
        except Exception as exc:  # pragma: no cover - gorunum yoksa
            raise unittest.SkipTest(f"Qt penceresi acilamadi: {exc}")

        def cleanup() -> None:
            try:
                app._on_close(force=True)
            except Exception:
                pass
            self.qapp.processEvents()

        self.addCleanup(cleanup)
        return app

    def test_boot_and_chat_roundtrip(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            (cwd / "sample.txt").write_text(
                "BANANA_FILE_CONTENT\n", encoding="utf-8"
            )
            app = self._make_app(cwd, home)

            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10),
                "runtime hazirlanamadi",
            )
            self.assertIn("openai/test-model", app.model_chip.text())
            self.assertIn("sample.txt", _tree_names(app.tree))

            app.input.setPlainText("sample.txt dosyasini oku")
            app.send()
            self.assertTrue(
                _pump(until=lambda: not app.busy, timeout=25),
                "yanit tamamlanmadi",
            )
            _pump(seconds=0.1)
            body = app.chat_view.to_plain_text()
            self.assertIn("BANANA_FILE_CONTENT", body)
            self.assertIn("read_file", body)
            self.assertIn("test-model", app.chat_model_label.text())

    def test_editor_open_edit_save_and_line_numbers(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            target = cwd / "demo.py"
            target.write_text("def selam():\n    print('hi')\n", encoding="utf-8")
            app = self._make_app(cwd, home)

            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            app.open_file(target)
            _pump(seconds=0.2)
            tab = app.current_tab()
            self.assertIsNotNone(tab)
            self.assertIn("def selam", tab.editor.toPlainText())
            self.assertGreaterEqual(tab.editor.blockCount(), 3)
            self.assertGreater(tab.editor.line_number_area_width(), 20)
            self.assertIn("demo.py", _tree_names(app.tree))

            from PyQt5.QtGui import QTextCursor

            tab.editor.moveCursor(QTextCursor.End)
            tab.editor.insertPlainText("# yeni satir\n")
            _pump(seconds=0.1)
            self.assertTrue(tab.modified)
            index = app.tabs.indexOf(tab)
            self.assertTrue(app.tabs.tabText(index).startswith("*"))
            self.assertTrue(tab.save())
            self.assertFalse(tab.modified)
            self.assertIn("# yeni satir", target.read_text(encoding="utf-8"))

            app.close_current()
            self.assertIsNone(app.current_tab())

    def test_theme_accent_and_command_palette(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            from banana import gui as gui_module

            app.set_accent("mint")
            self.assertEqual(gui_module.ACCENT, "#4fd1a5")
            self.assertIn("4fd1a5", self.qapp.styleSheet())
            self.assertEqual(gui_module.prefs().value("theme/accent"), "mint")

            app.open_palette()
            _pump(seconds=0.1)
            self.assertFalse(app._palette.isHidden())
            self.assertGreater(app._palette.list.count(), 0)
            app._palette.input.setText("nane")
            _pump(seconds=0.05)
            self.assertEqual(app._palette.count_label.text(), "1 sonuc")
            app._palette._run_current()
            _pump(seconds=0.1)
            self.assertTrue(app._palette.isHidden())
            self.assertEqual(gui_module.ACCENT, "#4fd1a5")

            app.set_accent("banana")
            self.assertEqual(gui_module.ACCENT, "#f5c542")

    def test_settings_dialog_controls_runtime(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            app.open_settings()
            _pump(seconds=0.1)
            settings = app._settings
            self.assertFalse(settings.isHidden())
            self.assertEqual(settings.nav.count(), 3)

            settings.nav.setCurrentRow(1)
            _pump(seconds=0.05)
            settings.approval_combo.setCurrentText("readonly")
            _pump(seconds=0.1)
            self.assertEqual(app.runtime.approver.mode, "readonly")

            settings.tools_check.setChecked(False)
            _pump(seconds=0.1)
            self.assertFalse(app.runtime.agent.tools_enabled)
            settings.tools_check.setChecked(True)
            _pump(seconds=0.1)
            self.assertTrue(app.runtime.agent.tools_enabled)

    def test_sidebar_toggle_mode_chip_and_toast(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            self.assertTrue(app._sidebar_visible)
            app.toggle_sidebar()
            _pump(seconds=0.1)
            self.assertFalse(app._sidebar_visible)
            self.assertFalse(app._sidebar_btn.property("active"))
            app.toggle_sidebar()
            _pump(seconds=0.1)
            self.assertTrue(app._sidebar_visible)
            self.assertTrue(app._sidebar_btn.property("active"))

            app.input.setPlainText("/help")
            _pump(seconds=0.05)
            self.assertEqual(app.mode_chip.text(), "komut")
            app.input.setPlainText("!ls")
            _pump(seconds=0.05)
            self.assertEqual(app.mode_chip.text(), "kabuk")
            app.input.clear()
            _pump(seconds=0.05)
            self.assertEqual(app.mode_chip.text(), "sohbet")

            app.show_toast("Deneme bildirimi", "ok")
            _pump(seconds=0.1)
            self.assertTrue(app._toast._open)
            self.assertEqual(app._toast.label.text(), "Deneme bildirimi")
            app._toast.dismiss()
            _pump(seconds=0.01)
            self.assertFalse(app._toast._open)

    def test_clear_chat_resets_messages(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            app.chat_view.add_user("ilk mesaj")
            self.assertIn("ilk mesaj", app.chat_view.to_plain_text())
            app.clear_chat()
            _pump(seconds=0.05)
            self.assertEqual(app.chat_view.to_plain_text(), "")
            self.assertFalse(app.chat_welcome.isHidden())

    def test_approval_dialog_returns_yes(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )

            answers: list[bool] = []

            def worker() -> None:
                from banana.approval import Approver

                answers.append(
                    Approver(app.ui, "ask").allow("Dosya yaz", "out.txt: merhaba")
                )

            def click_yes() -> bool:
                for window in QApplication.topLevelWidgets():
                    if not isinstance(window, QDialog):
                        continue
                    for button in window.findChildren(QPushButton):
                        if button.text() == "Evet":
                            button.click()
                            return True
                QTimer.singleShot(50, click_yes)
                return False

            threading.Thread(target=worker, daemon=True).start()
            QTimer.singleShot(100, click_yes)
            self.assertTrue(
                _pump(until=lambda: len(answers) == 1, timeout=8),
                "onay penceresi yanitlanmadi",
            )
            self.assertEqual(answers, [True])
            body = app.chat_view.to_plain_text()
            self.assertIn("out.txt: merhaba", body)

    def test_slash_commands_run_inside_gui(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            base = Path(raw)
            cwd = base / "cwd"
            home = base / "home"
            cwd.mkdir()
            home.mkdir()
            app = self._make_app(cwd, home)
            self.assertTrue(
                _pump(until=lambda: app.runtime is not None, timeout=10)
            )
            self.assertIn("/gui", _help_text(app))
            app.input.setPlainText("/tools off")
            app.send()
            self.assertTrue(_pump(until=lambda: not app.busy, timeout=8))
            _pump(seconds=0.1)
            self.assertFalse(app.runtime.agent.tools_enabled)
            self.assertFalse(app.tools_check.isChecked())
            self.assertIn("Araclar kapali", app.chat_view.to_plain_text())


def _tree_names(tree):
    return [
        tree.topLevelItem(index).text(0)
        for index in range(tree.topLevelItemCount())
    ]


def _help_text(app) -> str:
    app.input.setPlainText("/help")
    app.send()
    _pump(until=lambda: not app.busy, timeout=10)
    _pump(seconds=0.1)
    return app.chat_view.to_plain_text()


if __name__ == "__main__":
    unittest.main()
