from __future__ import annotations

import os
import tempfile
import threading
import unittest
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.hf import download_gguf, filename_from_url
from banana.net import ProviderError

PAYLOAD = b"GGUF" + b"x" * 4096


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        if self.path.endswith("/missing.gguf"):
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("content-length", str(len(PAYLOAD)))
        self.end_headers()
        self.wfile.write(PAYLOAD)

    def log_message(self, *args) -> None:
        pass


class DownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()

    def test_filename_from_url(self) -> None:
        self.assertEqual(
            filename_from_url("https://huggingface.co/x/y/resolve/main/model.gguf"),
            "model.gguf",
        )
        self.assertEqual(
            filename_from_url("https://x/model.gguf?download=true"), "model.gguf"
        )
        with self.assertRaises(ProviderError):
            filename_from_url("https://x/dir/")

    def test_filename_blocks_traversal(self) -> None:
        self.assertEqual(
            filename_from_url("https://x/../../etc/passwd.gguf"), "passwd.gguf"
        )

    def test_download_writes_file_and_reports_progress(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            dest_dir = Path(raw)
            seen: list[tuple[int, int]] = []
            dest = download_gguf(
                f"{self.base}/qwen.gguf", dest_dir, lambda d, t: seen.append((d, t))
            )
            self.assertEqual(dest.name, "qwen.gguf")
            self.assertEqual(dest.read_bytes(), PAYLOAD)
            self.assertTrue(seen)
            self.assertEqual(seen[-1][0], len(PAYLOAD))
            self.assertFalse(list(dest_dir.glob("*.part")))

    def test_existing_file_skips_download(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            dest_dir = Path(raw)
            (dest_dir / "a.gguf").write_bytes(b"OLD")
            dest = download_gguf(f"{self.base}/a.gguf", dest_dir)
            self.assertEqual(dest.read_bytes(), b"OLD")

    def test_http_error_raises(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            with self.assertRaises(ProviderError):
                download_gguf(f"{self.base}/missing.gguf", Path(raw))


if __name__ == "__main__":
    unittest.main()
