from __future__ import annotations

import os
import unittest
from pathlib import Path

from banana import booster
from banana.booster import BOOST_SYSTEM, boost_available, upgrade_prompt
from banana.config import Config
from banana.models import Message
from banana.net import ProviderError

API_KEY_VARS = (
    "OPENROUTER_API_KEY",
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
)


def _config(**kwargs) -> Config:
    cfg = Config.load(Path("/nonexistent-banana/config.json"))
    for key, value in kwargs.items():
        setattr(cfg, key, value)
    return cfg


class FakeBoostProvider:
    def __init__(self, content: str = "", error: bool = False) -> None:
        self.content = content
        self.error = error
        self.closed = False
        self.calls: list[dict] = []

    def complete(self, **kwargs):
        self.calls.append(kwargs)
        if self.error:
            raise ProviderError("boost servisi cevap vermedi")
        return Message(role="assistant", content=self.content), None, "stop", "fake"

    def close(self) -> None:
        self.closed = True


class UpgradePromptTests(unittest.TestCase):
    def setUp(self) -> None:
        for var in API_KEY_VARS:
            os.environ.pop(var, None)
        self.original = booster.create_provider

    def tearDown(self) -> None:
        booster.create_provider = self.original

    def test_disabled_returns_raw(self) -> None:
        cfg = _config(boost_enabled=False, boost_model="or-free")
        self.assertEqual(upgrade_prompt(cfg, "  kisa prompt  "), "kisa prompt")

    def test_missing_key_falls_back(self) -> None:
        cfg = _config(boost_enabled=True, boost_model="gpt")
        self.assertEqual(upgrade_prompt(cfg, "bir sey yap"), "bir sey yap")

    def test_provider_error_falls_back(self) -> None:
        cfg = _config(boost_enabled=True, boost_model="or-free")
        fake = FakeBoostProvider(error=True)
        booster.create_provider = lambda *a, **k: fake
        self.assertEqual(upgrade_prompt(cfg, "ham metin"), "ham metin")
        self.assertTrue(fake.closed)

    def test_empty_or_tiny_output_falls_back(self) -> None:
        cfg = _config(boost_enabled=True, boost_model="or-free")
        for content in ("", "  ", "ab"):
            booster.create_provider = lambda *a, c=content, **k: FakeBoostProvider(content=c)
            self.assertEqual(upgrade_prompt(cfg, "ham metin"), "ham metin")

    def test_upgraded_prompt_used(self) -> None:
        cfg = _config(boost_enabled=True, boost_model="or-free")
        fake = FakeBoostProvider(content="  GELISTIRILMIS PROMPT  ")
        booster.create_provider = lambda *a, **k: fake
        result = upgrade_prompt(cfg, "kisa istek")
        self.assertEqual(result, "GELISTIRILMIS PROMPT")
        call = fake.calls[0]
        self.assertEqual(call["system"], BOOST_SYSTEM)
        self.assertEqual(call["messages"][0].content, "kisa istek")
        self.assertEqual(call["temperature"], 0.3)
        self.assertTrue(fake.closed)


class BoostAvailableTests(unittest.TestCase):
    def setUp(self) -> None:
        for var in API_KEY_VARS:
            os.environ.pop(var, None)

    def tearDown(self) -> None:
        for var in API_KEY_VARS:
            os.environ.pop(var, None)

    def test_off_by_default(self) -> None:
        cfg = _config(boost_enabled=False, boost_model="or-free")
        self.assertFalse(boost_available(cfg))

    def test_needs_key_for_remote_model(self) -> None:
        cfg = _config(boost_enabled=True, boost_model="gpt")
        self.assertFalse(boost_available(cfg))
        os.environ["OPENAI_API_KEY"] = "sk-x"
        self.assertTrue(boost_available(cfg))


if __name__ == "__main__":
    unittest.main()
