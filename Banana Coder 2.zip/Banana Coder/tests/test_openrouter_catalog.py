from __future__ import annotations

import io
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.agent import Agent, build_system_prompt
from banana.approval import Approver
from banana.cli import (
    _filter_catalog,
    _remote_model_picker,
    _remote_row,
    _tool_support,
)
from banana.config import Config
from banana.models import Message, StreamDone, TextDelta, Usage
from banana.session import Session
from banana.ui import UI

CATALOG = [
    {
        "id": "openai/gpt-4o",
        "name": "GPT-4o",
        "context_length": 128000,
        "pricing": {"prompt": "0.0000025", "completion": "0.00001"},
        "supported_parameters": ["tools", "temperature"],
    },
    {
        "id": "meta-llama/llama-3-8b-instruct",
        "name": "Llama 3 8B Instruct",
        "context_length": 8192,
        "pricing": {"prompt": "0", "completion": "0"},
        "supported_parameters": ["temperature"],
    },
    {
        "id": "mistralai/mistral-small",
        "name": "Mistral Small",
        "context_length": 32000,
        "pricing": {"prompt": "0.000001", "completion": "0.000003"},
        "supported_parameters": ["tools"],
    },
]


class FakePickerUI:
    interactive = True

    def __init__(self, answers: list[str]) -> None:
        self.answers = list(answers)
        self.tables: list[tuple[tuple[str, ...], list[tuple[str, ...]]]] = []
        self.messages: list[str] = []
        self.warnings: list[str] = []
        self.errors: list[str] = []

    def table(self, headers, rows) -> None:
        self.tables.append((tuple(headers), [tuple(row) for row in rows]))

    def ask_line(self, prompt: str, default: str = "") -> str:
        return self.answers.pop(0) if self.answers else ""

    def info(self, message: str) -> None:
        self.messages.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)

    def error(self, message: str) -> None:
        self.errors.append(message)


class CatalogHelperTests(unittest.TestCase):
    def test_tool_support_reads_supported_parameters(self) -> None:
        self.assertTrue(_tool_support(CATALOG[0]))
        self.assertFalse(_tool_support(CATALOG[1]))
        self.assertIsNone(_tool_support({"id": "x/y"}))

    def test_filter_matches_id_and_name(self) -> None:
        self.assertEqual(
            [item["id"] for item in _filter_catalog(CATALOG, "llama")],
            ["meta-llama/llama-3-8b-instruct"],
        )
        self.assertEqual(
            [item["id"] for item in _filter_catalog(CATALOG, "GPT 4o")],
            ["openai/gpt-4o"],
        )
        self.assertEqual(_filter_catalog(CATALOG, ""), CATALOG)

    def test_row_shows_tool_column(self) -> None:
        row = _remote_row(1, CATALOG[0])
        self.assertEqual(row[0], "1")
        self.assertEqual(row[1], "openai/gpt-4o")
        self.assertEqual(row[-1], "var")
        self.assertEqual(_remote_row(2, CATALOG[1])[-1], "yok")


class RemotePickerTests(unittest.TestCase):
    def _pick(self, answers: list[str], **kwargs):
        ui = FakePickerUI(answers)
        with mock.patch("banana.cli.fetch_openrouter_models", return_value=CATALOG):
            return _remote_model_picker(ui, **kwargs), ui

    def test_selects_model_by_number_and_reports_tools(self) -> None:
        picked, ui = self._pick(["1"])
        self.assertEqual(picked, ("openrouter/meta-llama/llama-3-8b-instruct", False))
        headers, rows = ui.tables[0]
        self.assertIn("Arac", headers)
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[0][1], "meta-llama/llama-3-8b-instruct")

    def test_search_then_select(self) -> None:
        picked, ui = self._pick(["a mistral", "1"])
        self.assertEqual(picked, ("openrouter/mistralai/mistral-small", True))
        self.assertIn("filtre: mistral", ui.messages[-1])

    def test_failed_search_then_clear(self) -> None:
        picked, ui = self._pick(["a yokboyle", "a", "1"])
        self.assertEqual(picked, ("openrouter/meta-llama/llama-3-8b-instruct", False))
        self.assertTrue(any("Eslesen model yok" in item for item in ui.warnings))

    def test_cancel_with_empty_answer(self) -> None:
        picked, _ui = self._pick([""])
        self.assertIsNone(picked)

    def test_direct_model_id(self) -> None:
        picked, _ui = self._pick(["openrouter/openai/gpt-4o"])
        self.assertEqual(picked, ("openrouter/openai/gpt-4o", None))

    def test_pagination_moves_to_next_page(self) -> None:
        many = [
            {
                "id": f"vendor/model-{index:02d}",
                "name": f"Model {index:02d}",
                "supported_parameters": ["tools"],
            }
            for index in range(25)
        ]
        ui = FakePickerUI(["+", "21"])
        with mock.patch("banana.cli.fetch_openrouter_models", return_value=many):
            picked = _remote_model_picker(ui)
        self.assertEqual(picked, ("openrouter/vendor/model-20", True))
        self.assertEqual(ui.tables[0][1][0][0], "1")
        self.assertEqual(ui.tables[1][1][0][0], "21")

    def test_free_filter(self) -> None:
        ui = FakePickerUI(["1"])
        with mock.patch("banana.cli.fetch_openrouter_models", return_value=CATALOG):
            picked = _remote_model_picker(ui, free_only=True)
        self.assertEqual(picked, ("openrouter/meta-llama/llama-3-8b-instruct", False))


class _FakeProvider:
    name = "openrouter"
    label = "OpenRouter"

    def __init__(self) -> None:
        self.calls: list[dict] = []

    def stream(self, **kwargs):
        self.calls.append(kwargs)
        yield TextDelta("tamam")
        yield StreamDone(
            message=Message(role="assistant", content="tamam"),
            usage=Usage(input_tokens=3, output_tokens=1),
            stop_reason="stop",
            model=kwargs.get("model", ""),
        )

    def close(self) -> None:
        return None


class ConfigToolMemoryTests(unittest.TestCase):
    def test_model_tools_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            path = Path(raw) / "config.json"
            config = Config(config_path=path)
            config.model_tools["openrouter/vendor/model"] = False
            config.save()
            loaded = Config.load(path)
            self.assertFalse(loaded.model_tools["openrouter/vendor/model"])

    def test_switch_model_persists_choice(self) -> None:
        from types import SimpleNamespace

        from banana.cli import _switch_model

        class FakeAgent:
            def switch_model(self, *_args) -> None:
                return None

            def set_tools_enabled(self, _enabled) -> None:
                return None

        with tempfile.TemporaryDirectory() as raw:
            config = Config(config_path=Path(raw) / "config.json")
            config.api_keys["openrouter"] = "dummy-key"
            runtime = SimpleNamespace(
                config=config,
                provider=None,
                provider_name="openai",
                model="old",
                agent=FakeAgent(),
            )
            _switch_model(runtime, "openrouter/qwen/qwen3-coder")
            self.assertEqual(runtime.provider_name, "openrouter")
            self.assertEqual(runtime.model, "qwen/qwen3-coder")
            self.assertEqual(config.model, "openrouter/qwen/qwen3-coder")
            self.assertEqual(Config.load(config.config_path).model, config.model)
            runtime.provider.close()


class ActivationTests(unittest.TestCase):
    def _activate(self, supports_tools: bool | None):
        from types import SimpleNamespace

        from banana.cli import _activate_picked_model

        class FakeAgent:
            tools_enabled = True

            def set_tools_enabled(self, enabled) -> None:
                self.tools_enabled = enabled

        with tempfile.TemporaryDirectory() as raw:
            config = Config(config_path=Path(raw) / "config.json")
            ui = FakePickerUI([])
            runtime = SimpleNamespace(
                config=config,
                ui=ui,
                provider_name="openrouter",
                model="vendor/model",
                agent=FakeAgent(),
            )
            with mock.patch(
                "banana.cli._switch_model_interactive", return_value=True
            ):
                _activate_picked_model(
                    runtime, ("openrouter/vendor/model", supports_tools)
                )
            saved = Config.load(config.config_path)
            return SimpleNamespace(
                agent=runtime.agent,
                config=saved,
                model_tools_loaded=dict(saved.model_tools),
            )

    def test_chat_only_selection_disables_and_remembers_tools(self) -> None:
        runtime = self._activate(False)
        self.assertFalse(runtime.agent.tools_enabled)
        self.assertFalse(runtime.model_tools_loaded["openrouter/vendor/model"])

    def test_tool_capable_selection_enables_tools(self) -> None:
        runtime = self._activate(True)
        self.assertTrue(runtime.agent.tools_enabled)
        self.assertTrue(runtime.model_tools_loaded["openrouter/vendor/model"])


class AgentToolModeTests(unittest.TestCase):
    def _agent(self) -> tuple[Agent, _FakeProvider]:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        cwd = Path(tmp.name)
        ui = UI(
            color=False,
            one_shot=True,
            stream_output=False,
            sink=io.StringIO(),
            err=io.StringIO(),
        )
        provider = _FakeProvider()
        agent = Agent(
            provider=provider,
            provider_name="openrouter",
            model="vendor/model",
            config=Config(),
            ui=ui,
            approver=Approver(ui, "yolo"),
            session=Session.create(cwd, "openrouter", "vendor/model"),
            cwd=cwd,
            persist=False,
        )
        return agent, provider

    def test_prompt_hides_tools_when_disabled(self) -> None:
        cwd = Path(".")
        enabled = build_system_prompt(cwd)
        disabled = build_system_prompt(cwd, tools_enabled=False)
        self.assertIn("read_file:", enabled)
        self.assertNotIn("read_file:", disabled)
        self.assertIn("Tool use is disabled", disabled)

    def test_agent_sends_no_tools_when_disabled(self) -> None:
        agent, provider = self._agent()
        agent.set_tools_enabled(False)
        agent.run_turn("merhaba")
        self.assertEqual(provider.calls[0]["tools"], [])
        self.assertIn("Tool use is disabled", provider.calls[0]["system"])

    def test_agent_sends_tools_when_enabled(self) -> None:
        agent, provider = self._agent()
        agent.run_turn("merhaba")
        self.assertTrue(provider.calls[0]["tools"])
        self.assertIn("read_file:", provider.calls[0]["system"])


if __name__ == "__main__":
    unittest.main()
