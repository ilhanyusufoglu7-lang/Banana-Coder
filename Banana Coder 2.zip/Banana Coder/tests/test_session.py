from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.models import Message
from banana.session import Session


class SessionTests(unittest.TestCase):
    def test_save_latest_named_and_clear(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            session = Session.create(cwd, "openai", "test-model")
            self.assertFalse(session.path.exists())
            session.messages.append(Message(role="user", content="hello"))
            session.messages.append(Message(role="assistant", content="world"))
            session.usage.input_tokens = 12
            session.save()
            self.assertTrue(session.path.exists())

            latest = Session.load_latest(cwd)
            self.assertIsNotNone(latest)
            assert latest is not None
            self.assertEqual(len(latest.messages), 2)
            self.assertEqual(latest.messages[0].content, "hello")
            self.assertEqual(latest.usage.input_tokens, 12)
            self.assertEqual(latest.provider, "openai")
            self.assertEqual(latest.model, "test-model")

            recent = Session.recent(cwd)
            self.assertTrue(any(item.path == session.path for item in recent))

            named = Session.create(cwd, "gemini", "gemini-test", name="benim oturum")
            named.messages.append(Message(role="user", content="named"))
            named.save()
            loaded = Session.load_named("benim oturum", cwd)
            self.assertIsNotNone(loaded)
            assert loaded is not None
            self.assertEqual(loaded.messages[0].content, "named")
            self.assertIn("benim-oturum.json", loaded.path.name)

            named.clear()
            self.assertEqual(named.messages, [])
            reloaded = Session.load_named("benim oturum", cwd)
            assert reloaded is not None
            self.assertEqual(reloaded.messages, [])


if __name__ == "__main__":
    unittest.main()
