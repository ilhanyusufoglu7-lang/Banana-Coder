from __future__ import annotations

import json
import os
import tempfile
import threading
import unittest
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.net import ProviderError
from banana.tts import TTS_PCM_SAMPLE_RATE, _clean_for_speech, synthesize

# Ham PCM (44.1 kHz, 16-bit mono) gibi davranan cift uzunlukta sahte veri.
FAKE_AUDIO = b"\x00\x01\x02\x03" * 64
LAST: dict = {}


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args) -> None:
        return None

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("content-length") or 0)
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            payload = {}
        LAST["payload"] = payload
        LAST["auth"] = self.headers.get("Authorization", "")
        if self.path.startswith("/fail"):
            body = b'{"error":{"message":"no credits"}}'
            self.send_response(402)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path.startswith("/empty"):
            self.send_response(200)
            self.send_header("Content-Type", "audio/mpeg")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        # Raw PCM audio bytes, not JSON.
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("X-Generation-Id", "gen-123")
        self.send_header("Content-Length", str(len(FAKE_AUDIO)))
        self.end_headers()
        self.wfile.write(FAKE_AUDIO)


class TtsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()

    def _patch_url(self, path: str) -> str:
        import banana.tts as tts

        original = tts.TTS_URL
        tts.TTS_URL = f"{self.base}{path}"
        self.addCleanup(setattr, tts, "TTS_URL", original)

    def test_synthesize_writes_audio_bytes(self) -> None:
        self._patch_url("/audio/speech")
        out = synthesize("sk-test", "Merhaba dünya", voice="gareth")
        self.addCleanup(lambda: out.unlink(missing_ok=True))
        self.assertEqual(out.suffix, ".wav")
        with wave.open(str(out), "rb") as wav:
            self.assertEqual(wav.getnchannels(), 1)
            self.assertEqual(wav.getsampwidth(), 2)
            self.assertEqual(wav.getframerate(), TTS_PCM_SAMPLE_RATE)
            self.assertEqual(wav.readframes(wav.getnframes()), FAKE_AUDIO)
        self.assertEqual(LAST["payload"]["voice"], "gareth")
        self.assertEqual(LAST["payload"]["input"], "Merhaba dünya")
        self.assertEqual(LAST["payload"]["response_format"], "pcm")
        self.assertIn("heygen", LAST["payload"]["model"])
        self.assertEqual(LAST["auth"], "Bearer sk-test")

    def test_missing_key_raises(self) -> None:
        with self.assertRaises(ProviderError):
            synthesize("", "bir sey")

    def test_http_error_raises(self) -> None:
        self._patch_url("/fail/audio/speech")
        with self.assertRaises(ProviderError) as ctx:
            synthesize("sk-test", "merhaba")
        self.assertIn("402", str(ctx.exception))

    def test_empty_audio_raises(self) -> None:
        self._patch_url("/empty")
        with self.assertRaises(ProviderError):
            synthesize("sk-test", "merhaba")

    def test_clean_strips_code_blocks_and_markdown(self) -> None:
        text = "# Baslik\n\nMerhaba.\n\n```python\nprint(1)\n```\n\n- madde\nBitis."
        cleaned = _clean_for_speech(text)
        self.assertIn("Merhaba.", cleaned)
        self.assertIn("Bitis.", cleaned)
        self.assertNotIn("print(1)", cleaned)
        self.assertNotIn("```", cleaned)
        self.assertNotIn("Baslik", cleaned)

    def test_clean_returns_empty_for_code_only(self) -> None:
        with self.assertRaises(ProviderError):
            self._patch_url("/audio/speech")
            synthesize("sk-test", "```py\nx=1\n```")


if __name__ == "__main__":
    unittest.main()
