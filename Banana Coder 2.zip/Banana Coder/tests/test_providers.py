from __future__ import annotations

import os
import tempfile
import unittest

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.models import Message, StreamDone, TextDelta
from banana.net import ProviderError
from banana.providers.anthropic import AnthropicProvider
from banana.providers.gemini import GeminiProvider
from banana.providers.openai_compat import OpenAIProvider, OpenRouterProvider
from banana.tools import tool_specs
from tests.mock_api import MockAPI


class ProviderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.mock = MockAPI().start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.mock.stop()

    def _provider(self, kind: str):
        base = f"http://127.0.0.1:{self.mock.port}"
        if kind == "openai":
            return OpenAIProvider("test-openai", base + "/v1")
        if kind == "anthropic":
            return AnthropicProvider("test-anthropic", base)
        if kind == "gemini":
            return GeminiProvider("test-gemini", base + "/v1beta")
        raise AssertionError(kind)

    def test_tool_call_round_trip_for_each_provider(self) -> None:
        for kind in ("openai", "anthropic", "gemini"):
            with self.subTest(provider=kind):
                provider = self._provider(kind)
                try:
                    first_messages = [Message(role="user", content="read sample.txt")]
                    message, usage, stop_reason, model = provider.complete(
                        model="test-model",
                        system="You are a test.",
                        messages=first_messages,
                        tools=tool_specs(),
                        max_tokens=1024,
                    )
                    self.assertEqual(model, "mock-model")
                    self.assertEqual(len(message.tool_calls), 1)
                    call = message.tool_calls[0]
                    self.assertEqual(call.name, "read_file")
                    self.assertEqual(call.arguments, {"path": "sample.txt"})
                    self.assertIsNone(call.parse_error)
                    self.assertGreater(usage.input_tokens, 0)
                    if kind == "openai":
                        self.assertEqual(usage.cost, 0.0001)
                        self.assertEqual(stop_reason, "tool_calls")
                    elif kind == "anthropic":
                        self.assertEqual(usage.cache_read_tokens, 2)
                        self.assertEqual(stop_reason, "tool_use")
                    else:
                        self.assertEqual(stop_reason, "STOP")

                    history = [
                        *first_messages,
                        message,
                        Message(
                            role="tool",
                            content="BANANA_FILE_CONTENT",
                            tool_call_id=call.id,
                            tool_name=call.name,
                        ),
                    ]
                    events = list(
                        provider.stream(
                            model="test-model",
                            system="You are a test.",
                            messages=history,
                            tools=tool_specs(),
                            max_tokens=1024,
                        )
                    )
                    text = "".join(
                        event.text for event in events if isinstance(event, TextDelta)
                    )
                    done = [event for event in events if isinstance(event, StreamDone)]
                    self.assertEqual(len(done), 1)
                    self.assertIn("BANANA_FILE_CONTENT", text)
                    self.assertIn("BANANA_FILE_CONTENT", done[0].message.content)
                    self.assertEqual(done[0].message.tool_calls, [])
                    self.assertGreater(done[0].usage.input_tokens, 0)

                    path, headers, payload = self.mock.requests[-1]
                    if kind == "openai":
                        self.assertEqual(path, "/v1/chat/completions")
                        self.assertEqual(headers.get("authorization"), "Bearer test-openai")
                        self.assertIn("function", payload["tools"][0])
                        self.assertIn("max_completion_tokens", payload)
                        self.assertTrue(
                            any(
                                m.get("role") == "tool"
                                and "BANANA_FILE_CONTENT" in str(m.get("content"))
                                for m in payload["messages"]
                            )
                        )
                    elif kind == "anthropic":
                        self.assertEqual(path, "/v1/messages")
                        self.assertEqual(headers.get("x-api-key"), "test-anthropic")
                        self.assertIn("input_schema", payload["tools"][0])
                        self.assertTrue(
                            any(
                                block.get("type") == "tool_result"
                                for message in payload["messages"]
                                if isinstance(message.get("content"), list)
                                for block in message["content"]
                            )
                        )
                    else:
                        self.assertIn(":streamGenerateContent", path)
                        self.assertEqual(headers.get("x-goog-api-key"), "test-gemini")
                        self.assertIn(
                            "functionDeclarations", payload["tools"][0]
                        )
                        self.assertIn(
                            "BANANA_FILE_CONTENT",
                            str(payload["contents"]),
                        )
                finally:
                    provider.close()

    def test_openrouter_headers_and_token_parameter(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        provider = OpenRouterProvider("test-openrouter", base + "/v1")
        try:
            provider.complete(
                model="anthropic/claude-sonnet-4.5",
                system="test",
                messages=[Message(role="user", content="read sample.txt")],
                tools=tool_specs(),
                max_tokens=512,
            )
        finally:
            provider.close()
        path, headers, payload = self.mock.requests[-1]
        self.assertEqual(path, "/v1/chat/completions")
        self.assertEqual(headers.get("authorization"), "Bearer test-openrouter")
        self.assertEqual(headers.get("x-title"), "Banana Coder")
        self.assertIn("max_tokens", payload)
        self.assertNotIn("max_completion_tokens", payload)
        self.assertEqual(
            payload["stream_options"]["include_usage"],
            True,
        )

    def test_http_error_is_reported_clearly(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        provider = OpenAIProvider("bad-key", base + "/fail/v1")
        try:
            with self.assertRaises(ProviderError) as caught:
                provider.complete(
                    model="test-model",
                    system="test",
                    messages=[Message(role="user", content="hello")],
                    tools=[],
                    max_tokens=32,
                )
        finally:
            provider.close()
        self.assertEqual(caught.exception.status_code, 401)
        self.assertIn("API anahtari", str(caught.exception))
        self.assertIn("HTTP 401", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
