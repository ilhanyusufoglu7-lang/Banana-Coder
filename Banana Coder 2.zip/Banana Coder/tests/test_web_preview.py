from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from banana.approval import Approver
from banana.preview import clear, feed, init, path, should_print_inline
from banana.preview import publish as preview_publish
from banana.tools.common import ToolContext, ToolError
from banana.tools.web import (
    html_to_text,
    is_blocked_host,
    validate_url,
    web_fetch,
)
from banana.ui import UI
SAMPLE_HTML = """
<html><head><title>Kurulum Rehberi</title>
<script>var secret = "should be dropped";</script>
<style>.a{color:red}</style></head>
<body>
  <h1>Kurulum</h1>
  <p>Ilk  adim   <b>onetemli</b>.</p>
  <ul><li>ikinci</li><li>ucuncu</li></ul>
  <pre>kod  satiri</pre>
  &amp;&ouml;zet
</body></html>
"""


class YoloApprover(Approver):
    def __init__(self) -> None:
        super().__init__(UI(color=False, one_shot=True), "yolo")


class FakeUI:
    def __init__(self) -> None:
        self.lines: list[str] = []

    def preview_line(self, line: str) -> None:
        self.lines.append(line)


def _ctx(ui=None) -> ToolContext:
    return ToolContext(
        cwd=Path(tempfile.mkdtemp()), approver=YoloApprover(), ui=ui
    )


class UrlGuardTests(unittest.TestCase):
    def test_rejects_non_http(self) -> None:
        for url in ("ftp://x.com/a", "file:///etc/passwd", "", "javascript:alert(1)"):
            with self.assertRaises(ToolError):
                validate_url(url)

    def test_blocks_private_and_local(self) -> None:
        for host in (
            "127.0.0.1",
            "::1",
            "localhost",
            "10.0.0.5",
            "192.168.1.1",
            "169.254.169.254",
            "metadata.google.internal",
            "db.localhost",
        ):
            self.assertTrue(is_blocked_host(host), host)
            with self.assertRaises(ToolError):
                validate_url(f"http://{host}/x")

    def test_allows_public(self) -> None:
        self.assertEqual(
            validate_url("https://example.com/docs"), "https://example.com/docs"
        )
        self.assertFalse(is_blocked_host("example.com"))


class HtmlToTextTests(unittest.TestCase):
    def test_strips_scripts_and_keeps_text(self) -> None:
        text = html_to_text(SAMPLE_HTML)
        self.assertIn("Kurulum", text)
        self.assertIn("ikinci", text)
        self.assertIn("özet", text)
        self.assertNotIn("&amp;", text)
        self.assertNotIn("should be dropped", text)
        self.assertNotIn("color:red", text)
        self.assertNotIn("<", text)


class WebFetchTests(unittest.TestCase):
    def test_refused_by_user(self) -> None:
        class Deny(Approver):
            def allow(self, title, preview=None):
                return False

        ctx = ToolContext(cwd=Path.cwd(), approver=Deny(UI(color=False, one_shot=True)))
        result = web_fetch({"url": "https://example.com"}, ctx)
        self.assertTrue(result.is_error)
        self.assertEqual(result.summary, "reddedildi")

    def test_fetches_and_strips_html(self) -> None:
        import http.server
        import os
        import threading

        os.environ["BANANA_ALLOW_PRIVATE_URLS"] = "1"

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"

            def do_GET(self):
                if self.path == "/go":
                    self.send_response(302)
                    self.send_header("Location", "/docs")
                    self.end_headers()
                    return
                body = SAMPLE_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                return None

        with tempfile.TemporaryDirectory() as raw:
            home = Path(raw) / "home"
            home.mkdir()
            init(home / "config.json", enabled=True)
            server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            port = server.server_address[1]
            url = f"http://127.0.0.1:{port}/docs"
            fake_ui = FakeUI()
            ctx = _ctx(fake_ui)
            try:
                result = web_fetch({"url": url}, ctx)
                redirected = web_fetch({"url": f"http://127.0.0.1:{port}/go"}, ctx)
                logged = path().read_text(encoding="utf-8")
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)
                os.environ.pop("BANANA_ALLOW_PRIVATE_URLS", None)

        self.assertFalse(result.is_error)
        self.assertFalse(redirected.is_error)
        self.assertIn("HTTP 200", redirected.content)
        self.assertIn("/docs", redirected.content)
        self.assertIn("HTTP 200", result.content)
        self.assertIn("Kurulum", result.content)
        self.assertNotIn("should be dropped", result.content)
        self.assertIn("Kurulum Rehberi", result.content)
        self.assertTrue(any("GET" in line for line in fake_ui.lines))
        self.assertIn(url, logged)
        self.assertIn("[fetch]", logged)


class PreviewFeedTests(unittest.TestCase):
    def test_writes_queue_file(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            init(Path(home, "config.json"), enabled=True)
            line = feed("call", "read_file path=a.txt")
            self.assertIn("[call] read_file path=a.txt", line)
            self.assertIn(line, path().read_text(encoding="utf-8"))
            clear()
            self.assertEqual(path().read_text(encoding="utf-8"), "")

    def test_inline_flag_respects_one_shot(self) -> None:
        import os

        with tempfile.TemporaryDirectory() as home:
            init(Path(home, "config.json"), enabled=True)
            self.assertTrue(should_print_inline())
            os.environ["BANANA_ONE_SHOT"] = "1"
            try:
                self.assertFalse(should_print_inline())
            finally:
                os.environ.pop("BANANA_ONE_SHOT", None)

    def test_publish_calls_ui(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            init(Path(home, "config.json"), enabled=True)
            ui = FakeUI()
            preview_publish("fetch", "GET https://x.dev", ui)
            self.assertEqual(len(ui.lines), 1)
            self.assertIn("https://x.dev", ui.lines[0])


if __name__ == "__main__":
    unittest.main()
