from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.cli import _expand_file_refs
from tests.mock_api import MockAPI

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class CliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.mock = MockAPI().start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.mock.stop()

    def test_one_shot_for_each_provider(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        for provider in ("openai", "anthropic", "gemini"):
            with self.subTest(provider=provider), tempfile.TemporaryDirectory() as raw:
                cwd = Path(raw)
                home = Path(raw) / "home"
                (cwd / "sample.txt").write_text(
                    "BANANA_FILE_CONTENT\n", encoding="utf-8"
                )
                env = os.environ.copy()
                env.update(
                    {
                        "OPENAI_API_KEY": "test-openai",
                        "OPENAI_BASE_URL": base + "/v1",
                        "ANTHROPIC_API_KEY": "test-anthropic",
                        "ANTHROPIC_BASE_URL": base,
                        "GEMINI_API_KEY": "test-gemini",
                        "GEMINI_BASE_URL": base + "/v1beta",
                        "BANANA_HOME": str(home),
                        "NO_COLOR": "1",
                        "PYTHONPATH": str(PROJECT_ROOT),
                    }
                )
                completed = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "banana",
                        "-m",
                        f"{provider}/test-model",
                        "-p",
                        "sample.txt dosyasini oku",
                        "--yolo",
                        "--json",
                    ],
                    cwd=str(cwd),
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
                self.assertEqual(
                    completed.returncode,
                    0,
                    f"stdout={completed.stdout}\nstderr={completed.stderr}",
                )
                payload = json.loads(completed.stdout)
                self.assertEqual(payload["provider"], provider)
                self.assertEqual(payload["model"], "test-model")
                self.assertIn("BANANA_FILE_CONTENT", payload["text"])
                self.assertEqual(payload["tool_rounds"], 1)
                self.assertGreater(payload["usage"]["input_tokens"], 0)
                self.assertIn("read_file", completed.stderr)

    def test_file_reference_expansion(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            (cwd / "note.txt").write_text("ATTACH_CONTENT\n", encoding="utf-8")
            (cwd / "bin.dat").write_bytes(b"\x00binary")
            text = _expand_file_refs("nota bak @note.txt ve @bin.dat", cwd)
            self.assertIn("<attached_files>", text)
            self.assertIn("ATTACH_CONTENT", text)
            self.assertIn('skipped="binary"', text)
            self.assertIn("nota bak @note.txt", text)

    def test_repl_turn_help_and_session_persistence(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            home = cwd / "home"
            (cwd / "sample.txt").write_text(
                "BANANA_FILE_CONTENT\n", encoding="utf-8"
            )
            env = os.environ.copy()
            env.update(
                {
                    "OPENAI_API_KEY": "test-openai",
                    "OPENAI_BASE_URL": base + "/v1",
                    "BANANA_HOME": str(home),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            completed = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "banana",
                    "-m",
                    "openai/test-model",
                    "--yolo",
                ],
                cwd=str(cwd),
                env=env,
                input="sample.txt dosyasini oku\n/help\n/boost\n/quit\n",
                capture_output=True,
                text=True,
                timeout=120,
            )
            self.assertEqual(
                completed.returncode,
                0,
                f"stdout={completed.stdout}\nstderr={completed.stderr}",
            )
            self.assertIn("BANANA_FILE_CONTENT", completed.stdout)
            self.assertIn("/model [ad]", completed.stdout)
            self.assertIn("Prompt upgrade:", completed.stdout)

            sessions = list((home / "sessions").glob("*.json"))
            self.assertTrue(sessions)
            payload = json.loads(sessions[0].read_text(encoding="utf-8"))
            self.assertTrue(
                any(
                    message["role"] == "user"
                    and "sample.txt" in message["content"]
                    for message in payload["messages"]
                )
            )

    def test_boost_end_to_end_one_shot(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            home = cwd / "home"
            (cwd / "sample.txt").write_text("BANANA_FILE_CONTENT\n", encoding="utf-8")
            config_path = home / "config.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(
                json.dumps(
                    {
                        "model": "openai/test-model",
                        "api_keys": {"openai": "cfg-openai-key"},
                        "boost_enabled": True,
                        "boost_model": "openai/test-model",
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            env = os.environ.copy()
            env.update(
                {
                    "OPENAI_BASE_URL": base + "/v1",
                    "BANANA_HOME": str(home),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            for key in (
                "OPENAI_API_KEY",
                "ANTHROPIC_API_KEY",
                "OPENROUTER_API_KEY",
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
            ):
                env.pop(key, None)
            completed = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "banana",
                    "-p",
                    "sample.txt dosyasini oku",
                    "--yolo",
                    "--json",
                ],
                cwd=str(cwd),
                env=env,
                capture_output=True,
                text=True,
                timeout=120,
            )
            self.assertEqual(
                completed.returncode,
                0,
                f"stdout={completed.stdout}\nstderr={completed.stderr}",
            )
            payload = json.loads(completed.stdout)
            self.assertIn("UPGRADED:", payload["text"])
            self.assertIn("sample.txt dosyasini oku", payload["text"])

    def test_preview_repl_shows_activity_feed(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            home = cwd / "home"
            config_path = home / "config.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(
                json.dumps(
                    {
                        "model": "openai/test-model",
                        "api_keys": {"openai": "cfg-openai-key"},
                        "approval": "yolo",
                        "preview_enabled": True,
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            env = os.environ.copy()
            env.update(
                {
                    "OPENAI_BASE_URL": base + "/v1",
                    "BANANA_HOME": str(home),
                    "BANANA_ALLOW_PRIVATE_URLS": "1",
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            for key in (
                "OPENAI_API_KEY",
                "ANTHROPIC_API_KEY",
                "OPENROUTER_API_KEY",
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
            ):
                env.pop(key, None)
            completed = subprocess.run(
                [sys.executable, "-m", "banana", "--yolo"],
                cwd=str(cwd),
                env=env,
                input="FETCH_DOC_URL ile belgeyi cek\n/preview\n/quit\n",
                capture_output=True,
                text=True,
                timeout=120,
            )
            self.assertEqual(
                completed.returncode,
                0,
                f"stdout={completed.stdout}\nstderr={completed.stderr}",
            )
            self.assertIn("PV ", completed.stdout)
            self.assertIn("[call] web_fetch", completed.stdout)
            self.assertIn("[fetch] GET http://127.0.0.1:", completed.stdout)
            self.assertIn("Canli islem paneli: acik", completed.stdout)
            logged = (home / "preview.log").read_text(encoding="utf-8")
            self.assertIn("[fetch] GET http://127.0.0.1:", logged)
            self.assertIn("[done] web_fetch: HTTP 200", logged)

    def test_models_presets_command(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            env = os.environ.copy()
            env.update(
                {
                    "BANANA_HOME": str(Path(raw) / "home"),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            completed = subprocess.run(
                [sys.executable, "-m", "banana", "models"],
                env=env,
                capture_output=True,
                text=True,
                timeout=60,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertIn("or-claude", completed.stdout)
            self.assertIn("openrouter/anthropic/claude-sonnet-5.5", completed.stdout)
            self.assertIn("or-free", completed.stdout)
            self.assertIn("openrouter/openrouter/free", completed.stdout)

    def test_api_command_stores_key_in_config(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            home = cwd / "home"
            env = os.environ.copy()
            env.update(
                {
                    "ANTHROPIC_API_KEY": "test-anthropic",
                    "ANTHROPIC_BASE_URL": base,
                    "BANANA_HOME": str(home),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            config_path = home / "config.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(
                json.dumps({"model": "claude"}, ensure_ascii=False),
                encoding="utf-8",
            )
            completed = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "banana",
                    "--yolo",
                ],
                cwd=str(cwd),
                env=env,
                input="/api openai sk-test-openai\n/api\n/quit\n",
                capture_output=True,
                text=True,
                timeout=120,
            )
            self.assertEqual(
                completed.returncode,
                0,
                f"stdout={completed.stdout}\nstderr={completed.stderr}",
            )
            self.assertIn("kaydedildi", completed.stdout)
            saved = json.loads(config_path.read_text(encoding="utf-8"))
            self.assertEqual(saved.get("api_keys", {}).get("openai"), "sk-test-openai")

    def test_noninteractive_missing_key_shows_help(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            home = Path(raw) / "home"
            env = os.environ.copy()
            env.update(
                {
                    "BANANA_HOME": str(home),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            for key in (
                "OPENAI_API_KEY",
                "ANTHROPIC_API_KEY",
                "OPENROUTER_API_KEY",
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
            ):
                env.pop(key, None)
            completed = subprocess.run(
                [sys.executable, "-m", "banana"],
                cwd=str(raw),
                env=env,
                input="\n",
                capture_output=True,
                text=True,
                timeout=60,
            )
            self.assertNotEqual(completed.returncode, 0)
            self.assertIn("/api", completed.stdout + completed.stderr)

    def test_config_json_key_is_used_without_env(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"
        with tempfile.TemporaryDirectory() as raw:
            cwd = Path(raw)
            home = cwd / "home"
            (cwd / "sample.txt").write_text(
                "BANANA_FILE_CONTENT\n", encoding="utf-8"
            )
            config_path = home / "config.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(
                json.dumps(
                    {
                        "model": "openai/test-model",
                        "api_keys": {"openai": "cfg-openai-key"},
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            env = os.environ.copy()
            env.update(
                {
                    "OPENAI_BASE_URL": base + "/v1",
                    "BANANA_HOME": str(home),
                    "NO_COLOR": "1",
                    "PYTHONPATH": str(PROJECT_ROOT),
                }
            )
            for key in (
                "OPENAI_API_KEY",
                "ANTHROPIC_API_KEY",
                "OPENROUTER_API_KEY",
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
            ):
                env.pop(key, None)
            completed = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "banana",
                    "-p",
                    "sample.txt dosyasini oku",
                    "--yolo",
                    "--json",
                ],
                cwd=str(cwd),
                env=env,
                capture_output=True,
                text=True,
                timeout=120,
            )
            self.assertEqual(
                completed.returncode,
                0,
                f"stdout={completed.stdout}\nstderr={completed.stderr}",
            )
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["provider"], "openai")
            self.assertIn("BANANA_FILE_CONTENT", payload["text"])


if __name__ == "__main__":
    unittest.main()
