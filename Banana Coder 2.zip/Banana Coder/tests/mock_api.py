from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


def _sse(data: dict[str, Any], event: str | None = None) -> str:
    prefix = f"event: {event}\n" if event else ""
    return prefix + "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"


def _final_text(payload: dict[str, Any]) -> str:
    if "BANANA_FILE_CONTENT" in json.dumps(payload, ensure_ascii=False):
        return "okundu: BANANA_FILE_CONTENT"
    return "arac sonucu bulunamadi"


BOOST_SYSTEM_MARKER = "prompt-upgrade assistant"


def _is_boost_request(payload: dict[str, Any]) -> bool:
    return BOOST_SYSTEM_MARKER in json.dumps(payload, ensure_ascii=False)


def _first_user_text(payload: dict[str, Any]) -> str:
    for message in payload.get("messages") or []:
        if isinstance(message, dict) and message.get("role") == "user":
            content = message.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return "".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict)
                )
    return ""


def _openai_has_tool_result(payload: dict[str, Any]) -> bool:
    for message in payload.get("messages") or []:
        if isinstance(message, dict) and message.get("role") == "tool":
            return True
    return False


def _anthropic_has_tool_result(payload: dict[str, Any]) -> bool:
    for message in payload.get("messages") or []:
        content = message.get("content") if isinstance(message, dict) else None
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    return True
    return False


def _gemini_has_tool_result(payload: dict[str, Any]) -> bool:
    for content in payload.get("contents") or []:
        parts = content.get("parts") if isinstance(content, dict) else None
        if isinstance(parts, list):
            for part in parts:
                if isinstance(part, dict) and "functionResponse" in part:
                    return True
    return False


class MockAPI:
    def __init__(self) -> None:
        self.requests: list[tuple[str, dict[str, str], dict[str, Any]]] = []
        self.lock = threading.Lock()
        handler = _make_handler()
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.server.owner = self  # type: ignore[attr-defined]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def port(self) -> int:
        return int(self.server.server_address[1])

    def start(self) -> "MockAPI":
        self.thread.start()
        return self

    def stop(self) -> None:
        self.server.shutdown()
        self.server.server_close()

    def record(
        self, path: str, headers: dict[str, str], payload: dict[str, Any]
    ) -> None:
        with self.lock:
            self.requests.append((path, headers, payload))

    def openai_events(self, payload: dict[str, Any]) -> list[str]:
        has_result = _openai_has_tool_result(payload)
        if "FETCH_DOC_URL" in json.dumps(payload, ensure_ascii=False) and not has_result:
            doc_url = f"http://127.0.0.1:{self.port}/doc"
            return [
                _sse(
                    {
                        "id": "mock",
                        "model": "mock-model",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "tool_calls": [
                                        {
                                            "index": 0,
                                            "id": "call_fetch_1",
                                            "type": "function",
                                            "function": {
                                                "name": "web_fetch",
                                                "arguments": json.dumps(
                                                    {"url": doc_url}
                                                ),
                                            },
                                        }
                                    ]
                                },
                                "finish_reason": "tool_calls",
                            }
                        ],
                    }
                ),
                "data: [DONE]\n\n",
            ]
        if _is_boost_request(payload):
            return [
                _sse(
                    {
                        "id": "mock-boost",
                        "model": "mock-model",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "UPGRADED: "
                                    + _first_user_text(payload)
                                },
                                "finish_reason": "stop",
                            }
                        ],
                    }
                ),
                "data: [DONE]\n\n",
            ]
        if not _openai_has_tool_result(payload):
            return [
                _sse(
                    {
                        "id": "mock",
                        "model": "mock-model",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "reasoning": "once dosyayi okuyayim",
                                    "tool_calls": [
                                        {
                                            "index": 0,
                                            "id": "call_read_1",
                                            "type": "function",
                                            "function": {
                                                "name": "read_file",
                                                "arguments": '{"path":',
                                            },
                                        }
                                    ],
                                },
                                "finish_reason": None,
                            }
                        ],
                    }
                ),
                _sse(
                    {
                        "id": "mock",
                        "model": "mock-model",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "tool_calls": [
                                        {
                                            "index": 0,
                                            "function": {
                                                "arguments": ' "sample.txt"}'
                                            },
                                        }
                                    ]
                                },
                                "finish_reason": "tool_calls",
                            }
                        ],
                        "usage": {
                            "prompt_tokens": 10,
                            "completion_tokens": 5,
                            "cost": 0.0001,
                        },
                    }
                ),
                "data: [DONE]\n\n",
            ]
        upgraded = _first_user_text(payload)
        suffix = f" | {upgraded}" if "UPGRADED:" in upgraded else ""
        return [
            _sse(
                {
                    "id": "mock",
                    "model": "mock-model",
                    "choices": [
                        {
                            "index": 0,
                            "delta": {"content": "Dosya "},
                            "finish_reason": None,
                        }
                    ],
                }
            ),
            _sse(
                {
                    "id": "mock",
                    "model": "mock-model",
                    "choices": [
                        {
                            "index": 0,
                            "delta": {"content": _final_text(payload) + suffix},
                            "finish_reason": "stop",
                        }
                    ],
                    "usage": {"prompt_tokens": 30, "completion_tokens": 8},
                }
            ),
            "data: [DONE]\n\n",
        ]

    def anthropic_events(self, payload: dict[str, Any]) -> list[str]:
        if not _anthropic_has_tool_result(payload):
            return [
                _sse(
                    {
                        "type": "message_start",
                        "message": {
                            "id": "msg_mock",
                            "model": "mock-model",
                            "usage": {
                                "input_tokens": 10,
                                "output_tokens": 1,
                                "cache_read_input_tokens": 2,
                            },
                        },
                    },
                    event="message_start",
                ),
                _sse(
                    {
                        "type": "content_block_start",
                        "index": 0,
                        "content_block": {
                            "type": "tool_use",
                            "id": "toolu_read_1",
                            "name": "read_file",
                            "input": {},
                        },
                    },
                    event="content_block_start",
                ),
                _sse(
                    {
                        "type": "content_block_delta",
                        "index": 0,
                        "delta": {
                            "type": "input_json_delta",
                            "partial_json": '{"path": "sample.txt"}',
                        },
                    },
                    event="content_block_delta",
                ),
                _sse(
                    {"type": "content_block_stop", "index": 0},
                    event="content_block_stop",
                ),
                _sse(
                    {
                        "type": "message_delta",
                        "delta": {"stop_reason": "tool_use"},
                        "usage": {"output_tokens": 12},
                    },
                    event="message_delta",
                ),
                _sse({"type": "message_stop"}, event="message_stop"),
            ]
        return [
            _sse(
                {
                    "type": "message_start",
                    "message": {
                        "id": "msg_mock2",
                        "model": "mock-model",
                        "usage": {"input_tokens": 30, "output_tokens": 1},
                    },
                },
                event="message_start",
            ),
            _sse(
                {
                    "type": "content_block_start",
                    "index": 0,
                    "content_block": {"type": "text", "text": ""},
                },
                event="content_block_start",
            ),
            _sse(
                {
                    "type": "content_block_delta",
                    "index": 0,
                    "delta": {"type": "text_delta", "text": "Dosya "},
                },
                event="content_block_delta",
            ),
            _sse(
                {
                    "type": "content_block_delta",
                    "index": 0,
                    "delta": {"type": "text_delta", "text": _final_text(payload)},
                },
                event="content_block_delta",
            ),
            _sse(
                {"type": "content_block_stop", "index": 0},
                event="content_block_stop",
            ),
            _sse(
                {
                    "type": "message_delta",
                    "delta": {"stop_reason": "end_turn"},
                    "usage": {"output_tokens": 8},
                },
                event="message_delta",
            ),
            _sse({"type": "message_stop"}, event="message_stop"),
        ]

    def gemini_events(self, payload: dict[str, Any]) -> list[str]:
        if not _gemini_has_tool_result(payload):
            return [
                _sse(
                    {
                        "modelVersion": "mock-model",
                        "candidates": [
                            {
                                "content": {
                                    "role": "model",
                                    "parts": [
                                        {
                                            "functionCall": {
                                                "name": "read_file",
                                                "args": {"path": "sample.txt"},
                                            }
                                        }
                                    ],
                                },
                                "finishReason": "STOP",
                            }
                        ],
                        "usageMetadata": {
                            "promptTokenCount": 10,
                            "candidatesTokenCount": 5,
                        },
                    }
                )
            ]
        return [
            _sse(
                {
                    "modelVersion": "mock-model",
                    "candidates": [
                        {
                            "content": {
                                "role": "model",
                                "parts": [{"text": "Dosya "}],
                            },
                            "finishReason": None,
                        }
                    ]
                }
            ),
            _sse(
                {
                    "modelVersion": "mock-model",
                    "candidates": [
                        {
                            "content": {
                                "role": "model",
                                "parts": [{"text": _final_text(payload)}],
                            },
                            "finishReason": "STOP",
                        }
                    ],
                    "usageMetadata": {
                        "promptTokenCount": 30,
                        "candidatesTokenCount": 8,
                    },
                }
            ),
        ]


def _make_handler():
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *_args) -> None:
            return None

        def do_GET(self) -> None:
            if not self.path.startswith("/doc"):
                self.send_response(404)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            body = (
                b"<html><head><title>Onizleme Belgesi</title>"
                b"<script>GIZLI_KOD = 1;</script></head>"
                b"<body><h1>PREVIEW_DOC_BODY</h1><p>belge satiri</p></body></html>"
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self) -> None:
            length = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(length)
            try:
                payload = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                payload = {}
            owner: MockAPI = self.server.owner  # type: ignore[attr-defined]
            headers = {key.lower(): value for key, value in self.headers.items()}
            owner.record(self.path, headers, payload)

            if self.path.startswith("/fail"):
                body = b'{"error":{"message":"invalid api key"}}'
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            if self.path.startswith("/v1/chat/completions"):
                events = owner.openai_events(payload)
            elif self.path.startswith("/v1/messages"):
                events = owner.anthropic_events(payload)
            elif ":streamGenerateContent" in self.path:
                events = owner.gemini_events(payload)
            else:
                body = b'{"error":{"message":"unknown path"}}'
                self.send_response(404)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()
            for chunk in events:
                self.wfile.write(chunk.encode("utf-8"))
                self.wfile.flush()
            self.close_connection = True

    return Handler
