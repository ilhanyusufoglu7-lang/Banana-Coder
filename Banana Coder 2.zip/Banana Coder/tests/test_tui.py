from __future__ import annotations

import asyncio
import os
import tempfile
import threading
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-tui-home-"))

from banana.agent import Agent
from banana.approval import Approver
from banana.cli import HELP_ROWS, Runtime, _run_repl
from banana.config import Config
from banana.providers import create_provider
from banana.session import Session
from banana.tui import BananaApp
from textual.widgets import Input, Static
from tests.mock_api import MockAPI


def _config(home: Path, base: str) -> Config:
    config = Config.load(home / "config.json")
    config.set_api_key("openai", "test-openai")
    config.base_urls["openai"] = base + "/v1"
    config.model = "openai/test-model"
    config.save()
    return config


def _runtime(
    *,
    ui,
    config: Config,
    cwd: Path,
    approval: str,
    session: Session,
    provider,
):
    approver = Approver(ui, approval)
    agent = Agent(
        provider=provider,
        provider_name="openai",
        model="test-model",
        config=config,
        ui=ui,
        approver=approver,
        session=session,
        cwd=cwd,
        persist=False,
    )
    return Runtime(
        config=config,
        ui=ui,
        approver=approver,
        session=session,
        provider=provider,
        provider_name="openai",
        model="test-model",
        agent=agent,
        persist=False,
    )


def _chat_text(app: BananaApp) -> str:
    chat = app.query_one("#chat")
    return "\n".join(str(child.render()) for child in chat.children)


async def _submit(app: BananaApp, pilot, text: str) -> None:
    prompt = app.query_one("#prompt", Input)
    prompt.value = text
    await pilot.press("enter")
    await pilot.pause(0.4)


class TuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.mock = MockAPI().start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.mock.stop()

    def _session(self, cwd: Path) -> Session:
        return Session.create(cwd, "", "")

    def test_tui_streams_answer_into_chat(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"

        async def scenario() -> None:
            with tempfile.TemporaryDirectory() as raw:
                cwd = Path(raw)
                home = cwd / "home"
                home.mkdir()
                (cwd / "sample.txt").write_text("BANANA_FILE_CONTENT\n", encoding="utf-8")
                config = _config(home, base)
                provider = create_provider(config, "openai")
                session = self._session(home)

                def repl() -> int:
                    runtime = _runtime(
                        ui=app.ui,
                        config=config,
                        cwd=cwd,
                        approval="yolo",
                        session=session,
                        provider=provider,
                    )
                    app.ui.banner("0.0.0", "openai/test-model", "OpenAI", str(cwd), "yolo")
                    try:
                        return _run_repl(runtime, "test")
                    finally:
                        provider.close()

                app = BananaApp(
                    status_provider=lambda: "durum cubugu",
                    info_provider=lambda: "bilgi kutusu",
                    hints=HELP_ROWS,
                    repl=repl,
                    version="0.0.0",
                )
                async with app.run_test(size=(120, 40)) as pilot:
                    await pilot.pause(0.3)
                    await _submit(app, pilot, "sample.txt dosyasini oku")
                    body = _chat_text(app)
                    self.assertIn("BANANA_FILE_CONTENT", body)
                    self.assertIn("read_file", body)
                    await _submit(app, pilot, "/help")
                    self.assertIn("/preview", _chat_text(app))
                    await _submit(app, pilot, "/quit")
                    await pilot.pause(0.3)

        asyncio.run(scenario())

    def test_tui_activity_panel_follows_preview_feed(self) -> None:
        base = f"http://127.0.0.1:{self.mock.port}"

        async def scenario() -> None:
            with tempfile.TemporaryDirectory() as raw:
                cwd = Path(raw)
                home = cwd / "home"
                home.mkdir()
                (cwd / "sample.txt").write_text("BANANA_FILE_CONTENT\n", encoding="utf-8")
                config = _config(home, base)
                provider = create_provider(config, "openai")
                session = self._session(home)

                def repl() -> int:
                    runtime = _runtime(
                        ui=app.ui,
                        config=config,
                        cwd=cwd,
                        approval="yolo",
                        session=session,
                        provider=provider,
                    )
                    try:
                        return _run_repl(runtime, "test")
                    finally:
                        provider.close()

                app = BananaApp(
                    status_provider=lambda: "s",
                    info_provider=lambda: "i",
                    hints=HELP_ROWS,
                    repl=repl,
                    version="0.0.0",
                )
                async with app.run_test(size=(120, 40)) as pilot:
                    await pilot.pause(0.3)
                    panel = app.query_one("#activity")
                    self.assertTrue(panel.has_class("hidden"))
                    await _submit(app, pilot, "/preview on")
                    self.assertIn("Canli islem paneli acik", _chat_text(app))
                    self.assertFalse(app.query_one("#activity").has_class("hidden"))
                    await _submit(app, pilot, "sample.txt dosyasini oku")
                    lines = "\n".join(str(c.render()) for c in app.query_one("#activity").children)
                    self.assertIn("[call] read_file", lines)
                    await _submit(app, pilot, "/preview off")
                    self.assertTrue(app.query_one("#activity").has_class("hidden"))
                    await _submit(app, pilot, "/quit")
                    await pilot.pause(0.3)

        asyncio.run(scenario())

    def test_tui_approval_uses_input_bar(self) -> None:
        async def scenario() -> None:
            answers: list[str] = []

            def worker() -> int:
                from banana.approval import Approver

                approver = Approver(app.ui, "ask")
                answers.append(approver.allow("Dosya yaz", "out.txt: merhaba"))
                return 0

            app = BananaApp(
                status_provider=lambda: "s",
                info_provider=lambda: "i",
                hints=HELP_ROWS,
                repl=worker,
                version="0.0.0",
            )
            async with app.run_test(size=(120, 40)) as pilot:
                await pilot.pause(0.4)
                self.assertIn("Onayla?", app.query_one("#prompt", Input).prompt)
                self.assertIn("out.txt: merhaba", _chat_text(app))
                await _submit(app, pilot, "e")
                await pilot.pause(0.5)
                self.assertEqual(answers, [True])

        asyncio.run(scenario())

    def test_tui_hints_filter_slash_commands(self) -> None:
        async def scenario() -> None:
            stop = threading.Event()

            def repl() -> int:
                stop.wait()
                return 0

            app = BananaApp(
                status_provider=lambda: "s",
                info_provider=lambda: "i",
                hints=HELP_ROWS,
                repl=repl,
                version="0.0.0",
            )
            async with app.run_test(size=(120, 40)) as pilot:
                await pilot.pause(0.2)
                hints = app.query_one("#hints")
                self.assertTrue(hints.has_class("hidden"))
                await pilot.press("/", "m", "o")
                await pilot.pause(0.2)
                self.assertFalse(hints.has_class("hidden"))
                text = str(hints.render())
                self.assertIn("/model", text)
                self.assertNotIn("/voice", text)
                stop.set()
                await pilot.pause(0.3)

        asyncio.run(scenario())


if __name__ == "__main__":
    unittest.main()
