from __future__ import annotations

import os
import sys
import tempfile
import types
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.config import Config
from banana.models import Message, StreamDone, TextDelta, parse_model
from banana.net import ProviderError
from banana.providers import create_provider
from banana.providers.factory import local_model_path


class ParseModelLocalTests(unittest.TestCase):
    def test_bare_local(self) -> None:
        self.assertEqual(parse_model("local"), ("local", ""))

    def test_local_prefix(self) -> None:
        self.assertEqual(
            parse_model("local//tmp/qwen.gguf"), ("local", "/tmp/qwen.gguf")
        )

    def test_gguf_path_anywhere(self) -> None:
        self.assertEqual(parse_model("/tmp/models/phi.gguf"), ("local", "/tmp/models/phi.gguf"))

    def test_default_untouched(self) -> None:
        self.assertEqual(parse_model("gpt"), ("openai", "gpt-6.1-terra"))


class LocalFactoryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name) / "home"
        self.model = Path(self.tmp.name) / "dummy.gguf"
        self.model.write_bytes(b"GGUF")
        self.config = Config(config_path=self.home / "config.json")

    def test_local_needs_no_api_key(self) -> None:
        for key in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY", "BANANA_LOCAL_MODEL"):
            self.addCleanup(os.environ.pop, key, None)
            os.environ.pop(key, None)
        provider = create_provider(self.config, "local", model=str(self.model))
        self.assertEqual(provider.name, "local")
        self.assertEqual(provider.model_path, self.model.resolve())

    def test_missing_path_raises(self) -> None:
        with self.assertRaises(ProviderError) as ctx:
            local_model_path(self.config)
        self.assertIn("BANANA_LOCAL_MODEL", str(ctx.exception))

    def test_env_var_used(self) -> None:
        os.environ["BANANA_LOCAL_MODEL"] = str(self.model)
        self.addCleanup(os.environ.pop, "BANANA_LOCAL_MODEL", None)
        self.assertEqual(local_model_path(self.config), str(self.model))

    def test_config_path_used(self) -> None:
        self.config.local_model_path = str(self.model)
        self.assertEqual(local_model_path(self.config), str(self.model))

    def test_nonexistent_file_rejected(self) -> None:
        with self.assertRaises(ProviderError):
            create_provider(self.config, "local", model="/nope/yok.gguf")


class FakeLlama:
    def __init__(self, model_path, **kwargs):
        self.model_path = model_path
        self.kwargs = kwargs
        self.input_tokens = 10
        self.output_tokens = 3

    def create_chat_completion(self, *, messages, max_tokens, stream, temperature=None):
        def gen():
            for text in ("Mer", "haba", "!"):
                yield {"choices": [{"delta": {"content": text}}]}
            yield {"choices": [{"delta": {}}]}

        return gen()

    def close(self):
        pass


class LocalProviderStreamTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.model = Path(self.tmp.name) / "fake.gguf"
        self.model.write_bytes(b"GGUF")
        fake_module = types.ModuleType("llama_cpp")
        fake_module.Llama = FakeLlama
        self.addCleanup(sys.modules.pop, "llama_cpp", None)
        sys.modules["llama_cpp"] = fake_module

    def test_stream_yields_deltas_and_done(self) -> None:
        from banana.providers.local import LocalProvider

        provider = LocalProvider(self.model)
        events = list(
            provider.stream(
                model="fake.gguf",
                system="sys",
                messages=[Message(role="user", content="hi")],
                tools=[],
                max_tokens=16,
            )
        )
        deltas = [e for e in events if isinstance(e, TextDelta)]
        done = [e for e in events if isinstance(e, StreamDone)]
        self.assertEqual("".join(d.text for d in deltas), "Merhaba!")
        self.assertEqual(len(done), 1)
        self.assertEqual(done[0].message.content, "Merhaba!")
        self.assertEqual(done[0].usage.input_tokens, 10)
        self.assertEqual(done[0].model, "fake.gguf")

    def test_missing_dependency_message(self) -> None:
        from banana.providers.local import LocalProvider

        sys.modules["llama_cpp"] = None
        try:
            with self.assertRaises(ProviderError) as ctx:
                LocalProvider(self.model)
            self.assertIn("llama-cpp-python", str(ctx.exception))
        finally:
            fake_module = types.ModuleType("llama_cpp")
            fake_module.Llama = FakeLlama
            sys.modules["llama_cpp"] = fake_module


class GgufScanTests(unittest.TestCase):
    def test_folder_scan_finds_gguf(self) -> None:
        from banana import cli

        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            models = root / "models"
            (models / "alt").mkdir(parents=True)
            (models / "qwen.gguf").write_bytes(b"x")
            (models / "alt" / "phi.GGUF").write_bytes(b"y")
            (models / "not.txt").write_text("z")
            original = cli.GGUF_DIRS
            cli.GGUF_DIRS = (models,)
            self.addCleanup(setattr, cli, "GGUF_DIRS", original)
            found = cli._find_gguf_files()
            names = sorted(p.name for p in found)
            self.assertEqual(names, ["phi.GGUF", "qwen.gguf"])


if __name__ == "__main__":
    unittest.main()
