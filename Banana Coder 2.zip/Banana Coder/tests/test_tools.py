from __future__ import annotations

import io
import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from banana.approval import Approver
from banana.tools import ToolContext, execute_tool
from banana.ui import UI


class ToolTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.cwd = Path(self._tmp.name)
        ui = UI(
            color=False,
            one_shot=True,
            stream_output=False,
            sink=io.StringIO(),
            err=io.StringIO(),
        )
        self.ui = ui
        self.ctx = ToolContext(cwd=self.cwd, approver=Approver(ui, "yolo"))

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_write_read_edit(self) -> None:
        result = execute_tool(
            "write_file",
            {"path": "src/app.py", "content": "print('hi')\n"},
            self.ctx,
        )
        self.assertFalse(result.is_error, result.content)
        target = self.cwd / "src" / "app.py"
        self.assertTrue(target.exists())

        result = execute_tool("read_file", {"path": "src/app.py"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("1| print('hi')", result.content)

        result = execute_tool(
            "edit_file",
            {"path": "src/app.py", "old_string": "hi", "new_string": "hello"},
            self.ctx,
        )
        self.assertFalse(result.is_error, result.content)
        self.assertIn("hello", target.read_text(encoding="utf-8"))

        result = execute_tool(
            "edit_file",
            {"path": "src/app.py", "old_string": "missing", "new_string": "x"},
            self.ctx,
        )
        self.assertTrue(result.is_error)
        self.assertIn("bulunamadi", result.content)

        target.write_text("x\nx\n", encoding="utf-8")
        result = execute_tool(
            "edit_file",
            {"path": "src/app.py", "old_string": "x", "new_string": "y"},
            self.ctx,
        )
        self.assertTrue(result.is_error)
        self.assertIn("2 kez", result.content)

        result = execute_tool(
            "edit_file",
            {
                "path": "src/app.py",
                "old_string": "x",
                "new_string": "y",
                "replace_all": True,
            },
            self.ctx,
        )
        self.assertFalse(result.is_error, result.content)
        self.assertEqual(target.read_text(encoding="utf-8"), "y\ny\n")

    def test_read_errors(self) -> None:
        result = execute_tool("read_file", {"path": "missing.txt"}, self.ctx)
        self.assertTrue(result.is_error)
        self.assertIn("bulunamadi", result.content)

        (self.cwd / "sub").mkdir()
        result = execute_tool("read_file", {"path": "sub"}, self.ctx)
        self.assertTrue(result.is_error)
        self.assertIn("dizin", result.content)

        (self.cwd / "bin.dat").write_bytes(b"abc\x00def")
        result = execute_tool("read_file", {"path": "bin.dat"}, self.ctx)
        self.assertTrue(result.is_error)
        self.assertIn("Ikili", result.content)

    def test_list_glob_grep(self) -> None:
        (self.cwd / "sub").mkdir()
        (self.cwd / "a.py").write_text("needle one\n", encoding="utf-8")
        (self.cwd / "sub" / "b.py").write_text("needle two\n", encoding="utf-8")
        (self.cwd / "c.txt").write_text("nothing here\n", encoding="utf-8")

        result = execute_tool("list_dir", {}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("a.py", result.content)
        self.assertIn("sub/", result.content)

        result = execute_tool("glob", {"pattern": "**/*.py"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("a.py", result.content)
        self.assertIn("sub/b.py", result.content)

        result = execute_tool("grep", {"pattern": "needle"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("a.py:1:needle one", result.content)
        self.assertIn("sub/b.py:1:needle two", result.content)

        result = execute_tool(
            "grep", {"pattern": "nothing", "glob": "*.txt"}, self.ctx
        )
        self.assertFalse(result.is_error)
        self.assertIn("c.txt:1:", result.content)

        result = execute_tool("grep", {"pattern": "absent"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("Eslesme yok", result.content)

        result = execute_tool("grep", {"pattern": "["}, self.ctx)
        self.assertTrue(result.is_error)
        self.assertIn("Gecersiz regex", result.content)

    def test_bash(self) -> None:
        result = execute_tool("bash", {"command": "printf hello"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("exit_code: 0", result.content)
        self.assertIn("hello", result.content)

        result = execute_tool("bash", {"command": "exit 3"}, self.ctx)
        self.assertFalse(result.is_error)
        self.assertIn("exit_code: 3", result.content)

    def test_readonly_mode_denies_mutations(self) -> None:
        ctx = ToolContext(
            cwd=self.cwd, approver=Approver(self.ui, "readonly")
        )
        result = execute_tool(
            "write_file", {"path": "blocked.txt", "content": "x"}, ctx
        )
        self.assertTrue(result.is_error)
        self.assertIn("reddetti", result.content)
        self.assertFalse((self.cwd / "blocked.txt").exists())

        result = execute_tool("bash", {"command": "touch blocked2.txt"}, ctx)
        self.assertTrue(result.is_error)
        self.assertIn("reddetti", result.content)

        (self.cwd / "ok.txt").write_text("ok\n", encoding="utf-8")
        result = execute_tool("read_file", {"path": "ok.txt"}, ctx)
        self.assertFalse(result.is_error)

    def test_full_access_outside_working_directory(self) -> None:
        with tempfile.TemporaryDirectory() as other_raw:
            other = Path(other_raw)
            file_path = other / "outside.txt"
            file_path.write_text("outside content\n", encoding="utf-8")

            result = execute_tool(
                "read_file", {"path": str(file_path)}, self.ctx
            )
            self.assertFalse(result.is_error)
            self.assertIn("outside content", result.content)

            result = execute_tool(
                "write_file",
                {"path": str(other / "created.txt"), "content": "created\n"},
                self.ctx,
            )
            self.assertFalse(result.is_error)
            self.assertTrue((other / "created.txt").exists())

    def test_unknown_tool_and_limits(self) -> None:
        result = execute_tool("nope", {}, self.ctx)
        self.assertTrue(result.is_error)
        self.assertIn("Bilinmeyen arac", result.content)

        (self.cwd / "long.txt").write_text(
            "\n".join(f"line {index}" for index in range(50)) + "\n",
            encoding="utf-8",
        )
        ctx = ToolContext(
            cwd=self.cwd,
            approver=Approver(self.ui, "yolo"),
            output_limit=80,
        )
        result = execute_tool("read_file", {"path": "long.txt"}, ctx)
        self.assertFalse(result.is_error)
        self.assertIn("devam etmek icin offset=", result.content)


if __name__ == "__main__":
    unittest.main()
