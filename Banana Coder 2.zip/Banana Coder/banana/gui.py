"""PyQt5 tabanli masaustu IDE.

Tasarim Fluent ilkelerini izler: yumusak kartlar, katmanli yuzeyler,
vurgu rengi olarak banana sari, monospace editor ve sagda sohbet paneli.
Harici tema paketi gerektirmez; tum gorunum QSS ve QPainter ile uretilir.
"""

from __future__ import annotations

import html
import os
import queue
import re
import sys
import threading
import traceback
from pathlib import Path

from PyQt5.QtCore import (
    QEasingCurve,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QRegExp,
    QSettings,
    QSize,
    Qt,
    QTimer,
    pyqtSignal,
)
from PyQt5.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontDatabase,
    QFontMetricsF,
    QIcon,
    QKeySequence,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPalette,
    QPen,
    QPixmap,
    QSyntaxHighlighter,
    QTextCharFormat,
    QTextCursor,
    QTextFormat,
    QTextOption,
)
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QShortcut,
    QSizePolicy,
    QSplitter,
    QStackedWidget,
    QTabBar,
    QTabWidget,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from banana import __version__, preview
from banana.cli import (
    Runtime,
    _expand_file_refs,
    _handle_slash,
    _model_label,
    _prepare_runtime,
    _remember_tool_support,
    _run_bang,
    _speak_turn,
)
from banana.config import APP_HOME
from banana.net import ProviderError
from banana.ui import Text, UI

BG = "#141416"
SURFACE = "#1b1b1f"
CARD = "#1c1c20"
CARD_ALT = "#26262c"
EDITOR_BG = "#161619"
FG = "#e7e7ec"
MUTED = "#92929c"
ACCENT = "#f5c542"
ACCENT_DIM = "#3a3420"
ACCENT_LIGHT = "#ffd45e"
ACCENT_DARK = "#e0b234"
ACCENT_SOFT = "#262318"
BUBBLE_USER_BG = "#2d2a1c"
BUBBLE_USER_FG = "#f2e6c4"
CYAN = "#6ec7ff"
GREEN = "#7ddc7d"
RED = "#ff6b6b"
WARN = "#e5c07b"
THINK = "#a48be0"
BORDER = "#303038"
SELECT = "#4a4326"

UI_FONT = "SF Pro Text"
MONO_FONT = "SF Mono"

# (aksan, koyu ton, gorunen ad)
ACCENT_PRESETS: dict[str, tuple[str, str, str]] = {
    "banana": ("#f5c542", "#3a3420", "Banana"),
    "mint": ("#4fd1a5", "#1c3a31", "Nane"),
    "sky": ("#5aa9ff", "#1d2f44", "Gokyuzu"),
    "rose": ("#f2779a", "#3b2230", "Gul"),
    "violet": ("#a78bfa", "#2d2545", "Menekse"),
}


def _mix(first: str, second: str, ratio: float) -> str:
    ratio = max(0.0, min(1.0, ratio))
    a = QColor(first)
    b = QColor(second)
    return QColor(
        round(a.red() + (b.red() - a.red()) * ratio),
        round(a.green() + (b.green() - a.green()) * ratio),
        round(a.blue() + (b.blue() - a.blue()) * ratio),
    ).name()


def set_accent_tokens(name: str) -> None:
    global ACCENT, ACCENT_DIM, ACCENT_LIGHT, ACCENT_DARK, ACCENT_SOFT
    global BUBBLE_USER_BG, BUBBLE_USER_FG, SELECT
    accent, dim, _label = ACCENT_PRESETS.get(
        name, ACCENT_PRESETS["banana"]
    )
    ACCENT = accent
    ACCENT_DIM = dim
    ACCENT_LIGHT = _mix(accent, "#ffffff", 0.22)
    ACCENT_DARK = _mix(accent, "#000000", 0.16)
    ACCENT_SOFT = _mix("#202026", accent, 0.10)
    BUBBLE_USER_BG = _mix("#202026", accent, 0.14)
    BUBBLE_USER_FG = _mix("#e7e7ec", accent, 0.18)
    SELECT = _mix("#303038", accent, 0.34)


def prefs() -> QSettings:
    try:
        APP_HOME.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return QSettings(str(APP_HOME / "gui.ini"), QSettings.IniFormat)


def motion_allowed() -> bool:
    app = QApplication.instance()
    if app is not None and app.platformName() == "offscreen":
        return False
    if os.environ.get("BANANA_NO_MOTION"):
        return False
    try:
        return bool(prefs().value("ui/motion", True, type=bool))
    except Exception:
        return True


def apply_accent(app: QApplication, name: str) -> None:
    set_accent_tokens(name)
    palette = app.palette()
    palette.setColor(QPalette.Highlight, QColor(SELECT))
    palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    app.setPalette(palette)
    _ICON_CACHE.clear()
    app.setStyleSheet(build_qss())
    prefs().setValue("theme/accent", name)


MAX_FILE_BYTES = 2_000_000
SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    "dist",
    "build",
}

def build_qss() -> str:
    return """
QWidget {
    color: %(FG)s;
    font-size: 12px;
}
QWidget#Root, QMainWindow, QDialog {
    background: %(BG)s;
}
QLabel {
    background: transparent;
}
QFrame#Header {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #1e1e23, stop:0.55 #19191d, stop:1 #1d1d22);
    border-bottom: 1px solid #2a2a31;
}
QLabel#Brand {
    color: %(ACCENT)s;
    font-size: 20px;
    font-weight: 700;
}
QLabel#VersionChip {
    color: %(MUTED)s;
    font-size: 10px;
    padding: 2px 8px;
    border: 1px solid #34343c;
    border-radius: 8px;
}
QFrame#HeaderSep {
    background: %(BORDER)s;
}
QPushButton#GhostButton {
    background: #202026;
    color: #d8d8de;
    border: 1px solid #2b2b33;
    border-radius: 8px;
    padding: 7px 12px;
    font-size: 12px;
}
QPushButton#GhostButton:hover {
    background: #2a2a31;
    border-color: #3a3a43;
}
QPushButton#GhostButton:pressed {
    background: #33333c;
}
QPushButton#GhostButton:focus, QPushButton#Suggestion:focus,
QPushButton#AccentButton:focus, QPushButton#DangerButton:focus {
    border: 1px solid %(ACCENT)s;
}
QPushButton#AccentButton {
    background: %(ACCENT)s;
    color: #1a1a1d;
    border: none;
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
    font-size: 12px;
}
QPushButton#AccentButton:hover {
    background: %(ACCENT_LIGHT)s;
}
QPushButton#AccentButton:pressed {
    background: %(ACCENT_DARK)s;
}
QPushButton#AccentButton:disabled {
    background: %(ACCENT_DIM)s;
    color: #8c8c92;
}
QPushButton#DangerButton {
    background: #3a2224;
    color: #ff8f8f;
    border: 1px solid #533033;
    border-radius: 8px;
    padding: 7px 14px;
}
QPushButton#DangerButton:hover {
    background: #4a2a2d;
}
QPushButton#IconButton {
    background: transparent;
    color: %(MUTED)s;
    border: none;
    border-radius: 7px;
    padding: 4px 9px;
    font-size: 11px;
}
QPushButton#IconButton:hover {
    background: #2a2a31;
    color: %(FG)s;
}
QLabel#ModelChip {
    color: %(ACCENT)s;
    background: %(ACCENT_SOFT)s;
    border: 1px solid %(ACCENT_DIM)s;
    border-radius: 9px;
    padding: 4px 10px;
    font-size: 11px;
}
QLabel#FieldLabel {
    color: %(MUTED)s;
    font-size: 11px;
}
QFrame#Card {
    background: %(CARD)s;
    border: 1px solid #2b2b32;
    border-radius: 14px;
}
QLabel#SectionTitle {
    color: #8b8b95;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1.2px;
}
QLabel#CardHint {
    color: #66666f;
    font-size: 10px;
}
QLabel#ModelDot, QLabel#StatusDot {
    background: #5f5f69;
    border-radius: 4px;
}
QLabel#ModelDot[state="idle"], QLabel#StatusDot[state="idle"] {
    background: %(GREEN)s;
}
QLabel#ModelDot[state="busy"], QLabel#StatusDot[state="busy"] {
    background: %(ACCENT)s;
}
QLabel#ModelDot[state="off"], QLabel#StatusDot[state="off"] {
    background: #5f5f69;
}
QFrame#TreeSurface {
    background: #17171a;
    border: 1px solid #26262c;
    border-radius: 10px;
}
QLabel#RootName {
    color: #c9c9cf;
    font-size: 11px;
    font-weight: 600;
}
QLabel#CountChip {
    color: #8b8b95;
    background: #202026;
    border: 1px solid #2c2c34;
    border-radius: 7px;
    padding: 1px 6px;
    font-size: 10px;
}
QFrame#EditorStrip {
    background: transparent;
    border-top: 1px solid #232329;
}
QLabel#EditorMeta {
    color: #6f6f78;
    font-size: 10px;
}
QLabel#LangChip {
    color: %(CYAN)s;
    background: #172026;
    border: 1px solid #24333d;
    border-radius: 6px;
    padding: 1px 7px;
    font-size: 10px;
}
QPushButton#Suggestion {
    background: #222228;
    color: #d6d6dc;
    border: 1px solid #2f2f37;
    border-radius: 9px;
    padding: 9px 12px;
    text-align: left;
    font-size: 11px;
}
QPushButton#Suggestion:hover {
    background: #2b2b33;
    border-color: %(ACCENT_DIM)s;
    color: %(ACCENT)s;
}
QPushButton#Suggestion:pressed {
    background: #33333c;
}
QFrame#ChatWelcome {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 %(ACCENT_SOFT)s, stop:1 #191920);
    border: 1px solid #2f2f37;
    border-radius: 14px;
}
QLabel#ChatWelcomeTitle {
    color: #f0f0f4;
    font-size: 15px;
    font-weight: 600;
}
QLabel#ChatWelcomeSub {
    color: %(MUTED)s;
    font-size: 11px;
}
QLabel#ChatWelcomeHint {
    color: #6f6f78;
    font-size: 10px;
}
QLabel#CwdText {
    color: #6b6b74;
    font-size: 11px;
}
QSplitter::handle {
    background: transparent;
}
QSplitter::handle:hover {
    background: #2a2a31;
    border-radius: 3px;
}
QTreeWidget {
    background: transparent;
    border: none;
    color: #d6d6dc;
    font-size: 12px;
    outline: none;
}
QTreeWidget::item {
    padding: 5px 4px;
    border-radius: 6px;
}
QTreeWidget::item:hover {
    background: #26262c;
}
QTreeWidget::item:selected {
    background: %(ACCENT_DIM)s;
    color: %(ACCENT)s;
}
QTreeWidget::branch {
    background: transparent;
}
QTabWidget#EditorTabs::pane {
    border: none;
    background: %(EDITOR_BG)s;
    border-radius: 10px;
}
QTabBar::tab {
    background: transparent;
    color: #8b8b95;
    padding: 7px 14px;
    margin-right: 4px;
    border-radius: 7px;
    border-bottom: 2px solid transparent;
    font-size: 11px;
}
QTabBar::tab:hover {
    background: #26262c;
    color: #d6d6dc;
}
QTabBar::tab:selected {
    background: #26262c;
    color: %(ACCENT)s;
    border-bottom: 2px solid %(ACCENT)s;
}
QPlainTextEdit {
    background: %(EDITOR_BG)s;
    color: %(FG)s;
    border: none;
    selection-background-color: %(SELECT)s;
    selection-color: #ffffff;
}
QScrollBar:vertical {
    background: transparent;
    width: 10px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: #3a3a43;
    min-height: 30px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #4a4a55;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: transparent;
}
QScrollBar:horizontal {
    background: transparent;
    height: 10px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background: #3a3a43;
    min-width: 30px;
    border-radius: 4px;
}
QScrollBar::handle:horizontal:hover {
    background: #4a4a55;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    background: transparent;
}
QScrollArea#ChatView {
    background: transparent;
    border: none;
}
QWidget#ChatSurface {
    background: transparent;
}
QFrame#BubbleUser {
    background: %(BUBBLE_USER_BG)s;
    border: 1px solid %(ACCENT_DIM)s;
    border-radius: 12px;
}
QFrame#BubbleAssistant {
    background: #202026;
    border: 1px solid #2d2d35;
    border-radius: 12px;
}
QFrame#BubbleAssistant[streaming="true"] {
    border: 1px solid %(ACCENT)s;
}
QFrame#BubbleThinking {
    background: #1c1a24;
    border: 1px dashed #3a3450;
    border-radius: 12px;
}
QLabel#BubbleText {
    background: transparent;
    color: %(FG)s;
    font-size: 12px;
}
QFrame#BubbleUser QLabel#BubbleText {
    color: %(BUBBLE_USER_FG)s;
}
QFrame#BubbleThinking QLabel#BubbleText {
    color: %(THINK)s;
}
QLabel#RawLine {
    background: transparent;
    color: #b8b8c2;
    border-left: 2px solid transparent;
    padding-left: 8px;
    font-size: 11px;
}
QLabel#RawLine[role="tool"] {
    color: %(CYAN)s;
    border-left-color: %(CYAN)s;
}
QLabel#RawLine[role="muted"] {
    color: #8f8f99;
    border-left-color: #34343c;
}
QLabel#RawLine[role="warn"] {
    color: %(WARN)s;
    border-left-color: %(WARN)s;
}
QLabel#RawLine[role="error"] {
    color: %(RED)s;
    border-left-color: %(RED)s;
}
QLabel#RawLine[role="ok"] {
    color: %(GREEN)s;
    border-left-color: %(GREEN)s;
}
QLabel#RawLine[role="fail"] {
    color: %(RED)s;
    border-left-color: %(RED)s;
}
QLabel#RawLine[role="header"] {
    color: %(ACCENT)s;
    border-left-color: %(ACCENT)s;
    font-weight: 600;
}
QFrame#Composer {
    background: #19191d;
    border: 1px solid %(BORDER)s;
    border-radius: 12px;
}
QFrame#Composer[focused="true"] {
    border: 1px solid %(ACCENT)s;
}
QPlainTextEdit#ComposerEdit {
    background: transparent;
    color: %(FG)s;
    border: none;
    selection-background-color: %(SELECT)s;
    selection-color: #ffffff;
    padding: 2px;
}
QLabel#Hint {
    color: #6f6f78;
    font-size: 10px;
}
QFrame#StatusBar {
    background: #111113;
    border-top: 1px solid #26262c;
}
QLabel#StatusText {
    color: %(MUTED)s;
    font-size: 11px;
}
QLabel#ActivityText {
    color: #6b6b74;
    font-size: 11px;
}
QLabel#UsageText {
    color: %(MUTED)s;
    font-size: 11px;
}
QComboBox {
    background: #222228;
    color: #d6d6dc;
    border: 1px solid #34343c;
    border-radius: 8px;
    padding: 5px 10px;
    font-size: 11px;
    min-width: 68px;
}
QComboBox:hover {
    border-color: #45454f;
}
QComboBox::drop-down {
    border: none;
    width: 20px;
}
QComboBox::down-arrow {
    width: 0;
    height: 0;
}
QComboBox QAbstractItemView {
    background: #202026;
    color: #d6d6dc;
    border: 1px solid #34343c;
    selection-background-color: %(ACCENT_DIM)s;
    selection-color: %(ACCENT)s;
    outline: none;
    padding: 4px;
}
QCheckBox {
    color: #c9c9cf;
    font-size: 11px;
    spacing: 6px;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid #3a3a43;
    background: #1a1a1e;
}
QCheckBox::indicator:hover {
    border-color: %(ACCENT)s;
}
QCheckBox::indicator:checked {
    background: %(ACCENT)s;
    border-color: %(ACCENT)s;
}
QDialog#FluentDialog {
    background: #1c1c20;
}
QLabel#DialogTitle {
    color: %(ACCENT)s;
    font-size: 15px;
    font-weight: 700;
}
QLabel#DialogBody {
    color: #d6d6dc;
    font-size: 12px;
}
QLineEdit {
    background: #141417;
    color: %(FG)s;
    border: 1px solid #34343c;
    border-radius: 8px;
    padding: 8px 10px;
    font-size: 12px;
    selection-background-color: %(SELECT)s;
}
QLineEdit:focus {
    border-color: %(ACCENT)s;
}
QListWidget {
    background: #151518;
    color: #d6d6dc;
    border: 1px solid #2d2d35;
    border-radius: 8px;
    outline: none;
    padding: 4px;
    font-size: 11px;
}
QListWidget::item {
    padding: 6px 8px;
    border-radius: 6px;
}
QListWidget::item:hover {
    background: #26262c;
}
QListWidget::item:selected {
    background: %(ACCENT_DIM)s;
    color: %(ACCENT)s;
}
QWidget#WelcomePage {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #19191e, stop:0.6 #161619, stop:1 #131316);
}
QLabel#WelcomeTitle {
    color: #f0f0f4;
    font-size: 26px;
    font-weight: 700;
}
QLabel#WelcomeSub {
    color: %(MUTED)s;
    font-size: 12px;
}
QFrame#WelcomeCard {
    background: #1e1e23;
    border: 1px solid #2d2d35;
    border-radius: 10px;
}
QLabel#Kbd {
    color: %(ACCENT)s;
    background: %(ACCENT_SOFT)s;
    border: 1px solid %(ACCENT_DIM)s;
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 11px;
}
QLabel#WelcomeText {
    color: #c9c9cf;
    font-size: 12px;
}
QToolTip {
    background: #26262c;
    color: %(FG)s;
    border: 1px solid #3a3a43;
    padding: 5px 8px;
    border-radius: 6px;
}
QPushButton#IconButton[active="true"] {
    background: %(ACCENT_SOFT)s;
    color: %(ACCENT)s;
}
QLabel#ModeChip {
    color: %(MUTED)s;
    background: #202026;
    border: 1px solid #2c2c34;
    border-radius: 6px;
    padding: 1px 7px;
    font-size: 10px;
}
QLabel#ModeChip[role="chat"] {
    color: %(GREEN)s;
    border-color: #26362a;
}
QLabel#ModeChip[role="command"] {
    color: %(ACCENT)s;
    background: %(ACCENT_SOFT)s;
    border-color: %(ACCENT_DIM)s;
}
QLabel#ModeChip[role="shell"] {
    color: %(CYAN)s;
    background: #172026;
    border-color: #24333d;
}
QDialog#PaletteDialog {
    background: #1c1c20;
    border: 1px solid #3a3a43;
    border-radius: 14px;
}
QLabel#PaletteTitle {
    color: #f0f0f4;
    font-size: 13px;
    font-weight: 600;
}
QLabel#PaletteHint {
    color: #6f6f78;
    font-size: 10px;
}
QLineEdit#PaletteInput {
    background: #141417;
    color: %(FG)s;
    border: 1px solid #34343c;
    border-radius: 9px;
    padding: 10px 12px;
    font-size: 13px;
}
QLineEdit#PaletteInput:focus {
    border-color: %(ACCENT)s;
}
QListWidget#PaletteList {
    background: transparent;
    border: none;
    outline: none;
    padding: 0;
    font-size: 12px;
}
QListWidget#PaletteList::item {
    padding: 7px 10px;
    border-radius: 8px;
    color: #d6d6dc;
}
QListWidget#PaletteList::item:hover {
    background: #26262c;
}
QListWidget#PaletteList::item:selected {
    background: %(ACCENT_DIM)s;
    color: %(ACCENT)s;
}
QFrame#Toast {
    background: #232329;
    border: 1px solid #3a3a43;
    border-radius: 10px;
}
QFrame#Toast[kind="ok"] {
    border-color: #2f4a33;
}
QFrame#Toast[kind="warn"] {
    border-color: #4d4327;
}
QFrame#Toast[kind="error"] {
    border-color: #523033;
}
QLabel#ToastText {
    color: %(FG)s;
    font-size: 11px;
}
QLabel#ToastTime {
    color: #6f6f78;
    font-size: 10px;
}
QDialog#SettingsDialog {
    background: #1c1c20;
}
QWidget#SettingsPage {
    background: transparent;
}
QLabel#SettingsHeading {
    color: #f0f0f4;
    font-size: 16px;
    font-weight: 700;
}
QLabel#SettingsBody {
    color: %(MUTED)s;
    font-size: 11px;
}
QFrame#SettingsCard {
    background: #202026;
    border: 1px solid #2d2d35;
    border-radius: 10px;
}
QLabel#SettingsLabel {
    color: #d6d6dc;
    font-size: 12px;
}
QLabel#SettingsHint {
    color: #6f6f78;
    font-size: 10px;
}
QListWidget#SettingsNav {
    background: #17171a;
    border: 1px solid #26262c;
    border-radius: 10px;
    outline: none;
    padding: 5px;
    font-size: 12px;
}
QListWidget#SettingsNav::item {
    padding: 9px 10px;
    border-radius: 7px;
    color: #b8b8c2;
}
QListWidget#SettingsNav::item:hover {
    background: #222228;
    color: %(FG)s;
}
QListWidget#SettingsNav::item:selected {
    background: %(ACCENT_DIM)s;
    color: %(ACCENT)s;
}
QPushButton#Swatch {
    border: 2px solid transparent;
    border-radius: 10px;
}
QPushButton#Swatch:focus {
    border-color: %(FG)s;
}
QLabel#SwatchName {
    color: %(MUTED)s;
    font-size: 10px;
}
QLabel#ShortcutKey {
    color: %(ACCENT)s;
    background: %(ACCENT_SOFT)s;
    border: 1px solid %(ACCENT_DIM)s;
    border-radius: 6px;
    padding: 2px 8px;
    font-size: 11px;
}
""" % {
    "BG": BG,
    "FG": FG,
    "MUTED": MUTED,
    "ACCENT": ACCENT,
    "ACCENT_DIM": ACCENT_DIM,
    "ACCENT_LIGHT": ACCENT_LIGHT,
    "ACCENT_DARK": ACCENT_DARK,
    "ACCENT_SOFT": ACCENT_SOFT,
    "BUBBLE_USER_BG": BUBBLE_USER_BG,
    "BUBBLE_USER_FG": BUBBLE_USER_FG,
    "CARD": CARD,
    "EDITOR_BG": EDITOR_BG,
    "BORDER": BORDER,
    "SELECT": SELECT,
    "CYAN": CYAN,
    "GREEN": GREEN,
    "RED": RED,
    "WARN": WARN,
    "THINK": THINK,
}


UI_QSS = build_qss()

_INLINE_CODE = re.compile(r"`([^`\n]+)`")
_BOLD = re.compile(r"\*\*([^*\n]+)\*\*")
_ITALIC = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_HEADING = re.compile(r"^(#{1,4})\s+(.*)$")
_BULLET = re.compile(r"^\s*[-*]\s+(.*)$")
_QUOTE = re.compile(r"^\s*>\s?(.*)$")
_CODE_SPAN = re.compile("\x00(\\d+)\x00")


def _escape(value: str) -> str:
    return html.escape(str(value), quote=False)


def _code_block(lines: list[str]) -> str:
    body = _escape("\n".join(lines))
    body = body.replace("\t", "    ").replace(" ", "&#160;").replace("\n", "<br>")
    return (
        '<div style="background-color:#101013; color:#cfcfd6; '
        "font-family:Menlo,Consolas,'DejaVu Sans Mono',monospace; font-size:11px; "
        'padding:8px 10px; margin:5px 0; border-radius:8px;">'
        + body
        + "</div>"
    )


def _inline_markup(text: str) -> str:
    codes: list[str] = []

    def keep(match: re.Match) -> str:
        codes.append(match.group(1))
        return "\x00%d\x00" % (len(codes) - 1)

    text = _INLINE_CODE.sub(keep, text)
    text = _BOLD.sub(
        lambda m: '<span style="font-weight:600; color:#ffffff;">%s</span>'
        % m.group(1),
        text,
    )
    text = _ITALIC.sub(
        lambda m: '<span style="font-style:italic; color:#c9c9d2;">%s</span>'
        % m.group(1),
        text,
    )

    def restore(match: re.Match) -> str:
        index = int(match.group(1))
        body = codes[index] if index < len(codes) else ""
        body = body.replace("\t", "    ").replace(" ", "&#160;")
        return (
            "<span style=\"font-family:Menlo,Consolas,'DejaVu Sans Mono',monospace; "
            'background-color:#101014; color:#f0d98a;">' + body + "</span>"
        )

    return _CODE_SPAN.sub(restore, text)


def render_markdown(text: str) -> str:
    """Model ciktisini QLabel'in anlayacagi zengin metne cevir."""
    lines = str(text).split("\n")
    blocks: list[str] = []
    in_code = False
    code_lines: list[str] = []

    for line in lines:
        if line.strip().startswith("```"):
            if in_code:
                blocks.append(_code_block(code_lines))
                code_lines = []
                in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code_lines.append(line)
            continue
        stripped = line.strip()
        if not stripped:
            blocks.append('<div style="height:6px;"></div>')
            continue
        heading = _HEADING.match(stripped)
        if heading:
            level = len(heading.group(1))
            size = {1: 19, 2: 17, 3: 15, 4: 13}.get(level, 13)
            blocks.append(
                '<div style="font-size:%dpx; font-weight:600; color:#ffffff; '
                'margin:6px 0 2px 0;">%s</div>'
                % (size, _inline_markup(_escape(heading.group(2))))
            )
            continue
        bullet = _BULLET.match(line)
        if bullet:
            blocks.append(
                '<div style="margin:2px 0 2px 4px;">&#8226;&#160;%s</div>'
                % _inline_markup(_escape(bullet.group(1)))
            )
            continue
        quote = _QUOTE.match(line)
        if quote:
            blocks.append(
                '<div style="color:#a6a6b0; margin:3px 0;">%s</div>'
                % _inline_markup(_escape(quote.group(1)))
            )
            continue
        blocks.append(
            '<div style="margin:1px 0;">%s</div>' % _inline_markup(_escape(line))
        )

    if in_code:
        blocks.append(_code_block(code_lines))
    return "".join(blocks)


def _render_plain(text: str) -> str:
    body = _escape(text)
    body = body.replace("\t", "    ").replace("  ", "&#160;&#160;")
    return body.replace("\n", "<br>")


def _shorten(text: str, limit: int) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def _make_font(family: str, size: int, weight=QFont.Normal) -> QFont:
    font = QFont()
    if family == MONO_FONT:
        system = QFontDatabase.systemFont(QFontDatabase.FixedFont).family()
        fallback = ["SF Mono", "Menlo", "Consolas", "DejaVu Sans Mono", "Courier New"]
    else:
        system = QFontDatabase.systemFont(QFontDatabase.GeneralFont).family()
        fallback = ["SF Pro Text", "Helvetica Neue", "Helvetica", "Segoe UI", "Arial"]
    font.setFamilies([system] if system else fallback)
    font.setPointSize(size)
    font.setWeight(weight)
    return font


def _configure_application(app: QApplication) -> None:
    app.setStyle("Fusion")
    try:
        saved = str(prefs().value("theme/accent", "banana"))
    except Exception:
        saved = "banana"
    set_accent_tokens(saved)
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(BG))
    palette.setColor(QPalette.Base, QColor(EDITOR_BG))
    palette.setColor(QPalette.AlternateBase, QColor(CARD))
    palette.setColor(QPalette.WindowText, QColor(FG))
    palette.setColor(QPalette.Text, QColor(FG))
    palette.setColor(QPalette.Button, QColor(CARD))
    palette.setColor(QPalette.ButtonText, QColor(FG))
    palette.setColor(QPalette.Highlight, QColor(SELECT))
    palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    palette.setColor(QPalette.ToolTipBase, QColor(CARD_ALT))
    palette.setColor(QPalette.ToolTipText, QColor(FG))
    app.setPalette(palette)
    app.setFont(_make_font(UI_FONT, 12))
    app.setStyleSheet(build_qss())


def _paint_glyph(painter: QPainter, name: str, color: str) -> None:
    """24x24 izgarada ince cizgili ikon cizer."""
    pen = QPen(QColor(color))
    pen.setWidthF(1.8)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)

    if name == "folder":
        path = QPainterPath()
        path.moveTo(3.2, 7.4)
        path.lineTo(9.4, 7.4)
        path.lineTo(11.4, 9.4)
        path.lineTo(20.8, 9.4)
        path.lineTo(20.8, 19)
        path.lineTo(3.2, 19)
        path.closeSubpath()
        painter.drawPath(path)
    elif name == "file":
        path = QPainterPath()
        path.moveTo(6, 3.6)
        path.lineTo(14.2, 3.6)
        path.lineTo(19, 8.4)
        path.lineTo(19, 20.4)
        path.lineTo(6, 20.4)
        path.closeSubpath()
        painter.drawPath(path)
        fold = QPainterPath()
        fold.moveTo(14.2, 3.6)
        fold.lineTo(14.2, 8.4)
        fold.lineTo(19, 8.4)
        painter.drawPath(fold)
    elif name == "plus":
        painter.drawLine(QPoint(12, 5), QPoint(12, 19))
        painter.drawLine(QPoint(5, 12), QPoint(19, 12))
    elif name == "save":
        path = QPainterPath()
        path.moveTo(4.6, 4.6)
        path.lineTo(16.4, 4.6)
        path.lineTo(19.4, 7.6)
        path.lineTo(19.4, 19.4)
        path.lineTo(4.6, 19.4)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawRect(QRectF(8.2, 4.6, 7.2, 4.8))
        painter.drawRect(QRectF(7.6, 13.2, 8.8, 6.2))
    elif name == "close":
        painter.drawLine(QPoint(7, 7), QPoint(17, 17))
        painter.drawLine(QPoint(17, 7), QPoint(7, 17))
    elif name == "refresh":
        path = QPainterPath()
        path.arcMoveTo(QRectF(5, 5, 14, 14), 60)
        path.arcTo(QRectF(5, 5, 14, 14), 60, 280)
        painter.drawPath(path)
        arrow = QPainterPath()
        arrow.moveTo(14.4, 3.4)
        arrow.lineTo(18.4, 5.4)
        arrow.lineTo(15.8, 8.8)
        painter.drawPath(arrow)
    elif name == "search":
        painter.drawEllipse(QRectF(4.5, 4.5, 11, 11))
        painter.drawLine(QPoint(14, 14), QPoint(19, 19))
    elif name == "terminal":
        painter.drawRoundedRect(QRectF(3, 4.6, 18, 14.8), 2.6, 2.6)
        path = QPainterPath()
        path.moveTo(7, 10)
        path.lineTo(10.2, 12.6)
        path.lineTo(7, 15.2)
        painter.drawPath(path)
        painter.drawLine(QPoint(12, 15), QPoint(17, 15))
    elif name == "spark":
        path = QPainterPath()
        path.moveTo(12, 3)
        path.quadTo(13.4, 10.6, 21, 12)
        path.quadTo(13.4, 13.4, 12, 21)
        path.quadTo(10.6, 13.4, 3, 12)
        path.quadTo(10.6, 10.6, 12, 3)
        painter.setBrush(QBrush(QColor(color)))
        painter.setPen(Qt.NoPen)
        painter.drawPath(path)
    elif name == "user":
        painter.drawEllipse(QRectF(8, 4.4, 8, 8))
        path = QPainterPath()
        path.moveTo(4.6, 20.2)
        path.cubicTo(4.6, 15.4, 19.4, 15.4, 19.4, 20.2)
        painter.drawPath(path)
    elif name == "check":
        path = QPainterPath()
        path.moveTo(5, 12.6)
        path.lineTo(9.8, 17.4)
        path.lineTo(19, 7)
        painter.drawPath(path)
    elif name == "arrow-up":
        painter.drawLine(QPoint(12, 19), QPoint(12, 5))
        path = QPainterPath()
        path.moveTo(6, 11.4)
        path.lineTo(12, 5.4)
        path.lineTo(18, 11.4)
        painter.drawPath(path)
    elif name == "copy":
        painter.drawRoundedRect(QRectF(8.4, 8.4, 11.2, 11.2), 2.4, 2.4)
        path = QPainterPath()
        path.moveTo(15.6, 5)
        path.lineTo(7, 5)
        path.lineTo(5, 7)
        path.lineTo(5, 15.6)
        painter.drawPath(path)
    elif name == "chevron-right":
        path = QPainterPath()
        path.moveTo(9.6, 6.4)
        path.lineTo(15.2, 12)
        path.lineTo(9.6, 17.6)
        painter.drawPath(path)
    elif name == "sliders":
        for y, knob in ((7, 9), (12, 15), (17, 7)):
            painter.drawLine(QPoint(4, y), QPoint(20, y))
            painter.setBrush(QBrush(QColor(color)))
            painter.drawEllipse(QRectF(knob - 2.1, y - 2.1, 4.2, 4.2))
            painter.setBrush(Qt.NoBrush)
    elif name == "panel":
        painter.drawRoundedRect(QRectF(3.4, 4.6, 17.2, 14.8), 2.6, 2.6)
        painter.drawLine(QPoint(9, 5), QPoint(9, 19))
    elif name == "alert":
        path = QPainterPath()
        path.moveTo(12, 4.2)
        path.lineTo(20.6, 19.2)
        path.lineTo(3.4, 19.2)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawLine(QPoint(12, 9.4), QPoint(12, 13.8))
        painter.drawPoint(QPoint(12, 16.4))
    elif name == "info":
        painter.drawEllipse(QRectF(4.5, 4.5, 15, 15))
        painter.drawLine(QPoint(12, 10.6), QPoint(12, 16.2))
        painter.drawPoint(QPoint(12, 7.8))


_ICON_CACHE: dict[tuple[str, str, int], QIcon] = {}


def _line_icon(name: str, color: str = MUTED, size: int = 16) -> QIcon:
    key = (name, color, size)
    cached = _ICON_CACHE.get(key)
    if cached is not None:
        return cached
    scale = 2
    pixmap = QPixmap(size * scale, size * scale)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.scale(size * scale / 24.0, size * scale / 24.0)
    _paint_glyph(painter, name, color)
    painter.end()
    pixmap.setDevicePixelRatio(scale)
    icon = QIcon(pixmap)
    _ICON_CACHE[key] = icon
    return icon


_FILE_COLORS = {
    ".py": CYAN,
    ".pyw": CYAN,
    ".md": THINK,
    ".rst": THINK,
    ".json": WARN,
    ".toml": WARN,
    ".yaml": WARN,
    ".yml": WARN,
    ".ini": WARN,
    ".cfg": WARN,
    ".txt": MUTED,
    ".log": MUTED,
    ".html": "#e8916a",
    ".css": "#7fb4ff",
    ".js": "#e8d06a",
    ".ts": "#7fb4ff",
    ".sh": GREEN,
    ".zsh": GREEN,
    ".png": GREEN,
    ".jpg": GREEN,
    ".jpeg": GREEN,
    ".gif": GREEN,
    ".webp": GREEN,
    ".svg": GREEN,
}


def _file_icon(path: Path) -> QIcon:
    if path.is_dir():
        return _line_icon("folder", "#c2a95a", 15)
    color = _FILE_COLORS.get(path.suffix.lower(), "#9a9aa4")
    return _line_icon("file", color, 15)


_LANGUAGES = {
    ".py": "Python",
    ".pyw": "Python",
    ".md": "Markdown",
    ".rst": "reStructuredText",
    ".json": "JSON",
    ".toml": "TOML",
    ".yaml": "YAML",
    ".yml": "YAML",
    ".ini": "INI",
    ".cfg": "INI",
    ".txt": "Metin",
    ".log": "Log",
    ".html": "HTML",
    ".css": "CSS",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".sh": "Shell",
    ".zsh": "Shell",
    ".rs": "Rust",
    ".go": "Go",
    ".java": "Java",
    ".c": "C",
    ".h": "C",
    ".cpp": "C++",
}


def _send_icon() -> QIcon:
    return _line_icon("arrow-up", "#1a1a1d", 20)


def _glyph_label(name: str, color: str = MUTED, size: int = 13) -> QLabel:
    label = QLabel()
    label.setPixmap(_line_icon(name, color, size).pixmap(QSize(size, size)))
    label.setFixedSize(size, size)
    return label



class Logo(QWidget):
    """Sari zemin uzerinde koyu B harfi; baslik ve karsilama icin."""

    def __init__(self, size: int = 28, parent=None) -> None:
        super().__init__(parent)
        self._size = size
        self.setFixedSize(size, size)

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRect(1, 1, self._size - 2, self._size - 2)
        gradient = QLinearGradient(rect.topLeft(), rect.bottomRight())
        gradient.setColorAt(0.0, QColor(ACCENT_LIGHT))
        gradient.setColorAt(1.0, QColor(ACCENT_DARK))
        painter.setBrush(QBrush(gradient))
        painter.setPen(Qt.NoPen)
        radius = self._size * 0.28
        painter.drawRoundedRect(rect, radius, radius)
        painter.setFont(
            _make_font(UI_FONT, max(8, int(self._size * 0.5)), QFont.Bold)
        )
        painter.setPen(QColor("#1b1b1d"))
        painter.drawText(rect, Qt.AlignCenter, "B")


class FluentCombo(QComboBox):
    """QSS kutusu + elle cizilen ince asagi ok."""

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor(MUTED))
        pen.setWidthF(1.6)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        cx = self.width() - 11
        cy = self.height() // 2
        painter.drawLine(QPoint(cx - 4, cy - 2), QPoint(cx, cy + 2))
        painter.drawLine(QPoint(cx, cy + 2), QPoint(cx + 4, cy - 2))


class FluentCheckBox(QCheckBox):
    """Secili durumda aksan kutusunun uzerine koyu tik isareti cizer."""

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if not self.isChecked():
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor("#1b1b1d"))
        pen.setWidthF(2.0)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        x = 2
        y = (self.height() - 16) // 2
        painter.drawLine(QPoint(x + 4, y + 8), QPoint(x + 7, y + 11))
        painter.drawLine(QPoint(x + 7, y + 11), QPoint(x + 12, y + 5))


class RippleButton(QPushButton):
    """Basildiginda noktadan yayilan hafif dalga cizer."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._ripples: list[list[float]] = []
        self._ripple_timer = QTimer(self)
        self._ripple_timer.setInterval(16)
        self._ripple_timer.timeout.connect(self._tick_ripple)

    def mousePressEvent(self, event) -> None:
        if motion_allowed() and self.isEnabled():
            self._ripples.append(
                [float(event.pos().x()), float(event.pos().y()), 2.0, 1.0]
            )
            self._ripple_timer.start()
        super().mousePressEvent(event)

    def _tick_ripple(self) -> None:
        alive: list[list[float]] = []
        for ripple in self._ripples:
            ripple[2] += max(self.width(), self.height()) * 0.09
            ripple[3] -= 0.075
            if ripple[3] > 0:
                alive.append(ripple)
        self._ripples = alive
        if not self._ripples:
            self._ripple_timer.stop()
        self.update()

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if not self._ripples:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setClipRect(self.rect())
        accent = self.objectName() == "AccentButton"
        for x, y, radius, alpha in self._ripples:
            color = QColor("#ffffff" if accent else ACCENT)
            color.setAlphaF(min(0.16, max(0.0, alpha * 0.16)))
            painter.setBrush(QBrush(color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(
                QRectF(x - radius, y - radius, radius * 2, radius * 2)
            )


class FileTree(QTreeWidget):
    """Dosya agaci; dallari QSS'in gizledigi ok yerine ince cizgiyle cizer."""

    def drawBranches(self, painter: QPainter, rect: QRect, index) -> None:
        model = self.model()
        if not model.hasChildren(index):
            return
        expanded = self.isExpanded(index)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor("#7d7d87"))
        pen.setWidthF(1.5)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        cx = rect.right() - 6
        cy = rect.center().y()
        if expanded:
            painter.drawLine(QPoint(cx - 3, cy - 1), QPoint(cx, cy + 2))
            painter.drawLine(QPoint(cx, cy + 2), QPoint(cx + 3, cy - 1))
        else:
            painter.drawLine(QPoint(cx - 1, cy - 3), QPoint(cx + 2, cy))
            painter.drawLine(QPoint(cx + 2, cy), QPoint(cx - 1, cy + 3))
        painter.restore()


class BusyLine(QWidget):
    """Model calisirken durum cubugunun ustunde akan aksan cizgisi."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedHeight(2)
        self._phase = 0.0
        self._active = False
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)

    def set_active(self, active: bool) -> None:
        active = bool(active)
        if active == self._active:
            return
        self._active = active
        if active:
            self._phase = 0.0
            self._timer.start()
        else:
            self._timer.stop()
        self.update()

    def _tick(self) -> None:
        self._phase = (self._phase + 0.012) % 1.0
        self.update()

    def paintEvent(self, _event) -> None:
        if not self._active:
            return
        width = self.width()
        if width <= 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        segment = max(90, int(width * 0.22))
        x = int(self._phase * (width + segment)) - segment
        gradient = QLinearGradient(x, 0, x + segment, 0)
        gradient.setColorAt(0.0, QColor(245, 197, 66, 0))
        gradient.setColorAt(0.5, QColor(ACCENT))
        gradient.setColorAt(1.0, QColor(245, 197, 66, 0))
        painter.fillRect(x, 0, segment, self.height(), QBrush(gradient))
        painter.end()


class GuiUI(UI):
    """Agent ve arac katmanini Qt sohbet paneline baglayan arayuz."""

    def __init__(self, app: "GuiApp") -> None:
        super().__init__(
            color=False,
            show_reasoning=app.config.show_reasoning,
            one_shot=False,
            stream_output=True,
        )
        self.app = app
        self.interactive = True

    def _emit(self, renderable, *, to_err: bool = False) -> None:
        text = (
            renderable.render(False)
            if isinstance(renderable, Text)
            else str(renderable)
        )
        self.app.post("line", text, "error" if to_err else "system")

    def info(self, message: str) -> None:
        self.app.post("line", message, "muted")

    def warn(self, message: str) -> None:
        self.app.post("line", "> UYARI " + message, "warn")

    def error(self, message: str) -> None:
        self.app.post("line", "> HATA " + message, "error")

    def note(self, message: str) -> None:
        self.app.post("line", message, "muted")

    def preview_line(self, line: str) -> None:
        return None

    def show_panel(self, visible: bool = True) -> None:
        return None

    def set_panel_width(self, percent: int) -> None:
        return None

    def assistant_start(self) -> None:
        self.app.post("assistant_start")

    def assistant_end(self) -> None:
        self.app.post("assistant_end")

    def stream_text(self, text: str) -> None:
        if text:
            self.app.post("stream", text)

    def stream_thinking(self, text: str) -> None:
        if text and self.show_reasoning:
            self.app.post("thinking", text)

    def break_thinking(self) -> None:
        self.app.post("break_thinking")

    def tool_call(self, name: str, summary: str) -> None:
        self.app.post("tool_call", name, summary)

    def tool_result(self, ok: bool, summary: str) -> None:
        self.app.post("tool_result", ok, summary)

    def usage(
        self,
        input_tokens: int,
        output_tokens: int,
        elapsed: float,
        cost: float | None = None,
    ) -> None:
        self.app.post("usage", input_tokens, output_tokens, elapsed, cost)

    def status(self, message: str):
        return _GuiStatus(self.app, message)

    def progress(self, label: str):
        return _GuiProgress(self.app, label)

    def ask_approval(self, prompt: str) -> str:
        return self.app.ask_approval(prompt)

    def ask_line(self, prompt: str, default: str = "") -> str:
        return self.app.ask_string(prompt, default)

    def ask_secret(self, prompt: str) -> str:
        return self.app.ask_string(prompt, "", secret=True)

    def prompt(self, text: str) -> str:
        return self.app.ask_string(text)

    def ask_choice(self, prompt: str, choices, default: str = "") -> str:
        return self.app.ask_choice(prompt, list(choices), default)


class _GuiStatus:
    def __init__(self, app: "GuiApp", message: str) -> None:
        self.app = app
        self.message = message

    def start(self) -> None:
        self.app.post("status", self.message)

    def stop(self) -> None:
        self.app.post("status", "")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_exc) -> None:
        self.stop()
        return None


class _GuiProgress:
    def __init__(self, app: "GuiApp", label: str) -> None:
        self.app = app
        self.label = label

    def __enter__(self):
        return self

    def __exit__(self, *_exc) -> None:
        self.clear()
        return None

    def update(self, done: int, total: int) -> None:
        if total:
            percent = int(done * 100 / total)
            message = (
                f"{self.label}  %{percent}  "
                f"({done / 1e6:.1f}/{total / 1e6:.1f} MB)"
            )
        else:
            message = f"{self.label}  {done / 1e6:.1f} MB"
        self.app.post("status", message)

    def clear(self) -> None:
        self.app.post("status", "")


class LineNumberArea(QWidget):
    def __init__(self, editor: "CodeEditor") -> None:
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self) -> QSize:
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event) -> None:
        self.editor.line_number_area_paint_event(event)


class CodeEditor(QPlainTextEdit):
    """Satir numarali, akilli girintili kod editoru."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self._update_area_width)
        self.updateRequest.connect(self._update_area)
        self.cursorPositionChanged.connect(self._highlight_current_line)
        self.setFont(_make_font(MONO_FONT, 12))
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setWordWrapMode(QTextOption.NoWrap)
        self.setTabStopDistance(
            QFontMetricsF(self.font()).horizontalAdvance(" ") * 4
        )
        self._update_area_width()
        self._highlight_current_line()

    def line_number_area_width(self) -> int:
        digits = len(str(max(1, self.blockCount())))
        return 16 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_area_width(self) -> None:
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _update_area(self, rect: QRect, dy: int) -> None:
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(
                0, rect.y(), self.line_number_area.width(), rect.height()
            )
        if rect.contains(self.viewport().rect()):
            self._update_area_width()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        contents = self.contentsRect()
        self.line_number_area.setGeometry(
            QRect(
                contents.left(),
                contents.top(),
                self.line_number_area_width(),
                contents.height(),
            )
        )

    def line_number_area_paint_event(self, event) -> None:
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor(EDITOR_BG))
        painter.setFont(_make_font(MONO_FONT, 10))
        block = self.firstVisibleBlock()
        number = block.blockNumber()
        offset = self.contentOffset()
        top = self.blockBoundingGeometry(block).translated(offset).top()
        bottom = top + self.blockBoundingRect(block).height()
        current = self.textCursor().blockNumber()
        width = self.line_number_area.width() - 9
        height = self.fontMetrics().height()

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                color = QColor(ACCENT) if number == current else QColor("#55555e")
                painter.setPen(color)
                painter.drawText(
                    0,
                    int(top),
                    width,
                    height,
                    Qt.AlignRight,
                    str(number + 1),
                )
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            number += 1
        painter.end()

    def _highlight_current_line(self) -> None:
        selection = QTextEdit.ExtraSelection()
        selection.format.setBackground(QColor("#1d1d22"))
        selection.format.setProperty(QTextFormat.FullWidthSelection, True)
        selection.cursor = self.textCursor()
        selection.cursor.clearSelection()
        self.setExtraSelections([selection])

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            if event.modifiers() & Qt.ShiftModifier:
                super().keyPressEvent(event)
                return
            cursor = self.textCursor()
            line = cursor.block().text()
            indent = re.match(r"\s*", line).group(0)
            if line.rstrip().endswith(":"):
                indent += "    "
            cursor.insertText("\n" + indent)
            self.setTextCursor(cursor)
            return
        if event.key() == Qt.Key_Tab:
            modifiers = event.modifiers()
            if modifiers & (Qt.ControlModifier | Qt.MetaModifier | Qt.AltModifier):
                super().keyPressEvent(event)
                return
            self.insertPlainText("    ")
            return
        super().keyPressEvent(event)


class PythonHighlighter(QSyntaxHighlighter):
    """Python icin hafif sozdizimi renklendirme."""

    def __init__(self, document) -> None:
        super().__init__(document)
        self.rules: list[tuple[QRegExp, QTextCharFormat]] = []

        keyword = QTextCharFormat()
        keyword.setForeground(QColor("#c792ea"))
        keyword.setFontWeight(QFont.DemiBold)
        self.rules.append(
            (
                QRegExp(
                    r"\b(False|None|True|and|as|assert|async|await|break|class|"
                    r"continue|def|del|elif|else|except|finally|for|from|global|"
                    r"if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|"
                    r"self|try|while|with|yield)\b"
                ),
                keyword,
            )
        )

        builtin = QTextCharFormat()
        builtin.setForeground(QColor("#82aaff"))
        self.rules.append(
            (
                QRegExp(
                    r"\b(print|len|range|str|int|float|bool|list|dict|set|tuple|"
                    r"open|enumerate|zip|map|filter|sum|min|max|abs|sorted|"
                    r"reversed|isinstance|type|super|Exception|ValueError|"
                    r"KeyError|Path)\b"
                ),
                builtin,
            )
        )

        number = QTextCharFormat()
        number.setForeground(QColor("#f2a65a"))
        self.rules.append((QRegExp(r"\b[0-9]+(\.[0-9]+)?\b"), number))

        decorator = QTextCharFormat()
        decorator.setForeground(QColor("#f5c542"))
        self.rules.append((QRegExp(r"^\s*@\w+"), decorator))

        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#5f5f6a"))
        self.comment_format.setFontItalic(True)
        self.rules.append((QRegExp(r"#[^\n]*"), self.comment_format))

        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor("#a5d6a7"))
        self.rules.append(
            (QRegExp(r"'[^'\n]*'|\"[^\"\n]*\""), self.string_format)
        )

        self.tri_single = QRegExp("'''")
        self.tri_double = QRegExp('"""')

    def highlightBlock(self, text: str) -> None:
        for pattern, fmt in self.rules:
            index = pattern.indexIn(text)
            while index >= 0:
                length = pattern.matchedLength()
                if length <= 0:
                    break
                self.setFormat(index, length, fmt)
                index = pattern.indexIn(text, index + length)

        self.setCurrentBlockState(0)
        for delimiter in (self.tri_single, self.tri_double):
            start = 0
            if self.previousBlockState() != 1:
                start = delimiter.indexIn(text)
            while start >= 0:
                end = delimiter.indexIn(text, start + 3)
                if end == -1:
                    self.setCurrentBlockState(1)
                    length = len(text) - start
                else:
                    length = end - start + 3
                self.setFormat(start, length, self.string_format)
                start = delimiter.indexIn(text, start + length)


class EditorTab(QWidget):
    """Tek bir dosyanin editoru; kaydetme ve diskten yenileme destekler."""

    def __init__(self, app: "GuiApp", path: Path) -> None:
        super().__init__()
        self.app = app
        self.path = path
        self.modified = False
        self._loading = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.editor = CodeEditor(self)
        self.highlighter = (
            PythonHighlighter(self.editor.document())
            if path.suffix.lower() in (".py", ".pyw")
            else None
        )
        layout.addWidget(self.editor)
        self.editor.textChanged.connect(self._on_text_changed)
        self.editor.cursorPositionChanged.connect(app._on_cursor_moved)

    def load(self) -> None:
        self._loading = True
        try:
            content = ""
            if self.path.exists():
                try:
                    data = self.path.read_bytes()
                except OSError as exc:
                    QMessageBox.critical(
                        self.app.window,
                        "Dosya acilamadi",
                        f"{self.path}\n{exc}",
                    )
                    return
                if len(data) > MAX_FILE_BYTES:
                    QMessageBox.warning(
                        self.app.window,
                        "Dosya cok buyuk",
                        f"{self.path.name} {len(data) / 1e6:.1f} MB; "
                        "editor en fazla 2 MB dosya acar.",
                    )
                    return
                if b"\x00" in data[:4096]:
                    QMessageBox.warning(
                        self.app.window,
                        "Ikili dosya",
                        f"{self.path.name} ikili gorunuyor; metin "
                        "editorunde acilmadi.",
                    )
                    return
                content = data.decode("utf-8", errors="replace")
            self.editor.setPlainText(content)
            self.editor.document().setModified(False)
            self.editor.moveCursor(QTextCursor.Start)
            self.modified = False
            self.app.update_tab_title(self)
        finally:
            self._loading = False

    def save(self) -> bool:
        content = self.editor.toPlainText()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(content, encoding="utf-8")
        except OSError as exc:
            QMessageBox.critical(
                self.app.window, "Kaydetme hatasi", f"{self.path}\n{exc}"
            )
            return False
        self.editor.document().setModified(False)
        self.modified = False
        self.app.update_tab_title(self)
        self.app.set_activity(f"Kaydedildi: {self.path.name}")
        self.app.refresh_tree()
        return True

    def reload_from_disk(self) -> None:
        if self.modified or not self.path.exists():
            return
        try:
            data = self.path.read_bytes()
        except OSError:
            return
        if len(data) > MAX_FILE_BYTES or b"\x00" in data[:4096]:
            return
        content = data.decode("utf-8", errors="replace")
        if self.editor.toPlainText() == content:
            return
        position = self.editor.verticalScrollBar().value()
        cursor = self.editor.textCursor().position()
        self._loading = True
        try:
            self.editor.setPlainText(content)
            self.editor.document().setModified(False)
        finally:
            self._loading = False
        self.modified = False
        self.app.update_tab_title(self)
        self.editor.verticalScrollBar().setValue(position)
        restored = self.editor.textCursor()
        restored.setPosition(min(cursor, len(content)))
        self.editor.setTextCursor(restored)

    def _on_text_changed(self) -> None:
        if self._loading:
            return
        self.modified = True
        self.app.update_tab_title(self)


class Bubble(QFrame):
    def __init__(self, kind: str, parent=None) -> None:
        super().__init__(parent)
        self.kind = kind
        names = {
            "user": "BubbleUser",
            "assistant": "BubbleAssistant",
            "thinking": "BubbleThinking",
        }
        self.setObjectName(names.get(kind, "BubbleAssistant"))
        self.setMaximumWidth(560)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(11, 8, 11, 8)
        layout.setSpacing(0)
        self.label = QLabel()
        self.label.setObjectName("BubbleText")
        self.label.setWordWrap(True)
        self.label.setTextFormat(Qt.RichText)
        self.label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.label)


class MessageRow(QWidget):
    def __init__(self, kind: str, parent=None) -> None:
        super().__init__(parent)
        self.kind = kind
        self.plain_text = ""
        self._is_bubble = kind in ("user", "assistant", "thinking")
        self._gutter = 30 if kind in ("assistant", "thinking") else 0
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        if self._is_bubble:
            self.bubble = Bubble(kind, self)
            self.label = self.bubble.label
        else:
            self.bubble = QLabel(self)
            self.bubble.setObjectName("RawLine")
            self.bubble.setTextFormat(Qt.RichText)
            self.bubble.setWordWrap(True)
            self.bubble.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.bubble.setFont(_make_font(MONO_FONT, 10))
            self.bubble.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            self.label = self.bubble

        if kind == "user":
            layout.addStretch(1)
            layout.addWidget(self.bubble)
        elif kind == "assistant":
            layout.addWidget(Logo(22), 0, Qt.AlignTop)
            layout.addWidget(self.bubble)
            layout.addStretch(1)
        elif kind == "thinking":
            marker = QLabel()
            marker.setPixmap(
                _line_icon("spark", THINK, 14).pixmap(QSize(14, 14))
            )
            marker.setFixedSize(22, 22)
            marker.setAlignment(Qt.AlignCenter)
            layout.addWidget(marker, 0, Qt.AlignTop)
            layout.addWidget(self.bubble)
            layout.addStretch(1)
        else:
            layout.addWidget(self.bubble, 1)

    def fit(self, available: int, text: str) -> None:
        if not self._is_bubble:
            return
        metrics = self.label.fontMetrics()
        natural = max(
            (
                metrics.horizontalAdvance(line)
                for line in (text or " ").splitlines()
            ),
            default=0,
        )
        max_width = max(200, min(560, available - 16 - self._gutter))
        min_width = 130 if self.kind == "user" else 190
        width = min(max_width, max(min_width, natural + 28))
        if width != self.bubble.minimumWidth():
            self.bubble.setFixedWidth(width)


class ChatWelcome(QFrame):
    """Sohbetin basinda model bilgisi ve oneri cipleri."""

    SUGGESTIONS = (
        ("Dosyalari ozetle", "search"),
        ("Testleri bul", "check"),
        ("README iyilestir", "file"),
        ("/help komutlari", "terminal"),
    )

    def __init__(self, on_pick, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("ChatWelcome")
        self.setMaximumWidth(520)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 14, 16, 14)
        outer.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(10)
        head.addWidget(Logo(34), 0, Qt.AlignTop)
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        title = QLabel("Banana'ya hos geldin")
        title.setObjectName("ChatWelcomeTitle")
        text_col.addWidget(title)
        self.sub = QLabel("")
        self.sub.setObjectName("ChatWelcomeSub")
        self.sub.setWordWrap(True)
        text_col.addWidget(self.sub)
        head.addLayout(text_col, 1)
        outer.addLayout(head)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        for index, (label, icon) in enumerate(self.SUGGESTIONS):
            button = RippleButton(label)
            button.setObjectName("Suggestion")
            button.setIcon(_line_icon(icon, MUTED, 13))
            button.setIconSize(QSize(13, 13))
            button.setCursor(Qt.PointingHandCursor)
            button.clicked.connect(
                lambda _checked=False, text=label: on_pick(text)
            )
            grid.addWidget(button, index // 2, index % 2)
        outer.addLayout(grid)

    def set_context(self, model: str, cwd: str) -> None:
        name = Path(cwd).name or cwd
        self.sub.setText(f"{model}  ·  {name}")
        self.sub.setToolTip(cwd)


class ChatView(QScrollArea):
    """Balon tabanli sohbet akisi."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("ChatView")
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._surface = QWidget()
        self._surface.setObjectName("ChatSurface")
        self._layout = QVBoxLayout(self._surface)
        self._layout.setContentsMargins(4, 4, 4, 8)
        self._layout.setSpacing(7)
        self._layout.setAlignment(Qt.AlignTop)
        self.setWidget(self._surface)
        self._rows: list[MessageRow] = []
        self._active: MessageRow | None = None
        self._thinking: MessageRow | None = None
        self._refitting = False
        self._motion = motion_allowed()

    def add_banner(self, widget: QWidget) -> None:
        self._layout.insertWidget(0, widget)

    def reset(self) -> None:
        self._active = None
        self._thinking = None
        for row in self._rows:
            self._layout.removeWidget(row)
            row.deleteLater()
        self._rows.clear()

    def _fade_in(self, row: QWidget) -> None:
        if not self._motion:
            return
        effect = QGraphicsOpacityEffect(row)
        effect.setOpacity(0.0)
        row.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", row)
        animation.setDuration(170)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.finished.connect(lambda: row.setGraphicsEffect(None))
        row._fade_animation = animation
        animation.start(QPropertyAnimation.DeleteWhenStopped)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self._refitting:
            return
        self._refitting = True
        try:
            width = self.viewport().width()
            for row in getattr(self, "_rows", []):
                row.fit(width, row.plain_text)
        finally:
            self._refitting = False

    def _sticky(self) -> bool:
        bar = self.verticalScrollBar()
        return bar.value() >= bar.maximum() - 24

    def _scroll_bottom(self) -> None:
        bar = self.verticalScrollBar()
        QTimer.singleShot(0, lambda: bar.setValue(bar.maximum()))

    def _add(self, kind: str) -> MessageRow:
        stick = self._sticky()
        row = MessageRow(kind, self._surface)
        self._rows.append(row)
        self._layout.addWidget(row)
        self._fade_in(row)
        if stick:
            self._scroll_bottom()
        return row

    @staticmethod
    def _repolish(widget: QWidget) -> None:
        widget.style().unpolish(widget)
        widget.style().polish(widget)
        widget.update()

    def add_user(self, text: str) -> None:
        row = self._add("user")
        row.label.setText(_render_plain(text))
        row.plain_text = str(text)
        row.fit(self.viewport().width(), row.plain_text)
        self._scroll_bottom()

    def begin_assistant(self) -> None:
        # Balon yalnizca ilk metin geldiginde olusturulur; arac cagrisi
        # disinda metinsiz yanitlar bos kutu birakmaz.
        self._active = None

    def append_assistant(self, text: str) -> None:
        if self._active is None:
            row = self._add("assistant")
            row.label.setText("")
            row.fit(self.viewport().width(), "")
            row.bubble.setProperty("streaming", True)
            self._repolish(row.bubble)
            self._active = row
        assert self._active is not None
        self._active.plain_text += text
        self._active.label.setText(render_markdown(self._active.plain_text))
        self._active.fit(self.viewport().width(), self._active.plain_text)
        if self._sticky():
            self._scroll_bottom()

    def end_assistant(self) -> None:
        if self._active is not None:
            self._active.bubble.setProperty("streaming", False)
            self._repolish(self._active.bubble)
        self._active = None

    def begin_thinking(self) -> None:
        row = self._add("thinking")
        row.label.setText('<span style="font-style:italic;">[dusunme]</span>')
        row.fit(self.viewport().width(), "")
        self._thinking = row

    def append_thinking(self, text: str) -> None:
        if self._thinking is None:
            self.begin_thinking()
        assert self._thinking is not None
        self._thinking.plain_text += text
        self._thinking.label.setText(
            '<span style="font-style:italic;">[dusunme] '
            + _render_plain(self._thinking.plain_text)
            + "</span>"
        )
        self._thinking.fit(self.viewport().width(), self._thinking.plain_text)
        if self._sticky():
            self._scroll_bottom()

    def end_thinking(self) -> None:
        self._thinking = None

    def add_system(self, text: str, kind: str = "system") -> None:
        row = self._add("raw")
        row.label.setProperty("role", kind)
        row.label.setText(_render_plain(text))
        row.plain_text = str(text)
        self._repolish(row.label)

    def add_tool(self, name: str, summary: str) -> None:
        line = "-> " + str(name)
        if summary:
            line += "  " + str(summary)
        row = self._add("raw")
        row.label.setProperty("role", "tool")
        row.label.setText(_render_plain(line))
        row.plain_text = line
        self._repolish(row.label)

    def add_tool_result(self, ok: bool, summary: str) -> None:
        line = ("+ " if ok else "x ") + str(summary)
        row = self._add("raw")
        row.label.setProperty("role", "ok" if ok else "fail")
        row.label.setText(_render_plain(line))
        row.plain_text = line
        self._repolish(row.label)

    def to_plain_text(self) -> str:
        return "\n".join(row.plain_text for row in self._rows if row.plain_text)


class ComposerEdit(QPlainTextEdit):
    submitted = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("ComposerEdit")
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self.setFont(_make_font(MONO_FONT, 12))
        self.setFixedHeight(72)
        palette = self.palette()
        palette.setColor(QPalette.PlaceholderText, QColor("#5f5f68"))
        self.setPalette(palette)
        self.textChanged.connect(self._resize)

    def _resize(self) -> None:
        height = int(self.document().size().height()) + 18
        height = max(72, min(146, height))
        if height != self.height():
            self.setFixedHeight(height)

    def focusInEvent(self, event) -> None:
        super().focusInEvent(event)
        frame = self.parentWidget()
        if frame is not None:
            frame.setProperty("focused", True)
            frame.style().unpolish(frame)
            frame.style().polish(frame)

    def focusOutEvent(self, event) -> None:
        super().focusOutEvent(event)
        frame = self.parentWidget()
        if frame is not None:
            frame.setProperty("focused", False)
            frame.style().unpolish(frame)
            frame.style().polish(frame)

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            if event.modifiers() & Qt.ShiftModifier:
                super().keyPressEvent(event)
                return
            self.submitted.emit()
            return
        super().keyPressEvent(event)


class Toast(QFrame):
    """Kisa sureli bildirim; kendiliginden kaybolur."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setObjectName("Toast")
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setFixedHeight(38)
        self._effect = QGraphicsOpacityEffect(self)
        self._effect.setOpacity(1.0)
        self.setGraphicsEffect(self._effect)
        row = QHBoxLayout(self)
        row.setContentsMargins(12, 6, 14, 6)
        row.setSpacing(9)
        self.icon = QLabel()
        self.icon.setFixedSize(14, 14)
        row.addWidget(self.icon)
        self.label = QLabel("")
        self.label.setObjectName("ToastText")
        row.addWidget(self.label, 1)
        self._hide_after = False
        self._open = False
        self._anim = QPropertyAnimation(self._effect, b"opacity", self)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.finished.connect(self._on_fade_finished)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.dismiss)
        self.hide()

    def present(self, text: str, kind: str = "ok") -> None:
        icons = {
            "ok": ("check", GREEN),
            "info": ("spark", ACCENT),
            "warn": ("alert", WARN),
            "error": ("alert", RED),
        }
        icon, color = icons.get(kind, icons["info"])
        self.setProperty("kind", kind)
        self.icon.setPixmap(_line_icon(icon, color, 14).pixmap(QSize(14, 14)))
        self.label.setText(_shorten(text, 92))
        self._repolish()
        width = min(430, max(190, self.label.sizeHint().width() + 68))
        self.setFixedWidth(width)
        self._open = True
        self.reposition()
        self.show()
        self.raise_()
        self._timer.start(3400)
        self._hide_after = False
        if motion_allowed():
            self._fade_to(1.0, 160)
        else:
            self._effect.setOpacity(1.0)

    def dismiss(self) -> None:
        if not self._open:
            return
        self._open = False
        self._timer.stop()
        if motion_allowed():
            self._hide_after = True
            self._fade_to(0.0, 140)
        else:
            self.hide()

    def reposition(self) -> None:
        parent = self.parentWidget()
        if parent is None:
            return
        self.move(
            max(8, (parent.width() - self.width()) // 2),
            max(8, parent.height() - self.height() - 44),
        )

    def _fade_to(self, value: float, duration: int) -> None:
        self._anim.stop()
        self._anim.setDuration(duration)
        self._anim.setStartValue(self._effect.opacity())
        self._anim.setEndValue(value)
        self._anim.start()

    def _on_fade_finished(self) -> None:
        if self._hide_after:
            self._open = False
            self.hide()
            self._hide_after = False

    def _repolish(self) -> None:
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()


class CommandPalette(QDialog):
    """Ctrl+K ile acilan komut ve dosya arama penceresi."""

    def __init__(self, app: "GuiApp") -> None:
        super().__init__(app.window)
        self.app = app
        self.setObjectName("PaletteDialog")
        self.setWindowTitle("Komut paleti")
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setModal(True)
        self.setFixedSize(560, 424)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 14, 14, 12)
        outer.setSpacing(9)

        head = QHBoxLayout()
        head.setSpacing(7)
        head.addWidget(_glyph_label("search", MUTED, 13))
        title = QLabel("Komut paleti")
        title.setObjectName("PaletteTitle")
        head.addWidget(title)
        head.addStretch(1)
        badge = QLabel("Ctrl+K")
        badge.setObjectName("PaletteHint")
        head.addWidget(badge)
        outer.addLayout(head)

        self.input = QLineEdit()
        self.input.setObjectName("PaletteInput")
        self.input.setPlaceholderText("Komut veya dosya ara...")
        self.input.textChanged.connect(self._refresh)
        self.input.returnPressed.connect(self._run_current)
        outer.addWidget(self.input)

        self.list = QListWidget()
        self.list.setObjectName("PaletteList")
        self.list.setFocusPolicy(Qt.NoFocus)
        self.list.itemActivated.connect(lambda _item: self._run_current())
        outer.addWidget(self.list, 1)

        foot = QHBoxLayout()
        foot.setSpacing(8)
        hint = QLabel("Enter calistir  ·  Esc kapat")
        hint.setObjectName("PaletteHint")
        foot.addWidget(hint)
        foot.addStretch(1)
        self.count_label = QLabel("")
        self.count_label.setObjectName("PaletteHint")
        foot.addWidget(self.count_label)
        outer.addLayout(foot)

        self._commands: list[tuple[str, str, str, object]] = []
        self._actions: list = []

    def prepare(self) -> None:
        self._commands = self.app.palette_commands()
        self.input.clear()
        self._refresh("")
        self.input.setFocus()

    def _refresh(self, query: str = "") -> None:
        tokens = query.casefold().split()
        matches: list[tuple[int, str, str, str, object]] = []
        for order, (label, hint, icon, action) in enumerate(self._commands):
            haystack = f"{label} {hint}".casefold()
            if not all(token in haystack for token in tokens):
                continue
            if not tokens:
                score = order
            elif label.casefold().startswith(tokens[0]):
                score = order
            else:
                score = 100 + order
            matches.append((score, label, hint, icon, action))
        matches.sort(key=lambda item: item[0])
        self.list.clear()
        self._actions = []
        for _score, label, hint, icon, action in matches[:7]:
            item = QListWidgetItem(label + ("    " + hint if hint else ""))
            item.setIcon(_line_icon(icon, MUTED, 13))
            item.setToolTip(hint)
            self.list.addItem(item)
            self._actions.append(action)
        if self.list.count():
            self.list.setCurrentRow(0)
        self.count_label.setText(
            f"{len(matches)} sonuc" if matches else "sonuc yok"
        )

    def _run_current(self) -> None:
        row = self.list.currentRow()
        if row < 0 or row >= len(self._actions):
            return
        action = self._actions[row]
        self.accept()
        QTimer.singleShot(0, action)


class SettingsDialog(QDialog):
    """Fluent ayar penceresi: tema, davranis ve kisayollar."""

    SHORTCUTS = (
        ("Ctrl+K", "Komut paletini ac"),
        ("Ctrl+Shift+P", "Komut paletini ac (alternatif)"),
        ("Ctrl+S", "Aktif dosyayi kaydet"),
        ("Ctrl+O", "Calisma klasoru sec"),
        ("Ctrl+N", "Yeni dosya olustur"),
        ("Ctrl+W", "Aktif sekmeyi kapat"),
        ("Ctrl+R", "Dosya agacini yenile"),
        ("Ctrl+B", "Kenar cubugunu ac / kapat"),
        ("Ctrl+,", "Ayarlari ac"),
    )

    def __init__(self, app: "GuiApp") -> None:
        super().__init__(app.window)
        self.app = app
        self.setObjectName("SettingsDialog")
        self.setWindowTitle("Ayarlar")
        self.setModal(True)
        self.setMinimumSize(700, 470)
        self._swatches: dict[str, QPushButton] = {}

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        body = QHBoxLayout()
        body.setContentsMargins(16, 16, 16, 8)
        body.setSpacing(14)
        self.nav = QListWidget()
        self.nav.setObjectName("SettingsNav")
        self.nav.setFixedWidth(172)
        self.nav.setFocusPolicy(Qt.NoFocus)
        self.nav.addItems(["Gorunum", "Davranis", "Kisayollar"])
        body.addWidget(self.nav)

        self.pages = QStackedWidget()
        self.pages.addWidget(self._appearance_page())
        self.pages.addWidget(self._behavior_page())
        self.pages.addWidget(self._shortcut_page())
        body.addWidget(self.pages, 1)
        outer.addLayout(body, 1)
        self.nav.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.nav.setCurrentRow(0)

        footer = QHBoxLayout()
        footer.setContentsMargins(18, 6, 18, 14)
        hint = QLabel("Degisiklikler aninda uygulanir.")
        hint.setObjectName("SettingsHint")
        footer.addWidget(hint)
        footer.addStretch(1)
        footer.addWidget(app._button("Kapat", self.accept, "accent"))
        outer.addLayout(footer)

        self.sync_state()

    # ------------------------------------------------------------- sayfalar

    def _page(self) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        page.setObjectName("SettingsPage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 6, 4, 6)
        layout.setSpacing(12)
        return page, layout

    def _card(self, layout: QVBoxLayout) -> tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName("SettingsCard")
        inner = QVBoxLayout(card)
        inner.setContentsMargins(14, 12, 14, 12)
        inner.setSpacing(8)
        layout.addWidget(card)
        return card, inner

    def _appearance_page(self) -> QWidget:
        page, layout = self._page()
        heading = QLabel("Gorunum")
        heading.setObjectName("SettingsHeading")
        layout.addWidget(heading)
        body = QLabel(
            "Vurgu rengi basliklari, cipleri, odak halkalarini ve "
            "secimleri boyar. Tema tercihi gui.ini icinde saklanir."
        )
        body.setObjectName("SettingsBody")
        body.setWordWrap(True)
        layout.addWidget(body)

        _card, inner = self._card(layout)
        label = QLabel("Vurgu rengi")
        label.setObjectName("SettingsLabel")
        inner.addWidget(label)
        hint = QLabel("Bes hazir palet; secim aninda uygulanir.")
        hint.setObjectName("SettingsHint")
        inner.addWidget(hint)
        swatch_row = QHBoxLayout()
        swatch_row.setSpacing(12)
        for name in ACCENT_PRESETS:
            swatch_row.addWidget(self._make_swatch(name))
        swatch_row.addStretch(1)
        inner.addLayout(swatch_row)

        _card, inner = self._card(layout)
        row = QHBoxLayout()
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        label = QLabel("Hareketli gecisler")
        label.setObjectName("SettingsLabel")
        text_col.addWidget(label)
        hint = QLabel("Balon, bildirim ve kenar cubugu animasyonlari.")
        hint.setObjectName("SettingsHint")
        text_col.addWidget(hint)
        row.addLayout(text_col, 1)
        self.motion_check = FluentCheckBox("Acik")
        self.motion_check.setCursor(Qt.PointingHandCursor)
        self.motion_check.toggled.connect(self.app.set_motion)
        row.addWidget(self.motion_check)
        inner.addLayout(row)

        row = QHBoxLayout()
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        label = QLabel("Kenar cubugu")
        label.setObjectName("SettingsLabel")
        text_col.addWidget(label)
        hint = QLabel("Dosya agacini sol tarafta goster.")
        hint.setObjectName("SettingsHint")
        text_col.addWidget(hint)
        row.addLayout(text_col, 1)
        self.sidebar_check = FluentCheckBox("Goster")
        self.sidebar_check.setCursor(Qt.PointingHandCursor)
        self.sidebar_check.toggled.connect(self.app.toggle_sidebar)
        row.addWidget(self.sidebar_check)
        inner.addLayout(row)
        layout.addStretch(1)
        return page

    def _make_swatch(self, name: str) -> QWidget:
        accent, _dim, label_text = ACCENT_PRESETS[name]
        holder = QWidget()
        column = QVBoxLayout(holder)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(5)
        button = QPushButton()
        button.setObjectName("Swatch")
        button.setFixedSize(36, 36)
        button.setCursor(Qt.PointingHandCursor)
        button.setToolTip(label_text)
        button.setAccessibleName(f"Tema {label_text}")
        button.setStyleSheet(
            f"background-color: {accent}; border: 2px solid transparent; "
            "border-radius: 11px;"
        )
        button.clicked.connect(
            lambda _checked=False, value=name: self.app.set_accent(value)
        )
        column.addWidget(button, 0, Qt.AlignHCenter)
        caption = QLabel(label_text)
        caption.setObjectName("SwatchName")
        caption.setAlignment(Qt.AlignCenter)
        column.addWidget(caption)
        self._swatches[name] = button
        return holder

    def _behavior_page(self) -> QWidget:
        page, layout = self._page()
        heading = QLabel("Davranis")
        heading.setObjectName("SettingsHeading")
        layout.addWidget(heading)
        body = QLabel(
            "Arac izinleri ve model etkilesimi. Bu ayarlar aktif oturuma "
            "ve config.json dosyasina yazilir."
        )
        body.setObjectName("SettingsBody")
        body.setWordWrap(True)
        layout.addWidget(body)

        _card, inner = self._card(layout)
        row = QHBoxLayout()
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        label = QLabel("Izin modu")
        label.setObjectName("SettingsLabel")
        text_col.addWidget(label)
        hint = QLabel("ask: her arac icin onay, yolo: dogrudan, readonly: yalniz okuma")
        hint.setObjectName("SettingsHint")
        text_col.addWidget(hint)
        row.addLayout(text_col, 1)
        self.approval_combo = FluentCombo()
        self.approval_combo.addItems(["ask", "yolo", "readonly"])
        self.approval_combo.setCursor(Qt.PointingHandCursor)
        self.approval_combo.currentTextChanged.connect(
            self.app.set_approval_mode
        )
        row.addWidget(self.approval_combo)
        inner.addLayout(row)

        _card, inner = self._card(layout)
        row = QHBoxLayout()
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        label = QLabel("Araclar")
        label.setObjectName("SettingsLabel")
        text_col.addWidget(label)
        hint = QLabel("Dosya, kabuk ve web_fetch yetenekleri.")
        hint.setObjectName("SettingsHint")
        text_col.addWidget(hint)
        row.addLayout(text_col, 1)
        self.tools_check = FluentCheckBox("Etkin")
        self.tools_check.setCursor(Qt.PointingHandCursor)
        self.tools_check.toggled.connect(self.app.set_tools_enabled)
        row.addWidget(self.tools_check)
        inner.addLayout(row)

        _card, inner = self._card(layout)
        label = QLabel("Ayar dosyasi")
        label.setObjectName("SettingsLabel")
        inner.addWidget(label)
        path = QLabel(str(self.app.config.config_path))
        path.setObjectName("SettingsHint")
        path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        path.setWordWrap(True)
        inner.addWidget(path)
        layout.addStretch(1)
        return page

    def _shortcut_page(self) -> QWidget:
        page, layout = self._page()
        heading = QLabel("Kisayollar")
        heading.setObjectName("SettingsHeading")
        layout.addWidget(heading)
        body = QLabel("macOS'ta Ctrl tusu Cmd olarak calisir.")
        body.setObjectName("SettingsBody")
        body.setWordWrap(True)
        layout.addWidget(body)
        _card, inner = self._card(layout)
        for key, label_text in self.SHORTCUTS:
            row = QHBoxLayout()
            row.setSpacing(12)
            key_label = QLabel(key)
            key_label.setObjectName("ShortcutKey")
            key_label.setFont(_make_font(MONO_FONT, 10))
            key_label.setFixedWidth(118)
            key_label.setAlignment(Qt.AlignCenter)
            row.addWidget(key_label)
            desc = QLabel(label_text)
            desc.setObjectName("SettingsLabel")
            row.addWidget(desc, 1)
            inner.addLayout(row)
        layout.addStretch(1)
        return page

    # ------------------------------------------------------------- durum

    def sync_theme(self, current: str) -> None:
        for name, button in self._swatches.items():
            accent, _dim, _label = ACCENT_PRESETS[name]
            active = name == current
            border = "#f0f0f4" if active else "transparent"
            button.setStyleSheet(
                f"background-color: {accent}; border-radius: 11px; "
                f"border: 2px solid {border};"
            )
            button.setIcon(
                _line_icon("check", "#1b1b1d", 14) if active else QIcon()
            )
            button.setIconSize(QSize(14, 14))

    def sync_state(self) -> None:
        name = str(prefs().value("theme/accent", "banana"))
        self.sync_theme(name)
        motion = bool(prefs().value("ui/motion", True, type=bool))
        self.motion_check.blockSignals(True)
        self.motion_check.setChecked(motion)
        self.motion_check.blockSignals(False)
        visible = self.app._sidebar_visible
        self.sidebar_check.blockSignals(True)
        self.sidebar_check.setChecked(visible)
        self.sidebar_check.blockSignals(False)
        runtime = self.app.runtime
        if runtime is not None:
            index = self.approval_combo.findText(runtime.approver.mode)
            if index >= 0:
                self.approval_combo.blockSignals(True)
                self.approval_combo.setCurrentIndex(index)
                self.approval_combo.blockSignals(False)
            self.tools_check.blockSignals(True)
            self.tools_check.setChecked(bool(runtime.agent.tools_enabled))
            self.tools_check.blockSignals(False)


class FluentWindow(QMainWindow):
    def __init__(self, app: "GuiApp") -> None:
        super().__init__()
        self.app = app

    def closeEvent(self, event) -> None:
        self.app.handle_close_event(event)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.app._position_toast()


class GuiApp:
    def __init__(self, args, config, workdir: Path) -> None:
        self.args = args
        self.config = config
        self.workdir = Path(workdir)
        self.runtime: Runtime | None = None
        self.busy = False
        self._closed = False
        self._started = False
        self._syncing = False
        self._queue: queue.Queue = queue.Queue()
        self._pending_stream: list[str] = []
        self._in_assistant = False
        self._reasoning_open = False
        self._tabs: dict[Path, EditorTab] = {}
        self._welcome: QWidget | None = None
        self._tree_root = self.workdir
        self._loaded: set[str] = set()
        self._shortcuts: list[QShortcut] = []
        self._timer: QTimer | None = None
        self._files_card: QFrame | None = None
        self._sidebar_btn: QPushButton | None = None
        self._sidebar_width = 250
        self._sidebar_visible = True
        self._sidebar_anim: QPropertyAnimation | None = None
        self._palette: CommandPalette | None = None
        self._settings: SettingsDialog | None = None
        self._toast: Toast | None = None
        self._pulse_anim: QPropertyAnimation | None = None

        self.window = FluentWindow(self)
        self.window.setWindowTitle(f"Banana Coder {__version__}")
        self.window.setMinimumSize(1100, 640)
        self.ui = GuiUI(self)
        self._build()
        self._toast = Toast(self.window.centralWidget())
        preview.set_listener(self._on_preview)
        self.start()

    # ------------------------------------------------------------------ kurulum

    def _place_window(self) -> None:
        self.window.resize(1360, 860)
        try:
            stored = prefs().value("window/geometry")
        except Exception:
            stored = None
        if stored is not None and self.window.restoreGeometry(stored):
            return
        screen = QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        width = min(1400, max(1000, area.width() - 80))
        height = min(900, max(640, area.height() - 100))
        self.window.resize(width, height)
        frame = self.window.frameGeometry()
        frame.moveCenter(area.center())
        self.window.move(frame.topLeft())

    def _button(
        self, text: str, slot, kind: str = "ghost", icon: str | None = None
    ) -> QPushButton:
        button = RippleButton(text)
        button.setObjectName(
            {"accent": "AccentButton", "danger": "DangerButton"}.get(
                kind, "GhostButton"
            )
        )
        if icon:
            button.setIcon(_line_icon(icon, "#c9c9cf", 14))
            button.setIconSize(QSize(14, 14))
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(slot)
        return button

    def _icon_button(self, icon: str, tooltip: str, slot) -> QPushButton:
        button = RippleButton()
        button.setObjectName("IconButton")
        button.setIcon(_line_icon(icon, MUTED, 15))
        button.setIconSize(QSize(15, 15))
        button.setFixedSize(30, 30)
        button.setToolTip(tooltip)
        button.setAccessibleName(tooltip)
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(slot)
        return button

    def _build(self) -> None:
        self._place_window()
        central = QWidget()
        central.setObjectName("Root")
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._build_header())

        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(8)
        self._build_files()
        self._build_editor()
        self._build_chat()
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([250, 760, 440])
        layout.addWidget(self.splitter, 1)
        layout.addWidget(self._build_status())
        self.window.setCentralWidget(central)

        try:
            sidebar = bool(prefs().value("ui/sidebar", True, type=bool))
        except Exception:
            sidebar = True
        self._sidebar_visible = sidebar
        if not sidebar and self._files_card is not None:
            self._files_card.hide()
        self._set_sidebar_ui(sidebar)

    def _build_header(self) -> QFrame:
        header = QFrame()
        header.setObjectName("Header")
        header.setFixedHeight(62)
        row = QHBoxLayout(header)
        row.setContentsMargins(16, 10, 16, 10)
        row.setSpacing(8)

        row.addWidget(Logo(30))
        brand = QLabel("banana")
        brand.setObjectName("Brand")
        row.addWidget(brand)
        version = QLabel(f"v{__version__}")
        version.setObjectName("VersionChip")
        row.addWidget(version)

        separator = QFrame()
        separator.setObjectName("HeaderSep")
        separator.setFixedWidth(1)
        separator.setFixedHeight(26)
        row.addWidget(separator)

        self._sidebar_btn = self._icon_button(
            "panel",
            "Kenar cubugu (Ctrl+B)",
            lambda _checked=False: self.toggle_sidebar(),
        )
        row.addWidget(self._sidebar_btn)

        for text, slot, icon in (
            ("Klasor", self.open_folder, "folder"),
            ("Yeni", self.new_file, "plus"),
            ("Kaydet", self.save_current, "save"),
        ):
            row.addWidget(self._button(text, slot, icon=icon))

        row.addStretch(1)

        self._palette_btn = self._icon_button(
            "search",
            "Komut paleti (Ctrl+K)",
            lambda _checked=False: self.open_palette(),
        )
        row.addWidget(self._palette_btn)
        self._settings_btn = self._icon_button(
            "sliders",
            "Ayarlar (Ctrl+,)",
            lambda _checked=False: self.open_settings(),
        )
        row.addWidget(self._settings_btn)

        chip_row = QHBoxLayout()
        chip_row.setContentsMargins(0, 0, 0, 0)
        chip_row.setSpacing(6)
        self.model_dot = QLabel()
        self.model_dot.setObjectName("ModelDot")
        self.model_dot.setFixedSize(8, 8)
        self.model_dot.setProperty("state", "off")
        chip_row.addWidget(self.model_dot, 0, Qt.AlignVCenter)
        self.model_chip = QLabel("model yok")
        self.model_chip.setObjectName("ModelChip")
        self.model_chip.setToolTip("Aktif model")
        chip_row.addWidget(self.model_chip)
        row.addLayout(chip_row)

        field = QLabel("izin")
        field.setObjectName("FieldLabel")
        row.addWidget(field)

        self.approval_box = FluentCombo()
        self.approval_box.addItems(["ask", "yolo", "readonly"])
        self.approval_box.setToolTip("Arac izin modu")
        self.approval_box.currentTextChanged.connect(self._on_approval_changed)
        row.addWidget(self.approval_box)

        self.tools_check = FluentCheckBox("Araclar")
        self.tools_check.setChecked(True)
        self.tools_check.setCursor(Qt.PointingHandCursor)
        self.tools_check.toggled.connect(self._on_tools_toggled)
        row.addWidget(self.tools_check)

        return header

    def _build_files(self) -> None:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(7)
        head.addWidget(_glyph_label("folder", "#c2a95a", 12))
        title = QLabel("DOSYALAR")
        title.setObjectName("SectionTitle")
        head.addWidget(title)
        head.addStretch(1)
        refresh = QPushButton()
        refresh.setObjectName("IconButton")
        refresh.setIcon(_line_icon("refresh", MUTED, 13))
        refresh.setIconSize(QSize(13, 13))
        refresh.setFixedSize(24, 24)
        refresh.setToolTip("Dosya agacini yenile")
        refresh.setAccessibleName("Yenile")
        refresh.setCursor(Qt.PointingHandCursor)
        refresh.clicked.connect(self.refresh_tree)
        head.addWidget(refresh)
        layout.addLayout(head)

        root_row = QHBoxLayout()
        root_row.setContentsMargins(2, 0, 2, 0)
        root_row.setSpacing(6)
        self.tree_root_label = QLabel("")
        self.tree_root_label.setObjectName("RootName")
        root_row.addWidget(self.tree_root_label, 1)
        self.tree_count_label = QLabel("0")
        self.tree_count_label.setObjectName("CountChip")
        root_row.addWidget(self.tree_count_label)
        layout.addLayout(root_row)

        surface = QWidget()
        surface.setObjectName("TreeSurface")
        surface_layout = QVBoxLayout(surface)
        surface_layout.setContentsMargins(5, 5, 5, 5)
        surface_layout.setSpacing(0)

        self.tree = FileTree()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(15)
        self.tree.setAnimated(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setColumnCount(1)
        self.tree.setIconSize(QSize(15, 15))
        self.tree.setFrameShape(QFrame.NoFrame)
        self.tree.itemExpanded.connect(self._on_tree_expanded)
        self.tree.itemDoubleClicked.connect(self._on_tree_double_clicked)
        self.tree.itemActivated.connect(self._on_tree_activated)
        surface_layout.addWidget(self.tree)
        layout.addWidget(surface, 1)

        card.setMinimumWidth(180)
        self._files_card = card
        self.splitter.addWidget(card)

    def _build_editor(self) -> None:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(7)
        head.addWidget(_glyph_label("file", CYAN, 12))
        title = QLabel("EDITOR")
        title.setObjectName("SectionTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.editor_path_label = QLabel("")
        self.editor_path_label.setObjectName("CardHint")
        head.addWidget(self.editor_path_label)
        layout.addLayout(head)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("EditorTabs")
        self.tabs.setDocumentMode(True)
        self.tabs.tabBar().setDrawBase(False)
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setElideMode(Qt.ElideRight)
        self.tabs.tabCloseRequested.connect(self._on_tab_close_requested)
        self.tabs.currentChanged.connect(self._on_tab_changed)

        self._welcome = self._build_welcome()
        self.tabs.addTab(self._welcome, "baslangic")
        self.tabs.setTabIcon(0, _line_icon("spark", ACCENT, 13))
        self.tabs.tabBar().setTabButton(0, QTabBar.RightSide, None)
        layout.addWidget(self.tabs, 1)

        strip = QFrame()
        strip.setObjectName("EditorStrip")
        strip.setFixedHeight(24)
        strip_row = QHBoxLayout(strip)
        strip_row.setContentsMargins(6, 0, 6, 0)
        strip_row.setSpacing(10)
        self.editor_lang = QLabel("")
        self.editor_lang.setObjectName("LangChip")
        strip_row.addWidget(self.editor_lang)
        self.editor_pos = QLabel("")
        self.editor_pos.setObjectName("EditorMeta")
        strip_row.addWidget(self.editor_pos)
        strip_row.addStretch(1)
        self.editor_indent = QLabel("")
        self.editor_indent.setObjectName("EditorMeta")
        strip_row.addWidget(self.editor_indent)
        self.editor_encoding = QLabel("")
        self.editor_encoding.setObjectName("EditorMeta")
        strip_row.addWidget(self.editor_encoding)
        layout.addWidget(strip)
        self._update_editor_meta()

        card.setMinimumWidth(360)
        self.splitter.addWidget(card)

    def _build_welcome(self) -> QWidget:
        page = QWidget()
        page.setObjectName("WelcomePage")
        outer = QVBoxLayout(page)
        outer.setContentsMargins(30, 24, 30, 24)
        outer.setSpacing(10)
        outer.addStretch(1)

        logo_row = QHBoxLayout()
        logo_row.addStretch(1)
        logo_row.addWidget(Logo(64))
        logo_row.addStretch(1)
        outer.addLayout(logo_row)

        title = QLabel("Banana Coder")
        title.setObjectName("WelcomeTitle")
        title.setAlignment(Qt.AlignCenter)
        outer.addWidget(title)

        sub = QLabel(f"Masaustu IDE  ·  v{__version__}")
        sub.setObjectName("WelcomeSub")
        sub.setAlignment(Qt.AlignCenter)
        outer.addWidget(sub)

        tagline = QLabel("Yerel ve bulut modeller  ·  terminal hizinda masaustu deneyimi")
        tagline.setObjectName("CardHint")
        tagline.setAlignment(Qt.AlignCenter)
        outer.addWidget(tagline)

        outer.addSpacing(14)
        section = QLabel("HIZLI KOMUTLAR")
        section.setObjectName("SectionTitle")
        section.setAlignment(Qt.AlignCenter)
        outer.addWidget(section)

        cards = QWidget()
        cards_layout = QVBoxLayout(cards)
        cards_layout.setContentsMargins(0, 0, 0, 0)
        cards_layout.setSpacing(8)
        mod = "Cmd" if sys.platform == "darwin" else "Ctrl"
        shortcuts = (
            (f"{mod} + K", "Komut paletini ac"),
            (f"{mod} + S", "Dosyayi kaydet"),
            (f"{mod} + O", "Klasor sec"),
            (f"{mod} + B", "Kenar cubugu"),
            (f"{mod} + ,", "Ayarlar"),
        )
        for key, label in shortcuts:
            card = QFrame()
            card.setObjectName("WelcomeCard")
            card_layout = QHBoxLayout(card)
            card_layout.setContentsMargins(12, 8, 12, 8)
            card_layout.setSpacing(12)
            kbd = QLabel(key)
            kbd.setObjectName("Kbd")
            kbd.setFont(_make_font(MONO_FONT, 11))
            card_layout.addWidget(kbd)
            text = QLabel(label)
            text.setObjectName("WelcomeText")
            card_layout.addWidget(text)
            card_layout.addStretch(1)
            cards_layout.addWidget(card)

        holder = QHBoxLayout()
        holder.addStretch(1)
        holder.addWidget(cards, 3)
        holder.addStretch(1)
        outer.addLayout(holder)

        outer.addSpacing(10)
        hint = QLabel(
            "Enter gonder  ·  Shift+Enter yeni satir  ·  /help komutlar"
        )
        hint.setObjectName("CardHint")
        hint.setAlignment(Qt.AlignCenter)
        outer.addWidget(hint)
        outer.addStretch(1)
        return page

    def _build_chat(self) -> None:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(7)
        head.addWidget(_glyph_label("spark", ACCENT, 12))
        title = QLabel("SOHBET")
        title.setObjectName("SectionTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.chat_model_label = QLabel("")
        self.chat_model_label.setObjectName("CardHint")
        head.addWidget(self.chat_model_label)
        layout.addLayout(head)

        self.chat_view = ChatView()
        self.chat_welcome = ChatWelcome(self._suggestion_clicked)
        self.chat_view.add_banner(self.chat_welcome)
        layout.addWidget(self.chat_view, 1)

        composer = QFrame()
        composer.setObjectName("Composer")
        composer_layout = QHBoxLayout(composer)
        composer_layout.setContentsMargins(10, 6, 8, 6)
        composer_layout.setSpacing(8)
        self.input = ComposerEdit(composer)
        self.input.setPlaceholderText("Bir sey sor veya komut yaz...")
        self.input.submitted.connect(self.send)
        composer_layout.addWidget(self.input, 1)

        self.send_btn = QPushButton()
        self.send_btn.setObjectName("AccentButton")
        self.send_btn.setIcon(_send_icon())
        self.send_btn.setIconSize(QSize(18, 18))
        self.send_btn.setFixedSize(38, 38)
        self.send_btn.setCursor(Qt.PointingHandCursor)
        self.send_btn.setToolTip("Gonder (Enter)")
        self.send_btn.clicked.connect(self.send)
        composer_layout.addWidget(self.send_btn, 0, Qt.AlignBottom)
        layout.addWidget(composer)

        hint_row = QHBoxLayout()
        hint_row.setSpacing(8)
        self.mode_chip = QLabel("sohbet")
        self.mode_chip.setObjectName("ModeChip")
        self.mode_chip.setProperty("role", "chat")
        self.mode_chip.setToolTip("Komut icin /, kabuk icin ! ile basla")
        hint_row.addWidget(self.mode_chip)
        hint_row.addStretch(1)
        hint = QLabel("Enter gonder  ·  Shift+Enter yeni satir  ·  /help komutlar")
        hint.setObjectName("Hint")
        hint_row.addWidget(hint)
        layout.addLayout(hint_row)
        self.input.textChanged.connect(self._update_mode_chip)

        card.setMinimumWidth(300)
        self.splitter.addWidget(card)

    def _build_status(self) -> QWidget:
        holder = QWidget()
        holder.setObjectName("StatusHolder")
        column = QVBoxLayout(holder)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)

        self.busy_line = BusyLine(holder)
        column.addWidget(self.busy_line)

        status = QFrame()
        status.setObjectName("StatusBar")
        status.setFixedHeight(28)
        row = QHBoxLayout(status)
        row.setContentsMargins(14, 0, 14, 0)
        row.setSpacing(8)
        self.status_dot = QLabel()
        self.status_dot.setObjectName("StatusDot")
        self.status_dot.setFixedSize(7, 7)
        self.status_dot.setProperty("state", "idle")
        row.addWidget(self.status_dot, 0, Qt.AlignVCenter)
        self.status_label = QLabel("Hazir")
        self.status_label.setObjectName("StatusText")
        row.addWidget(self.status_label)
        self.activity_label = QLabel("")
        self.activity_label.setObjectName("ActivityText")
        row.addWidget(self.activity_label, 1)
        self.cwd_label = QLabel("")
        self.cwd_label.setObjectName("CwdText")
        row.addWidget(self.cwd_label)
        self.usage_label = QLabel("")
        self.usage_label.setObjectName("UsageText")
        self.usage_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row.addWidget(self.usage_label)
        column.addWidget(status)
        return holder

    def _set_status_state(self, state: str) -> None:
        for dot in (getattr(self, "model_dot", None), getattr(self, "status_dot", None)):
            if dot is None:
                continue
            dot.setProperty("state", state)
            self._repolish(dot)
        self._pulse_model_dot(state == "busy")

    def _pulse_model_dot(self, active: bool) -> None:
        dot = getattr(self, "model_dot", None)
        if dot is None:
            return
        animation = getattr(self, "_pulse_anim", None)
        if active:
            if animation is not None:
                return
            effect = QGraphicsOpacityEffect(dot)
            effect.setOpacity(1.0)
            dot.setGraphicsEffect(effect)
            animation = QPropertyAnimation(effect, b"opacity", dot)
            animation.setDuration(900)
            animation.setStartValue(1.0)
            animation.setKeyValueAt(0.5, 0.35)
            animation.setEndValue(1.0)
            animation.setLoopCount(-1)
            animation.start()
            self._pulse_anim = animation
        elif animation is not None:
            animation.stop()
            dot.setGraphicsEffect(None)
            animation.deleteLater()
            self._pulse_anim = None

    @staticmethod
    def _repolish(widget: QWidget) -> None:
        widget.style().unpolish(widget)
        widget.style().polish(widget)
        widget.update()

    def _install_shortcuts(self) -> None:
        for standard, slot in (
            (QKeySequence.Save, self.save_current),
            (QKeySequence.New, self.new_file),
            (QKeySequence.Open, self.open_folder),
            (QKeySequence.Close, self.close_current),
            ("Ctrl+R", self.refresh_all),
            ("Ctrl+K", self.open_palette),
            ("Ctrl+Shift+P", self.open_palette),
            ("Ctrl+B", lambda: self.toggle_sidebar()),
            ("Ctrl+,", self.open_settings),
        ):
            shortcut = QShortcut(QKeySequence(standard), self.window)
            shortcut.setContext(Qt.WindowShortcut)
            shortcut.activated.connect(slot)
            self._shortcuts.append(shortcut)

    # ------------------------------------------------------------------ arayuz

    def _set_sidebar_ui(self, visible: bool) -> None:
        button = getattr(self, "_sidebar_btn", None)
        if button is not None:
            button.setProperty("active", bool(visible))
            self._repolish(button)
            button.setToolTip(
                "Kenar cubugunu gizle (Ctrl+B)"
                if visible
                else "Kenar cubugunu goster (Ctrl+B)"
            )
            button.setAccessibleName(button.toolTip())
        settings = getattr(self, "_settings", None)
        if settings is not None:
            settings.sidebar_check.blockSignals(True)
            settings.sidebar_check.setChecked(bool(visible))
            settings.sidebar_check.blockSignals(False)

    def toggle_sidebar(self, show=None) -> None:
        card = self._files_card
        if card is None:
            return
        if show is None:
            show = not self._sidebar_visible
        show = bool(show)
        self._sidebar_visible = show
        prefs().setValue("ui/sidebar", show)
        self._set_sidebar_ui(show)
        if self._sidebar_anim is not None:
            self._sidebar_anim.stop()
            self._sidebar_anim = None
        if not motion_allowed():
            card.setMinimumWidth(180 if show else 0)
            card.setMaximumWidth(16777215)
            card.setVisible(show)
            return
        animation = QPropertyAnimation(card, b"maximumWidth", card)
        animation.setDuration(180)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        if show:
            card.setVisible(True)
            card.setMinimumWidth(180)
            card.setMaximumWidth(0)
            animation.setStartValue(0)
            animation.setEndValue(max(180, self._sidebar_width))
            animation.finished.connect(
                lambda: card.setMaximumWidth(16777215)
            )
        else:
            self._sidebar_width = max(180, card.width())
            card.setMinimumWidth(0)
            animation.setStartValue(card.width())
            animation.setEndValue(0)
            animation.finished.connect(card.hide)
        animation.start()
        self._sidebar_anim = animation

    def open_palette(self, _checked=False) -> None:
        if self._closed:
            return
        if self._palette is None:
            self._palette = CommandPalette(self)
        self._palette.prepare()
        frame = self._palette.frameGeometry()
        frame.moveCenter(self.window.geometry().center())
        self._palette.move(frame.topLeft())
        self._palette.show()
        self._palette.raise_()
        self._palette.activateWindow()

    def open_settings(self, _checked=False) -> None:
        if self._closed:
            return
        if self._settings is None:
            self._settings = SettingsDialog(self)
        self._settings.sync_state()
        frame = self._settings.frameGeometry()
        frame.moveCenter(self.window.geometry().center())
        self._settings.move(frame.topLeft())
        self._settings.show()
        self._settings.raise_()
        self._settings.activateWindow()

    def show_toast(self, text: str, kind: str = "ok") -> None:
        if self._toast is not None:
            self._toast.present(text, kind)

    def _position_toast(self) -> None:
        if self._toast is not None and self._toast.isVisible():
            self._toast.reposition()

    def set_accent(self, name: str) -> None:
        if name not in ACCENT_PRESETS:
            return
        app = QApplication.instance()
        if app is None:
            return
        apply_accent(app, name)
        if self._settings is not None:
            self._settings.sync_theme(name)
        if self._welcome is not None:
            index = self.tabs.indexOf(self._welcome)
            if index >= 0:
                self.tabs.setTabIcon(index, _line_icon("spark", ACCENT, 13))
        self.show_toast(f"Tema: {ACCENT_PRESETS[name][2]}", "ok")

    def set_motion(self, enabled: bool) -> None:
        enabled = bool(enabled)
        prefs().setValue("ui/motion", enabled)
        if hasattr(self, "chat_view"):
            self.chat_view._motion = enabled and motion_allowed()
        self.show_toast(
            "Hareketler acik" if enabled else "Hareketler kapali", "info"
        )

    def set_approval_mode(self, value: str) -> None:
        if self.runtime is None:
            self.show_toast("Model hazir degil.", "warn")
            return
        self.approval_box.setCurrentText(value)
        self.show_toast(f"Izin modu: {value}", "info")

    def set_tools_enabled(self, enabled: bool) -> None:
        if self.runtime is None:
            self.show_toast("Model hazir degil.", "warn")
            return
        self.tools_check.setChecked(bool(enabled))
        self.show_toast(
            "Araclar acik" if enabled else "Araclar kapali", "info"
        )

    def clear_chat(self) -> None:
        if self.busy:
            self.show_toast("Once mevcut islem bitsin.", "warn")
            return
        self.chat_view.reset()
        self.chat_welcome.show()
        self._in_assistant = False
        self._reasoning_open = False
        self._pending_stream.clear()
        self.show_toast("Sohbet temizlendi", "ok")

    def run_command(self, text: str) -> None:
        if not text:
            return
        self.input.setPlainText(text)
        self.send()

    def palette_commands(self) -> list[tuple[str, str, str, object]]:
        commands: list[tuple[str, str, str, object]] = [
            ("Kaydet", "Ctrl+S", "save", self.save_current),
            ("Yeni dosya", "Ctrl+N", "plus", self.new_file),
            ("Klasor ac", "Ctrl+O", "folder", self.open_folder),
            ("Dosya agacini yenile", "Ctrl+R", "refresh", self.refresh_all),
            ("Kenar cubugu", "Ctrl+B", "panel", lambda: self.toggle_sidebar()),
            ("Ayarlar", "Ctrl+,", "sliders", lambda: self.open_settings()),
            ("Sohbeti temizle", "", "close", self.clear_chat),
            ("/help komutlari", "", "terminal", lambda: self.run_command("/help")),
            ("/model listesi", "", "terminal", lambda: self.run_command("/models")),
        ]
        for tab in list(self._tabs.values()):
            commands.append(
                (
                    f"Dosya: {tab.path.name}",
                    str(tab.path),
                    "file",
                    lambda path=tab.path: self.open_file(path),
                )
            )
        for name, (_accent, _dim, label) in ACCENT_PRESETS.items():
            commands.append(
                (
                    f"Tema: {label}",
                    "vurgu rengi",
                    "spark",
                    lambda value=name: self.set_accent(value),
                )
            )
        return commands

    def _update_mode_chip(self) -> None:
        chip = getattr(self, "mode_chip", None)
        if chip is None:
            return
        text = self.input.toPlainText().lstrip()
        if text.startswith("!"):
            label, role = "kabuk", "shell"
        elif text.startswith("/"):
            label, role = "komut", "command"
        else:
            label, role = "sohbet", "chat"
        if chip.text() != label:
            chip.setText(label)
        if chip.property("role") != role:
            chip.setProperty("role", role)
            self._repolish(chip)

    # ------------------------------------------------------------------ calisma

    def start(self) -> None:
        if self._started or self._closed:
            return
        self._started = True
        self._install_shortcuts()
        self._timer = QTimer(self.window)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._drain)
        self._timer.start()
        QTimer.singleShot(80, self._boot)

    def run(self) -> int:
        self.start()
        self.window.show()
        app = QApplication.instance()
        return app.exec_() if app is not None else 0

    def post(self, op: str, *payload) -> None:
        if not self._closed:
            self._queue.put((op, payload))

    def _drain(self) -> None:
        if self._closed:
            return
        while True:
            try:
                op, payload = self._queue.get_nowait()
            except queue.Empty:
                break
            if self._closed:
                return
            if op == "stream":
                self._pending_stream.append(payload[0])
                continue
            if self._pending_stream:
                self._flush_stream()
            handler = getattr(self, f"_op_{op}", None)
            if handler is None:
                continue
            try:
                handler(*payload)
            except Exception:
                traceback.print_exc()
        if self._pending_stream:
            self._flush_stream()

    def _flush_stream(self) -> None:
        if not self._pending_stream:
            return
        text = "".join(self._pending_stream)
        self._pending_stream.clear()
        if not text:
            return
        if not self._in_assistant:
            self.chat_view.begin_assistant()
            self._in_assistant = True
        self.chat_view.append_assistant(text)

    # ------------------------------------------------------------------ op'lar

    def _op_line(self, text: str, tag: str = "system") -> None:
        text = str(text).rstrip("\n")
        if not text.strip():
            return
        if self._in_assistant:
            self._op_assistant_end()
        self.chat_view.add_system(text, tag)

    def _op_assistant_start(self) -> None:
        if self._in_assistant:
            self._op_assistant_end()
        self.chat_view.begin_assistant()
        self._in_assistant = True

    def _op_assistant_end(self) -> None:
        if self._reasoning_open:
            self._op_break_thinking()
        if self._in_assistant:
            self.chat_view.end_assistant()
            self._in_assistant = False

    def _op_thinking(self, text: str) -> None:
        if not self._reasoning_open:
            if self._in_assistant:
                self.chat_view.end_assistant()
                self._in_assistant = False
            self.chat_view.begin_thinking()
            self._reasoning_open = True
        self.chat_view.append_thinking(text)

    def _op_break_thinking(self) -> None:
        if self._reasoning_open:
            self.chat_view.end_thinking()
            self._reasoning_open = False

    def _op_tool_call(self, name: str, summary: str) -> None:
        if self._reasoning_open:
            self._op_break_thinking()
        if self._in_assistant:
            self._op_assistant_end()
        self.chat_view.add_tool(name, summary)

    def _op_tool_result(self, ok: bool, summary: str) -> None:
        self.chat_view.add_tool_result(ok, summary)

    def _op_usage(
        self,
        input_tokens: int,
        output_tokens: int,
        elapsed: float,
        cost: float | None,
    ) -> None:
        parts = [f"{input_tokens} in", f"{output_tokens} out", f"{elapsed:.1f}s"]
        if cost is not None:
            parts.append(f"${cost:.4f}")
        self.usage_label.setText("  ·  ".join(parts))

    def _op_status(self, message: str) -> None:
        self.status_label.setText(
            message if message else ("Calisiyor..." if self.busy else "Hazir")
        )

    def _op_activity(self, line: str) -> None:
        self.activity_label.setText(_shorten(line, 110))

    def _op_close(self) -> None:
        self._on_close(force=True)

    def _op_done(self) -> None:
        if self._closed:
            return
        self.busy = False
        self.send_btn.setEnabled(True)
        self.busy_line.set_active(False)
        self._set_status_state("idle")
        self._sync_runtime_ui()
        self.refresh_tree()
        self.reload_open_tabs()
        self.status_label.setText("Hazir")
        self.input.setFocus()

    def _op_call(self, function) -> None:
        function()

    # ------------------------------------------------------------------ sohbet

    def send(self, _checked=False) -> None:
        if self.busy:
            self.set_activity("Once mevcut islem bitsin.")
            return
        if self.runtime is None:
            self.chat_view.add_system(
                "Model hazir degil. Terminalde /api ve /model ile ayarla; "
                "ardindan banana --gui calistir.",
                "warn",
            )
            return
        text = self.input.toPlainText().strip()
        if not text:
            return
        self.input.clear()
        if self._pending_stream:
            self._flush_stream()
        self.chat_view.end_assistant()
        self.chat_view.end_thinking()
        self._in_assistant = False
        self._reasoning_open = False
        self.chat_view.add_user(text)
        self.chat_welcome.hide()
        self.busy = True
        self.send_btn.setEnabled(False)
        self.status_label.setText("Calisiyor...")
        self._set_status_state("busy")
        self.busy_line.set_active(True)
        threading.Thread(target=self._worker, args=(text,), daemon=True).start()

    def _worker(self, text: str) -> None:
        runtime = self.runtime
        if runtime is None:
            self.post("done")
            return
        try:
            if text.startswith("!"):
                _run_bang(runtime, text[1:].strip())
            elif text.startswith("/"):
                if _handle_slash(runtime, text) == "quit":
                    self.post("close")
                    return
            else:
                prompt = _expand_file_refs(text, runtime.agent.ctx.cwd)
                result = runtime.agent.run_turn(prompt)
                if not result.text and result.tool_rounds == 0:
                    self.ui.info("(model bos yanit dondurdu)")
                _speak_turn(runtime, result.text)
        except KeyboardInterrupt:
            self.ui.warn("Durduruldu.")
        except ProviderError as exc:
            self.ui.error(str(exc))
            self.ui.info(
                f"Aktif model: {_model_label(runtime.provider_name, runtime.model)}"
            )
            if exc.status_code == 429:
                self.ui.info("Baska bir model dene: /model veya /models free")
        except Exception as exc:
            self.ui.error(f"Beklenmeyen hata: {type(exc).__name__}: {exc}")
            traceback.print_exc()
        finally:
            self.post("done")

    # ------------------------------------------------------------------ dosyalar

    def _visible(self, path: Path) -> bool:
        name = path.name
        if name.startswith("."):
            return False
        if name in SKIP_DIRS:
            return False
        try:
            if path.is_symlink():
                return False
        except OSError:
            return False
        return True

    @staticmethod
    def _is_dir(path: Path) -> bool:
        try:
            return path.is_dir()
        except OSError:
            return False

    def _expanded_paths(self) -> set[str]:
        expanded: set[str] = set()

        def walk(item: QTreeWidgetItem) -> None:
            for index in range(item.childCount()):
                child = item.child(index)
                raw = child.data(0, Qt.UserRole)
                if raw and child.isExpanded():
                    expanded.add(str(raw))
                if child.childCount():
                    walk(child)

        walk(self.tree.invisibleRootItem())
        return expanded

    def refresh_tree(self, *_args) -> None:
        expanded = self._expanded_paths()
        self.tree.clear()
        self._loaded.clear()
        if self._tree_root.is_dir():
            self._populate(None, self._tree_root, expanded)
        self.tree_root_label.setText(
            self._tree_root.name or str(self._tree_root)
        )
        self.tree_root_label.setToolTip(str(self._tree_root))
        count = self.tree.topLevelItemCount()
        self.tree_count_label.setText(str(count))
        self.tree_count_label.setToolTip(f"{count} ust duzey oge")

    def _populate(
        self, parent: QTreeWidgetItem | None, path: Path, expanded: set[str]
    ) -> None:
        try:
            entries = sorted(
                path.iterdir(),
                key=lambda item: (
                    0 if self._is_dir(item) else 1,
                    item.name.lower(),
                ),
            )
        except OSError:
            return
        for child in entries:
            if not self._visible(child):
                continue
            item = (
                QTreeWidgetItem(parent, [child.name])
                if parent is not None
                else QTreeWidgetItem(self.tree, [child.name])
            )
            item.setData(0, Qt.UserRole, str(child))
            item.setToolTip(0, str(child))
            item.setIcon(0, _file_icon(child))
            if self._is_dir(child):
                QTreeWidgetItem(item, [" "])
                if str(child) in expanded:
                    item.takeChildren()
                    self._populate(item, child, expanded)
                    item.setExpanded(True)
                    self._loaded.add(str(child))
            else:
                self._loaded.add(str(child))

    def _on_tree_expanded(self, item: QTreeWidgetItem) -> None:
        raw = item.data(0, Qt.UserRole)
        if not raw:
            return
        path = Path(str(raw))
        if not self._is_dir(path):
            return
        key = str(path)
        if key in self._loaded:
            return
        self._loaded.add(key)
        while item.childCount():
            item.takeChild(0)
        self._populate(item, path, set())

    def _on_tree_double_clicked(self, item: QTreeWidgetItem, _column: int) -> None:
        self._activate_tree_item(item)

    def _on_tree_activated(self, item: QTreeWidgetItem, _column: int) -> None:
        self._activate_tree_item(item)

    def _activate_tree_item(self, item: QTreeWidgetItem) -> None:
        raw = item.data(0, Qt.UserRole)
        if not raw:
            return
        path = Path(str(raw))
        if self._is_dir(path):
            item.setExpanded(not item.isExpanded())
        else:
            self.open_file(path)

    def _remove_welcome(self) -> None:
        if self._welcome is None:
            return
        index = self.tabs.indexOf(self._welcome)
        if index >= 0:
            self.tabs.removeTab(index)
        self._welcome.deleteLater()
        self._welcome = None

    def open_file(self, path: Path) -> None:
        path = Path(path).expanduser()
        try:
            path = path.resolve()
        except OSError:
            return
        if path.is_dir():
            return
        tab = self._tabs.get(path)
        if tab is None:
            self._remove_welcome()
            tab = EditorTab(self, path)
            self._tabs[path] = tab
            index = self.tabs.addTab(tab, path.name)
            self.tabs.setTabIcon(index, _file_icon(path))
            self.tabs.setTabToolTip(index, str(path))
            tab.load()
        self.tabs.setCurrentWidget(tab)
        tab.editor.setFocus()

    def update_tab_title(self, tab: EditorTab) -> None:
        index = self.tabs.indexOf(tab)
        if index < 0:
            return
        self.tabs.setTabText(
            index, ("* " if tab.modified else "") + tab.path.name
        )
        if tab is self.current_tab():
            self._set_editor_path(tab.path)
            self._update_editor_meta()

    def _set_editor_path(self, path: Path | None) -> None:
        text = str(path) if path is not None else ""
        self.editor_path_label.setToolTip(text)
        self.editor_path_label.setText(
            self.editor_path_label.fontMetrics().elidedText(
                text, Qt.ElideMiddle, 280
            )
        )

    def _update_editor_meta(self) -> None:
        if not hasattr(self, "editor_lang"):
            return
        tab = self.current_tab()
        if tab is None:
            self.editor_lang.setText("")
            self.editor_lang.hide()
            self.editor_pos.setText("")
            self.editor_indent.setText("")
            self.editor_encoding.setText("")
            return
        self.editor_lang.setText(
            _LANGUAGES.get(tab.path.suffix.lower(), "Metin")
        )
        self.editor_lang.show()
        cursor = tab.editor.textCursor()
        self.editor_pos.setText(
            f"Ln {cursor.blockNumber() + 1}, Col {cursor.columnNumber() + 1}"
        )
        self.editor_indent.setText("4 bosluk")
        self.editor_encoding.setText("UTF-8")

    def _on_cursor_moved(self) -> None:
        self._update_editor_meta()

    def current_tab(self) -> EditorTab | None:
        widget = self.tabs.currentWidget()
        return widget if isinstance(widget, EditorTab) else None

    def reload_open_tabs(self) -> None:
        for tab in list(self._tabs.values()):
            tab.reload_from_disk()

    def save_current(self) -> None:
        tab = self.current_tab()
        if tab is None:
            self.set_activity("Kaydedilecek acik dosya yok.")
            return
        if tab.save():
            self.set_activity(f"Kaydedildi: {tab.path.name}")
            self.show_toast(f"Kaydedildi: {tab.path.name}", "ok")

    def close_current(self) -> None:
        widget = self.tabs.currentWidget()
        if widget is self._welcome:
            self._remove_welcome()
            return
        if isinstance(widget, EditorTab):
            self._close_tab(widget)

    def _on_tab_close_requested(self, index: int) -> None:
        widget = self.tabs.widget(index)
        if widget is self._welcome:
            self._remove_welcome()
            return
        if isinstance(widget, EditorTab):
            self._close_tab(widget)

    def _close_tab(self, tab: EditorTab) -> None:
        if tab.modified and not self._confirm_save(tab):
            return
        index = self.tabs.indexOf(tab)
        if index >= 0:
            self.tabs.removeTab(index)
        self._tabs.pop(tab.path, None)
        tab.deleteLater()

    def _confirm_save(self, tab: EditorTab) -> bool:
        box = QMessageBox(self.window)
        box.setWindowTitle("Degisiklikler")
        box.setText(f"{tab.path.name} degisti. Kaydedilsin mi?")
        save = box.addButton("Kaydet", QMessageBox.AcceptRole)
        box.addButton("Vazgec", QMessageBox.DestructiveRole)
        cancel = box.addButton("Iptal", QMessageBox.RejectRole)
        box.exec_()
        clicked = box.clickedButton()
        if clicked is save:
            return tab.save()
        if clicked is None or clicked is cancel:
            return False
        return True

    def new_file(self) -> None:
        initial = str(self._tree_root / "yeni_dosya.txt")
        raw, accepted = QInputDialog.getText(
            self.window,
            "Yeni dosya",
            "Dosya yolu:",
            QLineEdit.Normal,
            initial,
        )
        if not accepted or not raw:
            return
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = self._tree_root / path
        if path.is_dir():
            QMessageBox.warning(
                self.window, "Gecersiz yol", f"{path} bir dizin."
            )
            return
        self.open_file(path)

    def open_folder(self) -> None:
        chosen = QFileDialog.getExistingDirectory(
            self.window, "Calisma klasoru sec", str(self._tree_root)
        )
        if chosen:
            self.set_cwd(Path(chosen))

    def set_cwd(self, path: Path) -> None:
        try:
            path = Path(path).expanduser().resolve()
        except OSError as exc:
            self.set_activity(f"Yol cozumlenemedi: {exc}")
            return
        if not path.is_dir():
            self.set_activity(f"Dizin bulunamadi: {path}")
            return
        try:
            os.chdir(path)
        except OSError:
            pass
        self._tree_root = path
        self.workdir = path
        runtime = self.runtime
        if runtime is not None:
            runtime.agent.set_cwd(path)
            runtime.session.cwd = path
            if runtime.persist:
                try:
                    runtime.session.save()
                except OSError:
                    pass
            runtime.ui.info(f"Calisma dizini: {path}")
        self.refresh_tree()
        self.cwd_label.setText(path.name or str(path))
        self.cwd_label.setToolTip(str(path))
        self.chat_view.add_system(f"Dizin: {path}", "muted")
        self.set_activity(f"Dizin: {path}")
        self.show_toast(f"Dizin: {path.name or path}", "info")

    def refresh_all(self) -> None:
        self.refresh_tree()
        self.reload_open_tabs()
        self.set_activity("Yenilendi.")
        self.show_toast("Dosya agaci yenilendi", "info")

    # ------------------------------------------------------------------ durum

    def set_activity(self, text: str) -> None:
        self.activity_label.setText(_shorten(text, 120))

    def _sync_runtime_ui(self) -> None:
        runtime = self.runtime
        if runtime is None:
            self._set_status_state("off")
            self.cwd_label.setText("")
            return
        self._syncing = True
        try:
            cwd = Path(runtime.agent.ctx.cwd)
            if cwd != self._tree_root:
                self._tree_root = cwd
                self.workdir = cwd
                self.refresh_tree()
            label = _model_label(runtime.provider_name, runtime.model)
            self.model_chip.setText(label)
            self.chat_model_label.setText(label)
            self.cwd_label.setText(cwd.name or str(cwd))
            self.cwd_label.setToolTip(str(cwd))
            index = self.approval_box.findText(runtime.approver.mode)
            if index >= 0:
                self.approval_box.setCurrentIndex(index)
            self.tools_check.setChecked(bool(runtime.agent.tools_enabled))
            usage = runtime.session.usage
            parts = [f"{usage.input_tokens} in", f"{usage.output_tokens} out"]
            if usage.cost is not None:
                parts.append(f"${usage.cost:.4f}")
            self.usage_label.setText("  ·  ".join(parts))
            self.window.setWindowTitle(
                f"Banana Coder - {label} - {cwd.name}"
            )
        finally:
            self._syncing = False

    def _on_approval_changed(self, value: str) -> None:
        if self._syncing or self.runtime is None:
            return
        self.runtime.approver.set_mode(value)
        self.runtime.config.approval = value
        self.ui.info(f"Izin modu: {value}")

    def _on_tools_toggled(self, checked: bool) -> None:
        if self._syncing or self.runtime is None:
            return
        self.runtime.agent.set_tools_enabled(bool(checked))
        _remember_tool_support(self.runtime, bool(checked))
        if checked:
            self.ui.info("Araclar acik: dosya, kabuk ve web_fetch kullanilabilir.")
        else:
            self.ui.info("Araclar kapali: model yalnizca sohbet eder.")

    def _on_tab_changed(self, index: int) -> None:
        widget = self.tabs.widget(index)
        if isinstance(widget, EditorTab):
            self._set_editor_path(widget.path)
        else:
            self._set_editor_path(None)
        self._update_editor_meta()

    def _on_preview(self, line: str) -> None:
        if line:
            self.post("activity", line)

    # ------------------------------------------------------------------ baslat/kapat

    def _show_welcome(self, note: str) -> None:
        runtime = self.runtime
        if runtime is None:
            return
        self.chat_welcome.set_context(
            _model_label(runtime.provider_name, runtime.model),
            str(runtime.agent.ctx.cwd),
        )
        if note:
            self.chat_view.add_system(note, "muted")

    def _suggestion_clicked(self, text: str) -> None:
        if self.runtime is None:
            self.chat_view.add_system(
                "Model hazir degil. Terminalde /api ve /model ile ayarla.",
                "warn",
            )
            return
        self.input.setPlainText(text)
        self.send()

    def _boot(self) -> None:
        if self._closed:
            return
        try:
            prepared = _prepare_runtime(
                args=self.args,
                config=self.config,
                workdir=self.workdir,
                ui=self.ui,
                one_shot=False,
            )
        except Exception as exc:
            self.ui.error(f"Baslatma hatasi: {exc}")
            traceback.print_exc()
            return
        if prepared is None:
            self.ui.warn(
                "Model hazir degil. Model ve API anahtarini terminalde ayarla, "
                "ardindan banana --gui calistir."
            )
            self.status_label.setText("Model hazir degil")
            self._set_status_state("off")
            return
        self.runtime, note = prepared
        self._sync_runtime_ui()
        self._set_status_state("idle")
        self.refresh_tree()
        self._show_welcome(note)
        self.status_label.setText("Hazir")
        self.input.setFocus()

    def handle_close_event(self, event) -> None:
        if self._closed:
            event.accept()
            return
        if self.busy:
            box = QMessageBox(self.window)
            box.setWindowTitle("Banana Coder")
            box.setText("Model hala calisiyor. Pencere kapatilsin mi?")
            box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            box.setDefaultButton(QMessageBox.No)
            if box.exec_() != QMessageBox.Yes:
                event.ignore()
                return
        self._shutdown()
        event.accept()

    def _on_close(self, force: bool = False) -> None:
        if self._closed:
            return
        if self.busy and not force:
            box = QMessageBox(self.window)
            box.setWindowTitle("Banana Coder")
            box.setText("Model hala calisiyor. Pencere kapatilsin mi?")
            box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            box.setDefaultButton(QMessageBox.No)
            if box.exec_() != QMessageBox.Yes:
                return
        self._shutdown()
        self.window.close()

    def _shutdown(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._timer is not None:
            self._timer.stop()
        try:
            settings = prefs()
            settings.setValue("window/geometry", self.window.saveGeometry())
            if self._files_card is not None:
                settings.setValue("ui/sidebar", self._sidebar_visible)
            settings.sync()
        except Exception:
            pass
        preview.set_listener(None)
        runtime = self.runtime
        if runtime is not None:
            if runtime.persist and runtime.session.messages:
                try:
                    runtime.session.save()
                except OSError:
                    pass
            try:
                runtime.provider.close()
            except Exception:
                pass

    # ------------------------------------------------------------------ sorular

    def request(self, function):
        if self._closed:
            return None
        if threading.current_thread() is threading.main_thread():
            return function()
        done = threading.Event()
        box: dict = {}

        def runner() -> None:
            try:
                box["value"] = function()
            except Exception as exc:
                box["error"] = exc
            finally:
                done.set()

        self.post("call", runner)
        done.wait()
        if "error" in box:
            raise box["error"]
        return box.get("value")

    def ask_approval(self, prompt: str) -> str:
        if self._closed:
            return "no"
        answer = self.request(lambda: self._approval_dialog(prompt))
        return answer if answer in ("yes", "all") else "no"

    def ask_string(
        self, prompt: str, default: str = "", *, secret: bool = False
    ) -> str:
        if self._closed:
            return default
        answer = self.request(lambda: self._string_dialog(prompt, default, secret))
        return default if answer is None else answer

    def ask_choice(
        self, prompt: str, choices: list[str], default: str = ""
    ) -> str:
        if self._closed or not choices:
            return default
        answer = self.request(
            lambda: self._choice_dialog(prompt, choices, default)
        )
        return default if answer is None else answer

    def _dialog_shell(self, title: str, body: str) -> tuple[QDialog, QVBoxLayout]:
        dialog = QDialog(self.window)
        dialog.setObjectName("FluentDialog")
        dialog.setWindowTitle(title)
        dialog.setModal(True)
        dialog.setMinimumWidth(440)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(12)
        heading = QLabel(title)
        heading.setObjectName("DialogTitle")
        layout.addWidget(heading)
        if body:
            label = QLabel(body)
            label.setObjectName("DialogBody")
            label.setWordWrap(True)
            label.setTextFormat(Qt.PlainText)
            layout.addWidget(label)
        return dialog, layout

    def _string_dialog(self, prompt: str, default: str, secret: bool) -> str:
        dialog, layout = self._dialog_shell("Banana Coder", prompt)
        edit = QLineEdit(default)
        if secret:
            edit.setEchoMode(QLineEdit.Password)
        edit.selectAll()
        layout.addWidget(edit)

        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self._button("Iptal", dialog.reject))
        row.addWidget(self._button("Tamam", dialog.accept, "accent"))
        layout.addLayout(row)
        edit.returnPressed.connect(dialog.accept)
        edit.setFocus()
        if dialog.exec_() == QDialog.Accepted:
            return edit.text().strip()
        return default

    def _approval_dialog(self, prompt: str) -> str:
        dialog, layout = self._dialog_shell("Onay gerekli", prompt)
        dialog._value = "no"
        row = QHBoxLayout()
        row.addStretch(1)

        def choose(value: str) -> None:
            dialog._value = value
            dialog.accept()

        row.addWidget(self._button("Tumu", lambda: choose("all")))
        row.addWidget(self._button("Hayir", lambda: choose("no"), "danger"))
        row.addWidget(self._button("Evet", lambda: choose("yes"), "accent"))
        layout.addLayout(row)
        dialog.exec_()
        return getattr(dialog, "_value", "no")

    def _choice_dialog(self, prompt: str, choices: list[str], default: str) -> str:
        dialog, layout = self._dialog_shell("Secim", prompt)
        dialog.resize(660, 440)
        dialog._value = default

        listing = QListWidget()
        listing.setSelectionMode(QAbstractItemView.SingleSelection)
        listing.addItems(choices)
        if default in choices:
            listing.setCurrentRow(choices.index(default))
        layout.addWidget(listing, 1)

        def choose(value: str | None = None) -> None:
            if value is None:
                item = listing.currentItem()
                value = item.text() if item is not None else default
            dialog._value = value
            dialog.accept()

        listing.itemActivated.connect(lambda _item: choose())

        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self._button("Iptal", dialog.reject))
        row.addWidget(self._button("Sec", choose, "accent"))
        layout.addLayout(row)
        listing.setFocus()
        dialog.exec_()
        return getattr(dialog, "_value", default)


def run_gui(args, config, workdir: Path) -> int:
    instance = QApplication.instance()
    if instance is None:
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
        app = QApplication([sys.argv[0]])
    else:
        app = instance
    _configure_application(app)
    try:
        gui = GuiApp(args, config, Path(workdir))
    except Exception as exc:
        print(f"HATA: Masaustu arayuz acilamadi: {exc}", file=sys.stderr)
        print("PyQt5 gerekli: pip install PyQt5", file=sys.stderr)
        return 1
    gui.window.show()
    gui.start()
    return app.exec_()
