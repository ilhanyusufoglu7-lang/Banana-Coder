from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Iterator

from banana.config import PROVIDER_LABELS
from banana.models import Event, Message, StreamDone, TextDelta, ToolSpec, Usage
from banana.net import ProviderError
from banana.providers.base import Provider


class LocalProvider(Provider):
    name = "local"

    def __init__(
        self,
        model_path: str | Path,
        *,
        n_ctx: int = 4096,
        n_threads: int | None = None,
        n_batch: int = 512,
        verbose: bool = False,
    ) -> None:
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise ProviderError(
                f"Yerel model dosyasi bulunamadi: {path}\n"
                f"Gecerli bir .gguf yolu ver ya da BANANA_LOCAL_MODEL ortam degiskeni ayarla."
            )
        self.model_path = path
        self.n_ctx = n_ctx
        self.n_threads = n_threads or max(1, (os.cpu_count() or 4) // 2)
        self.n_batch = n_batch
        self.verbose = verbose
        self._llm: Any | None = None
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise ProviderError(
                "Yerel modeller icin 'llama-cpp-python' kurulu degil.\n"
                "Kurulum: pip install llama-cpp-python"
            ) from exc
        self._Llama = Llama

    def close(self) -> None:
        if self._llm is not None:
            try:
                self._llm.close()
            except Exception:
                pass
            self._llm = None

    @property
    def label(self) -> str:
        return PROVIDER_LABELS.get(self.name, self.name)

    def _load(self) -> Any:
        if self._llm is None:
            try:
                self._llm = self._Llama(
                    model_path=str(self.model_path),
                    n_ctx=self.n_ctx,
                    n_threads=self.n_threads,
                    n_batch=self.n_batch,
                    verbose=self.verbose,
                )
            except Exception as exc:
                raise ProviderError(
                    f"Yerel model yuklenemedi: {self.model_path}\nHata: {exc}"
                ) from exc
        return self._llm

    @staticmethod
    def _to_chat_messages(messages: list[Message]) -> list[dict[str, str]]:
        return [
            {"role": message.role, "content": message.content}
            for message in messages
            if message.content
        ]

    def stream(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None = None,
    ) -> Iterator[Event]:
        llm = self._load()
        chat_messages: list[dict[str, str]] = []
        if system:
            chat_messages.append({"role": "system", "content": system})
        chat_messages.extend(self._to_chat_messages(messages))

        kwargs: dict[str, Any] = {
            "messages": chat_messages,
            "max_tokens": max_tokens,
            "stream": True,
        }
        if temperature is not None:
            kwargs["temperature"] = temperature

        try:
            stream = llm.create_chat_completion(**kwargs)
        except Exception as exc:
            raise ProviderError(
                f"{self.label}: yerel model istegi basarisiz oldu: {exc}"
            ) from exc

        partial: list[str] = []
        try:
            for chunk in stream:
                choices = chunk.get("choices") if isinstance(chunk, dict) else None
                if not isinstance(choices, list) or not choices:
                    continue
                delta = choices[0].get("delta") if isinstance(choices[0], dict) else None
                if not isinstance(delta, dict):
                    continue
                text = delta.get("content")
                if text:
                    partial.append(text)
                    yield TextDelta(text=text)
        except Exception as exc:
            raise ProviderError(
                f"{self.label}: yerel model akisi kesildi: {exc}"
            ) from exc

        content = "".join(partial)
        message = Message(role="assistant", content=content)
        usage = Usage()
        try:
            prompt_tokens = llm.input_tokens if hasattr(llm, "input_tokens") else 0
            completion_tokens = (
                llm.output_tokens if hasattr(llm, "output_tokens") else 0
            )
            usage = Usage(
                input_tokens=int(prompt_tokens or 0),
                output_tokens=int(completion_tokens or 0),
            )
        except Exception:
            pass
        yield StreamDone(message=message, usage=usage, stop_reason="stop", model=str(self.model_path.name))
