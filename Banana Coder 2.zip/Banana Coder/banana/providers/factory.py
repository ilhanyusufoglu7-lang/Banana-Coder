from __future__ import annotations

import os

from banana.config import KEY_ENV, PROVIDER_LABELS, PROVIDERS, Config
from banana.models import parse_model
from banana.net import ProviderError
from banana.providers.anthropic import AnthropicProvider
from banana.providers.base import Provider
from banana.providers.gemini import GeminiProvider
from banana.providers.local import LocalProvider
from banana.providers.openai_compat import OpenAIProvider, OpenRouterProvider


class MissingKeyError(ProviderError):
    pass


def missing_key_message(provider: str) -> str:
    label = PROVIDER_LABELS.get(provider, provider)
    env_names = " veya ".join(KEY_ENV.get(provider, ()))
    return (
        f"{label} icin API anahtari bulunamadi.\n"
        f"REPL icinde `/api {provider}` yazarak anahtari kaydedebilir, "
        f"ya da {env_names} ortam degiskenini ayarlayabilirsin."
    )


def local_model_path(config: Config, model: str | None = None) -> str:
    path = (model or "").strip() or (config.local_model_path or "").strip()
    if not path:
        path = os.environ.get("BANANA_LOCAL_MODEL", "").strip()
    if not path:
        raise ProviderError(
            "Yerel GGUF modeli secili degil.\n"
            "REPL icinde `/model local` yazip model klaserindeki bir .gguf dosyasini sec,\n"
            "ya da BANANA_LOCAL_MODEL ortam degiskenine dosya yolunu ver."
        )
    return path


def create_provider(
    config: Config,
    provider: str,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    timeout: float | None = None,
    model: str | None = None,
) -> Provider:
    provider = provider.lower()
    if provider not in PROVIDERS:
        raise ProviderError(
            f"Bilinmeyen saglayici: {provider}. Gecerli secenekler: {', '.join(PROVIDERS)}"
        )
    if provider == "local":
        return LocalProvider(local_model_path(config, model))
    key = (api_key or config.api_key(provider) or "").strip()
    if not key:
        raise MissingKeyError(missing_key_message(provider), provider=provider)
    url = base_url or config.base_url(provider)
    client_timeout = timeout if timeout is not None else config.request_timeout

    if provider == "openrouter":
        return OpenRouterProvider(key, url, client_timeout)
    if provider == "openai":
        return OpenAIProvider(key, url, client_timeout)
    if provider == "anthropic":
        return AnthropicProvider(key, url, client_timeout)
    if provider == "gemini":
        return GeminiProvider(key, url, client_timeout)
    raise ProviderError(f"Desteklenmeyen saglayici: {provider}")


def create_for_model(
    config: Config, model_spec: str, default_provider: str | None = None
) -> tuple[Provider, str]:
    provider_name, model = parse_model(model_spec, default_provider)
    if provider_name == "local":
        path = local_model_path(config, model)
        return create_provider(config, "local", model=path), path
    return create_provider(config, provider_name), model
