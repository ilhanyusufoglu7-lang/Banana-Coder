from __future__ import annotations

import json
from typing import Any, Iterator
from urllib.parse import quote

import httpx

from banana.models import (
    Event,
    Message,
    StreamDone,
    TextDelta,
    ThinkingDelta,
    ToolCall,
    ToolSpec,
    Usage,
)
from banana.net import ProviderError, iter_sse, stream_request
from banana.providers.base import Provider

_ALLOWED_SCHEMA_KEYS = {
    "type",
    "description",
    "properties",
    "required",
    "items",
    "enum",
    "nullable",
    "format",
    "minimum",
    "maximum",
    "minItems",
    "maxItems",
    "pattern",
    "title",
}


def _clean_schema(node: Any) -> Any:
    if isinstance(node, dict):
        return {
            key: _clean_schema(value)
            for key, value in node.items()
            if key in _ALLOWED_SCHEMA_KEYS
        }
    if isinstance(node, list):
        return [_clean_schema(item) for item in node]
    return node


def _tool_response(message: Message) -> dict[str, Any]:
    text = message.content or ""
    if message.is_error:
        return {"error": text}
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return {"result": text}
    if isinstance(parsed, dict):
        return parsed
    return {"result": parsed}


class GeminiProvider(Provider):
    name = "gemini"

    def _headers(self) -> dict[str, str]:
        return {
            "x-goog-api-key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

    def _url(self, model: str) -> str:
        model_name = model[7:] if model.startswith("models/") else model
        base = self.base_url
        if base.endswith(":streamGenerateContent"):
            return base
        return f"{base}/models/{quote(model_name, safe='')}:streamGenerateContent?alt=sse"

    def _contents(self, messages: list[Message]) -> list[dict[str, Any]]:
        contents: list[dict[str, Any]] = []
        for message in messages:
            if message.role == "user":
                parts: list[dict[str, Any]] = [{"text": message.content}]
                if contents and contents[-1]["role"] == "user":
                    contents[-1]["parts"].extend(parts)
                else:
                    contents.append({"role": "user", "parts": parts})
            elif message.role == "assistant":
                parts = []
                if message.content:
                    parts.append({"text": message.content})
                for call in message.tool_calls:
                    parts.append(
                        {"functionCall": {"name": call.name, "args": call.arguments}}
                    )
                if not parts:
                    parts.append({"text": "(no response)"})
                if contents and contents[-1]["role"] == "model":
                    contents[-1]["parts"].extend(parts)
                else:
                    contents.append({"role": "model", "parts": parts})
            elif message.role == "tool":
                part = {
                    "functionResponse": {
                        "name": message.tool_name or "unknown",
                        "response": _tool_response(message),
                    }
                }
                if contents and contents[-1]["role"] == "user":
                    contents[-1]["parts"].append(part)
                else:
                    contents.append({"role": "user", "parts": [part]})
        return contents

    def _payload(
        self,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None,
    ) -> dict[str, Any]:
        generation_config: dict[str, Any] = {"maxOutputTokens": max_tokens}
        if temperature is not None:
            generation_config["temperature"] = temperature
        payload: dict[str, Any] = {
            "contents": self._contents(messages),
            "generationConfig": generation_config,
        }
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        if tools:
            declarations = []
            for tool in tools:
                declaration: dict[str, Any] = {
                    "name": tool.name,
                    "description": tool.description,
                }
                parameters = _clean_schema(tool.parameters)
                if isinstance(parameters, dict) and parameters.get("properties"):
                    declaration["parameters"] = parameters
                declarations.append(declaration)
            payload["tools"] = [{"functionDeclarations": declarations}]
            payload["toolConfig"] = {
                "functionCallingConfig": {"mode": "AUTO"}
            }
        return payload

    def stream(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None = None,
    ) -> Iterator[Event]:
        payload = self._payload(system, messages, tools, max_tokens, temperature)
        yield from stream_request(
            self.client,
            self.name,
            self._url(model),
            self._headers(),
            payload,
            lambda response: self._parse_stream(response, model),
        )

    def _parse_stream(self, response: httpx.Response, model: str) -> Iterator[Event]:
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        usage = Usage()
        stop_reason: str | None = None
        model_used = model
        got_chunk = False

        for _event_name, data in iter_sse(response):
            if not data:
                continue
            try:
                chunk = json.loads(data)
            except json.JSONDecodeError:
                continue
            if not isinstance(chunk, dict):
                continue
            got_chunk = True

            if chunk.get("error"):
                error = chunk["error"]
                message = error.get("message") if isinstance(error, dict) else str(error)
                raise ProviderError(
                    f"{self.label}: akis sirasinda hata: {message}",
                    provider=self.name,
                )
            if isinstance(chunk.get("modelVersion"), str):
                model_used = chunk["modelVersion"]

            raw_usage = chunk.get("usageMetadata")
            if isinstance(raw_usage, dict):
                usage.input_tokens = int(raw_usage.get("promptTokenCount") or 0)
                usage.output_tokens = int(raw_usage.get("candidatesTokenCount") or 0)
                usage.cache_read_tokens = int(
                    raw_usage.get("cachedContentTokenCount") or 0
                )

            candidates = chunk.get("candidates")
            if not isinstance(candidates, list):
                continue
            for candidate in candidates:
                if not isinstance(candidate, dict):
                    continue
                finish = candidate.get("finishReason")
                if isinstance(finish, str):
                    stop_reason = finish
                content = candidate.get("content")
                if not isinstance(content, dict):
                    continue
                parts = content.get("parts")
                if not isinstance(parts, list):
                    continue
                for part in parts:
                    if not isinstance(part, dict):
                        continue
                    if isinstance(part.get("text"), str):
                        text = part["text"]
                        if part.get("thought"):
                            if text:
                                yield ThinkingDelta(text)
                        elif text:
                            text_parts.append(text)
                            yield TextDelta(text)
                    elif isinstance(part.get("functionCall"), dict):
                        function = part["functionCall"]
                        name = str(function.get("name") or "")
                        arguments = function.get("args")
                        if not isinstance(arguments, dict):
                            arguments = {}
                        tool_calls.append(
                            ToolCall(
                                id=str(function.get("id") or f"gemini_{len(tool_calls) + 1}"),
                                name=name,
                                arguments=arguments,
                                raw_arguments=json.dumps(arguments, ensure_ascii=False),
                                parse_error=None if name else "Arac adi eksik.",
                            )
                        )

        if not got_chunk:
            raise ProviderError(
                f"{self.label}: bos bir yanit alindi. Model adini ve API anahtarini kontrol et.",
                provider=self.name,
            )

        yield StreamDone(
            message=Message(
                role="assistant",
                content="".join(text_parts),
                tool_calls=tool_calls,
            ),
            usage=usage,
            stop_reason=stop_reason,
            model=model_used,
        )
