from __future__ import annotations

import json
from typing import Any, Iterator

import httpx

from banana.models import (
    Event,
    Message,
    StreamDone,
    TextDelta,
    ThinkingDelta,
    ToolCall,
    ToolSpec,
    Usage,
)
from banana.net import ProviderError, iter_sse, stream_request
from banana.providers.base import Provider


def _content_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts)
    return ""


def _usage_from_openai(raw: dict[str, Any]) -> Usage:
    usage = Usage()
    usage.input_tokens = int(raw.get("prompt_tokens") or raw.get("input_tokens") or 0)
    usage.output_tokens = int(
        raw.get("completion_tokens") or raw.get("output_tokens") or 0
    )
    details = raw.get("prompt_tokens_details")
    if isinstance(details, dict):
        usage.cache_read_tokens = int(details.get("cached_tokens") or 0)
    cost = raw.get("cost")
    if isinstance(cost, (int, float)):
        usage.cost = float(cost)
    return usage


class OpenAIChatProvider(Provider):
    name = "openai"

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float = 600,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(api_key, base_url, timeout)
        self.extra_headers = extra_headers or {}

    def _headers(self) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        headers.update(self.extra_headers)
        return headers

    def _url(self) -> str:
        if self.base_url.endswith("/chat/completions"):
            return self.base_url
        return self.base_url + "/chat/completions"

    def _messages(self, system: str, messages: list[Message]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        if system:
            result.append({"role": "system", "content": system})
        for message in messages:
            if message.role == "user":
                result.append({"role": "user", "content": message.content})
            elif message.role == "assistant":
                item: dict[str, Any] = {
                    "role": "assistant",
                    "content": message.content or None,
                }
                if message.tool_calls:
                    item["tool_calls"] = [
                        {
                            "id": call.id,
                            "type": "function",
                            "function": {
                                "name": call.name,
                                "arguments": call.raw_arguments
                                if call.raw_arguments and not call.parse_error
                                else json.dumps(call.arguments, ensure_ascii=False),
                            },
                        }
                        for call in message.tool_calls
                    ]
                result.append(item)
            elif message.role == "tool":
                result.append(
                    {
                        "role": "tool",
                        "tool_call_id": message.tool_call_id or "",
                        "content": message.content,
                    }
                )
        return result

    def _payload(
        self,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": model,
            "messages": self._messages(system, messages),
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        token_field = "max_completion_tokens" if self.name == "openai" else "max_tokens"
        payload[token_field] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if tools:
            payload["tools"] = [tool.as_openai() for tool in tools]
            payload["tool_choice"] = "auto"
        return payload

    def _adjust_payload(self, payload: dict[str, Any], body: str) -> bool:
        low = body.lower()
        changed = False
        if "stream_options" in low and "stream_options" in payload:
            payload.pop("stream_options", None)
            changed = True
        if "temperature" in low and "temperature" in payload:
            payload.pop("temperature", None)
            changed = True
        if "max_completion_tokens" in low and "max_completion_tokens" in payload:
            payload["max_tokens"] = payload.pop("max_completion_tokens")
            changed = True
        elif "max_tokens" in low and "max_tokens" in payload:
            payload["max_completion_tokens"] = payload.pop("max_tokens")
            changed = True
        return changed

    def stream(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None = None,
    ) -> Iterator[Event]:
        payload = self._payload(
            model, system, messages, tools, max_tokens, temperature
        )
        for _attempt in range(3):
            emitted = False
            try:
                for event in stream_request(
                    self.client,
                    self.name,
                    self._url(),
                    self._headers(),
                    payload,
                    lambda response: self._parse_stream(response, model),
                ):
                    emitted = True
                    yield event
                return
            except ProviderError as error:
                if (
                    not emitted
                    and error.status_code == 400
                    and self._adjust_payload(payload, error.body)
                ):
                    continue
                raise

    def _parse_stream(self, response: httpx.Response, model: str) -> Iterator[Event]:
        text_parts: list[str] = []
        calls: dict[int, dict[str, str]] = {}
        usage = Usage()
        stop_reason: str | None = None
        model_used = model
        finished = False

        for _event_name, data in iter_sse(response):
            if not data:
                continue
            stripped = data.strip()
            if stripped == "[DONE]":
                break
            try:
                chunk = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if not isinstance(chunk, dict):
                continue
            if chunk.get("error"):
                error = chunk["error"]
                message = error.get("message") if isinstance(error, dict) else str(error)
                raise ProviderError(
                    f"{self.label}: akis sirasinda hata: {message}",
                    provider=self.name,
                )
            if isinstance(chunk.get("model"), str):
                model_used = chunk["model"]
            if isinstance(chunk.get("usage"), dict):
                usage = _usage_from_openai(chunk["usage"])

            choices = chunk.get("choices")
            if not isinstance(choices, list) or not choices:
                continue
            choice = choices[0] if isinstance(choices[0], dict) else {}
            delta = choice.get("delta")
            if not isinstance(delta, dict):
                delta = {}

            reasoning = delta.get("reasoning_content") or delta.get("reasoning")
            if isinstance(reasoning, str) and reasoning:
                yield ThinkingDelta(reasoning)

            content = _content_text(delta.get("content"))
            if content:
                text_parts.append(content)
                yield TextDelta(content)

            tool_deltas = delta.get("tool_calls")
            if isinstance(tool_deltas, list):
                for item in tool_deltas:
                    if not isinstance(item, dict):
                        continue
                    try:
                        index = int(item.get("index", 0))
                    except (TypeError, ValueError):
                        index = 0
                    slot = calls.setdefault(index, {"id": "", "name": "", "json": ""})
                    if isinstance(item.get("id"), str) and item["id"]:
                        slot["id"] = item["id"]
                    function = item.get("function")
                    if isinstance(function, dict):
                        name = function.get("name")
                        if isinstance(name, str) and name:
                            if not slot["name"]:
                                slot["name"] = name
                            elif name != slot["name"]:
                                slot["name"] += name
                        arguments = function.get("arguments")
                        if isinstance(arguments, str):
                            slot["json"] += arguments

            legacy = delta.get("function_call")
            if isinstance(legacy, dict) and not calls:
                slot = calls.setdefault(0, {"id": "call_legacy_1", "name": "", "json": ""})
                name = legacy.get("name")
                if isinstance(name, str) and name:
                    slot["name"] = name
                arguments = legacy.get("arguments")
                if isinstance(arguments, str):
                    slot["json"] += arguments

            finish = choice.get("finish_reason")
            if isinstance(finish, str):
                stop_reason = finish
                finished = True

        if not finished and not text_parts and not calls:
            raise ProviderError(
                f"{self.label}: bos bir yanit alindi. Model adini ve API anahtarini kontrol et.",
                provider=self.name,
            )

        tool_calls: list[ToolCall] = []
        for index in sorted(calls):
            slot = calls[index]
            raw = slot["json"].strip()
            arguments: dict[str, Any] = {}
            parse_error: str | None = None
            if raw:
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        arguments = parsed
                    else:
                        parse_error = "Arac argumanlari JSON nesnesi olmali."
                except json.JSONDecodeError as exc:
                    parse_error = f"Gecersiz JSON: {exc}"
            if not slot["name"]:
                parse_error = parse_error or "Arac adi eksik."
            tool_calls.append(
                ToolCall(
                    id=slot["id"] or f"call_{index + 1}",
                    name=slot["name"],
                    arguments=arguments,
                    raw_arguments=raw,
                    parse_error=parse_error,
                )
            )

        yield StreamDone(
            message=Message(
                role="assistant",
                content="".join(text_parts),
                tool_calls=tool_calls,
            ),
            usage=usage,
            stop_reason=stop_reason,
            model=model_used,
        )


class OpenAIProvider(OpenAIChatProvider):
    name = "openai"


class OpenRouterProvider(OpenAIChatProvider):
    name = "openrouter"

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float = 600,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        headers = {
            "HTTP-Referer": "https://github.com/banana-coder",
            "X-Title": "Banana Coder",
        }
        if extra_headers:
            headers.update(extra_headers)
        super().__init__(api_key, base_url, timeout, headers)
