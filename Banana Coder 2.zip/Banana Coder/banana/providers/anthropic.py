from __future__ import annotations

import json
from typing import Any, Iterator

import httpx

from banana.models import (
    Event,
    Message,
    StreamDone,
    TextDelta,
    ThinkingDelta,
    ToolCall,
    ToolSpec,
    Usage,
)
from banana.net import ProviderError, iter_sse, stream_request
from banana.providers.base import Provider


class AnthropicProvider(Provider):
    name = "anthropic"

    def _headers(self) -> dict[str, str]:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

    def _url(self) -> str:
        if self.base_url.endswith("/messages"):
            return self.base_url
        return self.base_url + "/v1/messages"

    def _messages(self, messages: list[Message]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for message in messages:
            if message.role == "tool":
                block: dict[str, Any] = {
                    "type": "tool_result",
                    "tool_use_id": message.tool_call_id or "",
                    "content": message.content,
                }
                if message.is_error:
                    block["is_error"] = True
                if result and result[-1]["role"] == "user":
                    result[-1]["content"].append(block)
                else:
                    result.append({"role": "user", "content": [block]})
            elif message.role == "user":
                block = {"type": "text", "text": message.content}
                if result and result[-1]["role"] == "user":
                    result[-1]["content"].append(block)
                else:
                    result.append({"role": "user", "content": [block]})
            elif message.role == "assistant":
                blocks: list[dict[str, Any]] = []
                if message.content:
                    blocks.append({"type": "text", "text": message.content})
                for call in message.tool_calls:
                    blocks.append(
                        {
                            "type": "tool_use",
                            "id": call.id,
                            "name": call.name,
                            "input": call.arguments,
                        }
                    )
                if not blocks:
                    blocks.append({"type": "text", "text": "(no response)"})
                result.append({"role": "assistant", "content": blocks})
        return result

    def _payload(
        self,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": self._messages(messages),
            "stream": True,
        }
        if system:
            payload["system"] = [
                {
                    "type": "text",
                    "text": system,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        if temperature is not None:
            payload["temperature"] = temperature
        if tools:
            payload["tools"] = [tool.as_anthropic() for tool in tools]
            payload["tool_choice"] = {"type": "auto"}
        return payload

    def stream(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None = None,
    ) -> Iterator[Event]:
        payload = self._payload(
            model, system, messages, tools, max_tokens, temperature
        )
        yield from stream_request(
            self.client,
            self.name,
            self._url(),
            self._headers(),
            payload,
            lambda response: self._parse_stream(response, model),
        )

    def _parse_stream(self, response: httpx.Response, model: str) -> Iterator[Event]:
        text_parts: list[str] = []
        tool_blocks: dict[int, dict[str, Any]] = {}
        usage = Usage()
        stop_reason: str | None = None
        model_used = model
        got_event = False

        for _event_name, data in iter_sse(response):
            if not data:
                continue
            try:
                event = json.loads(data)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            event_type = event.get("type")
            got_event = True

            if event_type == "error":
                detail = event.get("error")
                if isinstance(detail, dict):
                    detail = detail.get("message") or json.dumps(detail)
                raise ProviderError(
                    f"{self.label}: akis sirasinda hata: {detail}",
                    provider=self.name,
                )

            if event_type == "message_start":
                message = event.get("message") or {}
                if isinstance(message.get("model"), str):
                    model_used = message["model"]
                raw_usage = message.get("usage") or {}
                if isinstance(raw_usage, dict):
                    usage.input_tokens = int(raw_usage.get("input_tokens") or 0)
                    usage.output_tokens = int(raw_usage.get("output_tokens") or 0)
                    usage.cache_read_tokens = int(
                        raw_usage.get("cache_read_input_tokens") or 0
                    )
                    usage.cache_write_tokens = int(
                        raw_usage.get("cache_creation_input_tokens") or 0
                    )
                continue

            if event_type == "content_block_start":
                index = int(event.get("index") or 0)
                block = event.get("content_block") or {}
                if block.get("type") == "tool_use":
                    tool_blocks[index] = {
                        "id": block.get("id") or f"toolu_{index + 1}",
                        "name": block.get("name") or "",
                        "json": "",
                        "input": block.get("input")
                        if isinstance(block.get("input"), dict)
                        else None,
                    }
                continue

            if event_type == "content_block_delta":
                index = int(event.get("index") or 0)
                delta = event.get("delta") or {}
                delta_type = delta.get("type")
                if delta_type == "text_delta":
                    text = delta.get("text") or ""
                    if text:
                        text_parts.append(text)
                        yield TextDelta(text)
                elif delta_type == "thinking_delta":
                    text = delta.get("thinking") or ""
                    if text:
                        yield ThinkingDelta(text)
                elif delta_type == "input_json_delta":
                    block = tool_blocks.get(index)
                    if block is not None:
                        block["json"] += delta.get("partial_json") or ""
                continue

            if event_type == "message_delta":
                delta = event.get("delta") or {}
                if isinstance(delta.get("stop_reason"), str):
                    stop_reason = delta["stop_reason"]
                raw_usage = event.get("usage") or {}
                if isinstance(raw_usage, dict):
                    if raw_usage.get("output_tokens") is not None:
                        usage.output_tokens = int(raw_usage["output_tokens"])
                    if raw_usage.get("input_tokens") is not None:
                        usage.input_tokens = int(raw_usage["input_tokens"])
                continue

        if not got_event:
            raise ProviderError(
                f"{self.label}: bos bir yanit alindi. Model adini ve API anahtarini kontrol et.",
                provider=self.name,
            )

        tool_calls: list[ToolCall] = []
        for index in sorted(tool_blocks):
            block = tool_blocks[index]
            raw = block["json"].strip()
            arguments = block.get("input")
            parse_error: str | None = None
            if raw:
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        arguments = parsed
                    else:
                        parse_error = "Arac argumanlari JSON nesnesi olmali."
                except json.JSONDecodeError as exc:
                    parse_error = f"Gecersiz JSON: {exc}"
            if not isinstance(arguments, dict):
                arguments = {}
            if not block["name"]:
                parse_error = parse_error or "Arac adi eksik."
            tool_calls.append(
                ToolCall(
                    id=block["id"],
                    name=block["name"],
                    arguments=arguments,
                    raw_arguments=raw,
                    parse_error=parse_error,
                )
            )

        yield StreamDone(
            message=Message(
                role="assistant",
                content="".join(text_parts),
                tool_calls=tool_calls,
            ),
            usage=usage,
            stop_reason=stop_reason,
            model=model_used,
        )
