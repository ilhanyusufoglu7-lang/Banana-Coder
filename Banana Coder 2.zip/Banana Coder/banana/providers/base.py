from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterator

from banana.config import PROVIDER_LABELS
from banana.models import Event, Message, StreamDone, ToolSpec, Usage
from banana.net import ProviderError, make_client


class Provider(ABC):
    name: str

    def __init__(self, api_key: str, base_url: str, timeout: float = 600) -> None:
        if not api_key or not api_key.strip():
            label = PROVIDER_LABELS.get(self.name, self.name)
            raise ProviderError(f"{label}: API anahtari bos.")
        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self.client = make_client(timeout)

    @property
    def label(self) -> str:
        return PROVIDER_LABELS.get(self.name, self.name)

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> "Provider":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    @abstractmethod
    def stream(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec],
        max_tokens: int,
        temperature: float | None = None,
    ) -> Iterator[Event]:
        raise NotImplementedError

    def complete(
        self,
        *,
        model: str,
        system: str,
        messages: list[Message],
        tools: list[ToolSpec] | None = None,
        max_tokens: int = 256,
        temperature: float | None = None,
    ) -> tuple[Message, Usage, str | None, str]:
        for event in self.stream(
            model=model,
            system=system,
            messages=messages,
            tools=tools or [],
            max_tokens=max_tokens,
            temperature=temperature,
        ):
            if isinstance(event, StreamDone):
                return event.message, event.usage, event.stop_reason, event.model
        raise ProviderError(f"{self.label}: akis beklenmedik sekilde sona erdi.")
