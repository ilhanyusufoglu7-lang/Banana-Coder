from __future__ import annotations

import fnmatch
import glob as globlib
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from banana.models import ToolSpec
from banana.tools.common import (
    EXCLUDED_DIRS,
    ToolContext,
    ToolError,
    ToolResult,
    atomic_write,
    display_path,
    get_bool,
    get_int,
    get_str,
    human_size,
    resolve_path,
)
from banana.ui import render_diff

MAX_LINE_CHARS = 4_000
MAX_SEARCH_FILE_BYTES = 2_000_000
MAX_SEARCH_FILES = 20_000

FILE_SPECS = [
    ToolSpec(
        name="read_file",
        description=(
            "Read a UTF-8 text file from disk. Returns numbered lines for navigation; "
            "the line numbers are not part of the file content. Use offset (1-based) "
            "and limit for large files. Paths may be absolute or relative to the "
            "working directory."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read."},
                "offset": {
                    "type": "integer",
                    "minimum": 1,
                    "description": "1-based line number to start from (default 1).",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 20000,
                    "description": "Maximum number of lines to return (default 2000).",
                },
            },
            "required": ["path"],
        },
        read_only=True,
    ),
    ToolSpec(
        name="write_file",
        description=(
            "Create a new file or completely overwrite an existing file. "
            "Parent directories are created automatically. Prefer edit_file for "
            "small changes to existing files. Requires user approval unless auto-approved."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to write."},
                "content": {
                    "type": "string",
                    "description": "Complete new file content.",
                },
            },
            "required": ["path", "content"],
        },
        read_only=False,
    ),
    ToolSpec(
        name="edit_file",
        description=(
            "Replace an exact string in an existing text file. old_string must match "
            "the file content exactly, including whitespace, and must be unique unless "
            "replace_all is true. The line-number prefixes returned by read_file are "
            "not part of the content. Requires user approval unless auto-approved."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to edit."},
                "old_string": {
                    "type": "string",
                    "description": "Exact text to replace.",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text (may be empty to delete).",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": "Replace every occurrence (default false).",
                },
            },
            "required": ["path", "old_string", "new_string"],
        },
        read_only=False,
    ),
    ToolSpec(
        name="list_dir",
        description=(
            "List the direct children of a directory with type and size. "
            "Use glob for recursive file discovery."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path (default: working directory).",
                },
                "max_entries": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 1000,
                    "description": "Maximum entries to return (default 300).",
                },
            },
            "required": [],
        },
        read_only=True,
    ),
    ToolSpec(
        name="glob",
        description=(
            "Find files by glob pattern, for example '**/*.py' or 'src/**/*.ts'. "
            "Results are sorted by modification time. Hidden and ignored directories "
            "such as .git and node_modules are skipped unless include_ignored is true."
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern to match files.",
                },
                "path": {
                    "type": "string",
                    "description": "Base directory (default: working directory).",
                },
                "max_results": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 2000,
                    "description": "Maximum files to return (default 200).",
                },
                "include_ignored": {
                    "type": "boolean",
                    "description": "Include hidden and ignored directories (default false).",
                },
            },
            "required": ["pattern"],
        },
        read_only=True,
    ),
    ToolSpec(
        name="grep",
        description=(
            "Search file contents with a regular expression. Uses ripgrep when available. "
            "Returns lines as path:line:text. Use glob to restrict file types. "
            "Ignored directories and hidden files are skipped unless include_ignored is true."
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regular expression to search for.",
                },
                "path": {
                    "type": "string",
                    "description": "File or directory to search (default: working directory).",
                },
                "glob": {
                    "type": "string",
                    "description": "Optional file glob filter, e.g. '*.py'.",
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Case-sensitive search (default false).",
                },
                "max_results": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 1000,
                    "description": "Maximum matching lines (default 100).",
                },
                "include_ignored": {
                    "type": "boolean",
                    "description": "Include hidden and ignored directories (default false).",
                },
            },
            "required": ["pattern"],
        },
        read_only=True,
    ),
]


def _check_text_file(path: Path) -> None:
    try:
        with path.open("rb") as handle:
            head = handle.read(8192)
    except OSError as exc:
        raise ToolError(f"Dosya okunamadi: {path} ({exc})") from exc
    if b"\x00" in head:
        raise ToolError(f"Ikili dosya okunamaz: {path}")


def read_file(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    raw = get_str(args, "path")
    path = resolve_path(raw, ctx.cwd)
    shown = display_path(path, ctx.cwd)
    if not path.exists():
        raise ToolError(f"Dosya bulunamadi: {shown}")
    if path.is_dir():
        raise ToolError(f"{shown} bir dizin. list_dir veya glob kullan.")
    if not path.is_file():
        raise ToolError(f"{shown} normal bir dosya degil.")
    _check_text_file(path)

    offset = get_int(args, "offset", 1, minimum=1)
    limit = get_int(args, "limit", 2000, minimum=1, maximum=20000)

    lines: list[tuple[int, str]] = []
    used = 0
    has_more = False
    line_truncated = False
    try:
        with path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
            for line_number, line in enumerate(handle, 1):
                if line_number < offset:
                    continue
                if len(lines) >= limit:
                    has_more = True
                    break
                text = line.rstrip("\r\n")
                if len(text) > MAX_LINE_CHARS:
                    text = text[:MAX_LINE_CHARS] + " ..."
                    line_truncated = True
                used += len(text) + 12
                if used > ctx.output_limit:
                    has_more = True
                    break
                lines.append((line_number, text))
    except OSError as exc:
        raise ToolError(f"Dosya okunamadi: {shown} ({exc})") from exc

    header = f'<file path="{shown}" offset="{offset}">'
    if not lines:
        return ToolResult(
            f"{header}\n(offset {offset} ve sonrasinda satir yok)\n</file>",
            summary=f"{shown} · satir yok",
        )
    width = len(str(lines[-1][0]))
    body = "\n".join(f"{number:>{width}}| {text}" for number, text in lines)
    footer: list[str] = []
    if has_more:
        footer.append(f"[devam etmek icin offset={lines[-1][0] + 1} kullan]")
    if line_truncated:
        footer.append(f"[{MAX_LINE_CHARS} karakterden uzun satirlar kisaltildi]")
    note = ("\n" + "\n".join(footer)) if footer else ""
    content = f"{header}\n{body}{note}\n</file>"
    return ToolResult(
        content,
        summary=f"{shown} · {lines[0][0]}-{lines[-1][0]} satir",
    )


def write_file(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    raw = get_str(args, "path")
    content = get_str(args, "content", required=False, default="")
    path = resolve_path(raw, ctx.cwd)
    shown = display_path(path, ctx.cwd)
    if path.exists() and path.is_dir():
        raise ToolError(f"{shown} bir dizin; dosya olarak yazilamaz.")

    existing: str | None = None
    if path.exists():
        try:
            existing = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            raise ToolError(f"Mevcut dosya okunamadi: {shown} ({exc})") from exc
        if existing == content:
            return ToolResult(
                f"Degisiklik yok: {shown} zaten bu icerige sahip.",
                summary=f"{shown} · degisiklik yok",
            )

    preview = render_diff(shown, existing, content)
    if not ctx.approver.allow(f"Dosya yazma: {shown}", preview):
        return ToolResult(
            f"Kullanici {shown} dosyasina yazmayi reddetti.",
            is_error=True,
            summary=f"{shown} · reddedildi",
        )

    try:
        atomic_write(path, content)
    except OSError as exc:
        raise ToolError(f"Dosya yazilamadi: {shown} ({exc})") from exc
    size = len(content.encode("utf-8"))
    return ToolResult(
        f"Yazildi: {shown} ({size} bayt).",
        summary=f"{shown} · {human_size(size)}",
    )


def edit_file(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    raw = get_str(args, "path")
    old_string = args.get("old_string")
    new_string = args.get("new_string", "")
    if not isinstance(old_string, str) or old_string == "":
        raise ToolError("'old_string' bos olmayan bir metin olmali.")
    if not isinstance(new_string, str):
        new_string = str(new_string)
    replace_all = get_bool(args, "replace_all", False)

    path = resolve_path(raw, ctx.cwd)
    shown = display_path(path, ctx.cwd)
    if not path.exists():
        raise ToolError(f"Dosya bulunamadi: {shown}")
    if path.is_dir():
        raise ToolError(f"{shown} bir dizin; edit_file yalnizca dosyalar icin.")
    _check_text_file(path)

    try:
        original = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise ToolError(f"Dosya okunamadi: {shown} ({exc})") from exc

    count = original.count(old_string)
    if count == 0:
        raise ToolError(
            f"old_string {shown} icinde bulunamadi. Dosyayi yeniden okuyup "
            "bosluk/karakterleri birebir kopyaladigindan emin ol."
        )
    if count > 1 and not replace_all:
        raise ToolError(
            f"old_string {shown} icinde {count} kez geciyor. Daha fazla baglam ekle "
            "veya replace_all=true kullan."
        )

    updated = (
        original.replace(old_string, new_string)
        if replace_all
        else original.replace(old_string, new_string, 1)
    )
    preview = render_diff(shown, original, updated)
    if not ctx.approver.allow(f"Dosya duzenleme: {shown}", preview):
        return ToolResult(
            f"Kullanici {shown} dosyasini duzenlemeyi reddetti.",
            is_error=True,
            summary=f"{shown} · reddedildi",
        )

    try:
        atomic_write(path, updated)
    except OSError as exc:
        raise ToolError(f"Dosya yazilamadi: {shown} ({exc})") from exc
    return ToolResult(
        f"Duzenlendi: {shown} ({count} yer).",
        summary=f"{shown} · {count} degisiklik",
    )


def list_dir(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    raw = get_str(args, "path", required=False, default=".")
    path = resolve_path(raw, ctx.cwd)
    shown = display_path(path, ctx.cwd)
    if not path.exists():
        raise ToolError(f"Dizin bulunamadi: {shown}")
    if not path.is_dir():
        raise ToolError(f"{shown} bir dizin degil.")
    max_entries = get_int(args, "max_entries", 300, minimum=1, maximum=1000)

    entries: list[tuple[bool, str, Path]] = []
    try:
        for entry in path.iterdir():
            try:
                is_dir = entry.is_dir()
            except OSError:
                is_dir = False
            entries.append((not is_dir, entry.name.lower(), entry))
    except OSError as exc:
        raise ToolError(f"Dizin okunamadi: {shown} ({exc})") from exc

    entries.sort()
    lines: list[str] = [f'<dir path="{shown}">']
    shown_count = 0
    for _is_file, _name, entry in entries:
        if shown_count >= max_entries:
            lines.append(f"[{len(entries) - max_entries} giris daha var, limit={max_entries}]")
            break
        try:
            if entry.is_symlink():
                kind = "l"
                suffix = f" -> {os.readlink(entry)}"
                size = ""
            elif entry.is_dir():
                kind = "d"
                suffix = "/"
                size = ""
            else:
                kind = "f"
                suffix = ""
                size = human_size(entry.stat().st_size)
        except OSError:
            kind = "?"
            suffix = ""
            size = ""
        lines.append(f"{kind} {size:>9}  {entry.name}{suffix}")
        shown_count += 1
    lines.append("</dir>")
    return ToolResult(
        "\n".join(lines),
        summary=f"{shown} · {shown_count} giris",
    )


def _ignored_parent(path: Path, base: Path, include_ignored: bool) -> bool:
    if include_ignored:
        return False
    try:
        parts = path.relative_to(base).parts[:-1]
    except ValueError:
        parts = path.parts[:-1]
    return any(
        part in EXCLUDED_DIRS or (part.startswith(".") and part not in (".", ".."))
        for part in parts
    )


def glob_files(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    pattern = get_str(args, "pattern")
    raw_path = get_str(args, "path", required=False, default=".")
    base = resolve_path(raw_path, ctx.cwd)
    if not base.exists():
        raise ToolError(f"Dizin bulunamadi: {display_path(base, ctx.cwd)}")
    if not base.is_dir():
        raise ToolError(f"{display_path(base, ctx.cwd)} bir dizin degil.")
    max_results = get_int(args, "max_results", 200, minimum=1, maximum=2000)
    include_ignored = get_bool(args, "include_ignored", False)

    if Path(pattern).expanduser().is_absolute():
        raw_matches = globlib.glob(str(Path(pattern).expanduser()), recursive=True)
    else:
        raw_matches = globlib.glob(str(base / pattern), recursive=True)

    files: list[Path] = []
    for item in raw_matches:
        path = Path(item)
        try:
            if not path.is_file():
                continue
        except OSError:
            continue
        if _ignored_parent(path, base, include_ignored):
            continue
        files.append(path)

    def _mtime(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except OSError:
            return 0.0

    files.sort(key=_mtime, reverse=True)
    total = len(files)
    files = files[:max_results]
    if not files:
        return ToolResult(
            f"Eslesen dosya yok: {pattern}",
            summary="0 dosya",
        )
    lines = [f"Eslesen dosyalar ({len(files)}/{total}):"]
    lines.extend(display_path(path, ctx.cwd) for path in files)
    if total > len(files):
        lines.append(f"[max_results={max_results} nedeniyle {total - len(files)} dosya gizlendi]")
    return ToolResult("\n".join(lines), summary=f"{len(files)} dosya")


def _rg_search(
    base: Path,
    pattern: str,
    glob_pattern: str | None,
    case_sensitive: bool,
    include_ignored: bool,
    max_results: int,
) -> list[str] | None:
    executable = shutil.which("rg")
    if not executable:
        return None
    command = [
        executable,
        "-n",
        "--no-heading",
        "--color",
        "never",
        "--max-columns",
        "400",
        "--max-columns-preview",
        "-e",
        pattern,
    ]
    if not case_sensitive:
        command.append("-i")
    if glob_pattern:
        command.extend(["--glob", glob_pattern])
    if include_ignored:
        command.append("-uu")
    command.append(str(base))
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=30,
            cwd=str(base.parent if base.is_file() else base),
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode not in (0, 1):
        return None
    results: list[str] = []
    for line in completed.stdout.splitlines():
        if len(results) >= max_results:
            break
        if not line:
            continue
        results.append(line)
    return results


def _py_search(
    base: Path,
    regex: re.Pattern[str],
    glob_pattern: str | None,
    include_ignored: bool,
    max_results: int,
) -> tuple[list[tuple[str, int, str]], int, bool, bool]:
    files: list[Path] = []
    if base.is_file():
        files.append(base)
    else:
        for root, dirs, names in os.walk(base):
            dirs[:] = sorted(
                name
                for name in dirs
                if include_ignored
                or (name not in EXCLUDED_DIRS and not name.startswith("."))
            )
            for name in sorted(names):
                if not include_ignored and name.startswith("."):
                    continue
                path = Path(root) / name
                if glob_pattern:
                    try:
                        relative = str(path.relative_to(base))
                    except ValueError:
                        relative = name
                    if not (
                        fnmatch.fnmatch(name, glob_pattern)
                        or fnmatch.fnmatch(relative, glob_pattern)
                    ):
                        continue
                files.append(path)
            if len(files) >= MAX_SEARCH_FILES:
                break

    matches: list[tuple[str, int, str]] = []
    skipped = 0
    hit_file_limit = len(files) >= MAX_SEARCH_FILES
    truncated = False
    for path in files[:MAX_SEARCH_FILES]:
        try:
            if path.stat().st_size > MAX_SEARCH_FILE_BYTES:
                skipped += 1
                continue
            with path.open("rb") as handle:
                head = handle.read(4096)
            if b"\x00" in head:
                skipped += 1
                continue
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for line_number, line in enumerate(handle, 1):
                    if len(matches) >= max_results:
                        truncated = True
                        break
                    if regex.search(line):
                        text = line.rstrip("\r\n")
                        if len(text) > 400:
                            text = text[:400] + " ..."
                        matches.append((str(path), line_number, text))
                if truncated:
                    break
        except OSError:
            skipped += 1
            continue
        if truncated:
            break
    return matches, skipped, truncated, hit_file_limit


def grep_files(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    pattern = get_str(args, "pattern")
    raw_path = get_str(args, "path", required=False, default=".")
    base = resolve_path(raw_path, ctx.cwd)
    if not base.exists():
        raise ToolError(f"Yol bulunamadi: {display_path(base, ctx.cwd)}")
    case_sensitive = get_bool(args, "case_sensitive", False)
    include_ignored = get_bool(args, "include_ignored", False)
    max_results = get_int(args, "max_results", 100, minimum=1, maximum=1000)
    glob_value = args.get("glob")
    glob_pattern = glob_value if isinstance(glob_value, str) and glob_value.strip() else None
    try:
        regex = re.compile(pattern, 0 if case_sensitive else re.IGNORECASE)
    except re.error as exc:
        raise ToolError(f"Gecersiz regex: {exc}") from exc

    results: list[str] = []
    skipped = 0
    truncated = False
    rg_lines = _rg_search(
        base, pattern, glob_pattern, case_sensitive, include_ignored, max_results
    )
    if rg_lines is not None:
        for line in rg_lines:
            path_part, separator, rest = line.partition(":")
            if separator and path_part:
                results.append(
                    f"{display_path(Path(path_part), ctx.cwd)}:{rest}"
                )
            else:
                results.append(line)
        truncated = len(results) >= max_results
    else:
        matches, skipped, truncated, hit_file_limit = _py_search(
            base, regex, glob_pattern, include_ignored, max_results
        )
        for path, line_number, text in matches:
            results.append(f"{display_path(Path(path), ctx.cwd)}:{line_number}:{text}")
        if hit_file_limit:
            skipped += 1

    if not results:
        suffix = f" ({skipped} dosya atlandi)" if skipped else ""
        return ToolResult(f"Eslesme yok: {pattern}{suffix}", summary="0 eslesme")

    output = [f'<grep pattern="{pattern}">']
    output.extend(results)
    if truncated:
        output.append(f"[max_results={max_results} siniri; daha fazla sonuc olabilir]")
    if skipped:
        output.append(f"[{skipped} ikili/buyuk dosya atlandi]")
    output.append("</grep>")
    return ToolResult("\n".join(output), summary=f"{len(results)} eslesme")


FILE_HANDLERS = {
    "read_file": read_file,
    "write_file": write_file,
    "edit_file": edit_file,
    "list_dir": list_dir,
    "glob": glob_files,
    "grep": grep_files,
}
