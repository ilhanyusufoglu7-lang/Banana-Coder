from __future__ import annotations

import os
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from banana.approval import Approver

EXCLUDED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".tox",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "target",
    "vendor",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".cache",
    "coverage",
    ".banana",
}


class ToolError(Exception):
    pass


@dataclass
class ToolResult:
    content: str
    is_error: bool = False
    summary: str = ""


@dataclass
class ToolContext:
    cwd: Path
    approver: Approver
    output_limit: int = 30_000
    ui: Any = None


def get_str(
    args: dict[str, Any],
    key: str,
    *,
    required: bool = True,
    default: str | None = None,
) -> str:
    value = args.get(key, default)
    if value is None:
        if required:
            raise ToolError(f"'{key}' parametresi gerekli.")
        return default or ""
    if not isinstance(value, str):
        value = str(value)
    if required and not value.strip():
        raise ToolError(f"'{key}' parametresi bos olamaz.")
    return value


def get_int(
    args: dict[str, Any],
    key: str,
    default: int,
    *,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    value = args.get(key, default)
    if value is None or value == "":
        value = default
    if isinstance(value, bool):
        raise ToolError(f"'{key}' bir tam sayi olmali.")
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ToolError(f"'{key}' bir tam sayi olmali.") from None
    if minimum is not None:
        number = max(minimum, number)
    if maximum is not None:
        number = min(maximum, number)
    return number


def get_bool(args: dict[str, Any], key: str, default: bool = False) -> bool:
    value = args.get(key, default)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on", "evet")
    return default


def resolve_path(raw: str, cwd: Path) -> Path:
    raw = raw.strip()
    if not raw:
        raise ToolError("Dosya yolu bos olamaz.")
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = cwd / path
    try:
        return path.resolve()
    except OSError as exc:
        raise ToolError(f"Yol cozumlenemedi: {raw} ({exc})") from exc


def display_path(path: Path, cwd: Path) -> str:
    try:
        relative = path.relative_to(cwd)
        return str(relative) if str(relative) else "."
    except ValueError:
        return str(path)


def is_ignored(path: Path, base: Path, include_ignored: bool) -> bool:
    if include_ignored:
        return False
    try:
        parts = path.relative_to(base).parts
    except ValueError:
        parts = path.parts
    for part in parts[:-1]:
        if part in EXCLUDED_DIRS or (part.startswith(".") and part not in (".", "..")):
            return True
    name = path.name
    if name in EXCLUDED_DIRS:
        return True
    return name.startswith(".")


def human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def truncate_middle(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    head = int(limit * 0.65)
    tail = max(0, limit - head - 60)
    removed = len(text) - head - tail
    middle = f"\n...[{removed} karakter kisaltildi]...\n"
    if tail:
        return text[:head] + middle + text[-tail:]
    return text[:head] + middle


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing_mode: int | None = None
    try:
        existing_mode = stat.S_IMODE(path.stat().st_mode)
    except OSError:
        existing_mode = None
    fd, tmp_name = tempfile.mkstemp(
        dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        os.chmod(tmp_name, existing_mode if existing_mode is not None else 0o644)
        os.replace(tmp_name, path)
    except BaseException:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise
