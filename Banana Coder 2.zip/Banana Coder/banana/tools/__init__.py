from __future__ import annotations

from typing import Any

from banana.models import ToolSpec
from banana.tools.common import ToolContext, ToolError, ToolResult
from banana.tools.files import FILE_HANDLERS, FILE_SPECS
from banana.tools.shell import BASH_SPEC, SHELL_HANDLERS
from banana.tools.web import WEB_HANDLERS, WEB_SPECS

_SPECS: dict[str, ToolSpec] = {
    spec.name: spec for spec in [*FILE_SPECS, BASH_SPEC, *WEB_SPECS]
}
_HANDLERS = {**FILE_HANDLERS, **SHELL_HANDLERS, **WEB_HANDLERS}


def tool_specs() -> list[ToolSpec]:
    return list(_SPECS.values())


def tool_spec(name: str) -> ToolSpec | None:
    return _SPECS.get(name)


def execute_tool(name: str, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    handler = _HANDLERS.get(name)
    if handler is None:
        message = f"Bilinmeyen arac: {name}"
        return ToolResult(f"Hata: {message}", is_error=True, summary=message)
    try:
        return handler(args or {}, ctx)
    except ToolError as exc:
        message = str(exc)
        return ToolResult(f"Hata: {message}", is_error=True, summary=message[:140])
    except OSError as exc:
        message = f"Dosya sistemi hatasi: {exc}"
        return ToolResult(f"Hata: {message}", is_error=True, summary=message[:140])
    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        return ToolResult(f"Hata: {message}", is_error=True, summary=message[:140])


__all__ = [
    "ToolContext",
    "ToolError",
    "ToolResult",
    "execute_tool",
    "tool_spec",
    "tool_specs",
]
