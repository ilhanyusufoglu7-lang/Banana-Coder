from __future__ import annotations

import html as htmlmod
import ipaddress
import os
import re
from typing import Any
from urllib.parse import urlsplit

import httpx

from banana.models import ToolSpec
from banana.preview import publish as preview_publish
from banana.tools.common import (
    ToolContext,
    ToolError,
    ToolResult,
    get_int,
    get_str,
    truncate_middle,
)
from banana.ui import Text

MAX_FETCH_BYTES = 2_000_000
FETCH_TIMEOUT = 30.0

WEB_SPECS = [
    ToolSpec(
        name="web_fetch",
        description=(
            "Fetch a public http(s) URL and return its content as readable plain "
            "text (HTML is stripped). Use it for documentation, API responses and "
            "error pages. Local, private and metadata addresses are refused. "
            "Requires user approval unless auto-approved."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "http(s) URL to fetch."},
                "max_chars": {
                    "type": "integer",
                    "minimum": 200,
                    "maximum": 100_000,
                    "description": "Maximum characters of content to return.",
                },
            },
            "required": ["url"],
        },
        read_only=False,
    ),
]

_BLOCKED_HOSTS = {"localhost", "metadata.google.internal"}
_TAG = re.compile(r"<[^>]+>")
_SPACE = re.compile(r"[ \t\f\r]+")
_BLANK_LINES = re.compile(r"\n{3,}")

_TITLE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
_DROP_BLOCKS = re.compile(
    r"<(script|style|noscript|svg|template)\b.*?</\1>",
    re.IGNORECASE | re.DOTALL,
)
_BLOCK_BREAK = re.compile(
    r"</?(p|div|br|li|ul|ol|h[1-6]|tr|table|section|article|header|footer|nav|main|pre)\b[^>]*>",
    re.IGNORECASE,
)


def is_blocked_host(host: str) -> bool:
    host = (host or "").strip().lower().rstrip(".")
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    if not host:
        return True
    if host in _BLOCKED_HOSTS or host.endswith(".localhost") or host.endswith(".local"):
        return True
    if os.environ.get("BANANA_ALLOW_PRIVATE_URLS", "").lower() in ("1", "true", "yes", "on"):
        return False
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False
    return (
        address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_reserved
        or address.is_multicast
    )


def validate_url(url: str, *, check_blocked: bool = True) -> str:
    url = (url or "").strip()
    parts = urlsplit(url)
    if parts.scheme.lower() not in ("http", "https"):
        raise ToolError(f"Yalnizca http/https desteklenir: {url}")
    if not parts.netloc or not parts.hostname:
        raise ToolError(f"Gecersiz URL: {url}")
    if check_blocked and is_blocked_host(parts.hostname):
        raise ToolError(f"Guvenlik nedeniyle engellenen adres: {parts.hostname}")
    return url


def html_to_text(raw: str) -> str:
    text = _DROP_BLOCKS.sub(" ", raw)
    text = _BLOCK_BREAK.sub("\n", text)
    text = _TAG.sub("", text)
    text = htmlmod.unescape(text)
    lines = [_SPACE.sub(" ", line).strip() for line in text.splitlines()]
    text = "\n".join(line for line in lines if line)
    return _BLANK_LINES.sub("\n\n", text).strip()


def html_title(raw: str) -> str:
    match = _TITLE.search(raw)
    if not match:
        return ""
    return _SPACE.sub(" ", _TAG.sub("", match.group(1))).strip()


def _looks_html(content_type: str, body: bytes) -> bool:
    if "html" in content_type or "xml" in content_type:
        return True
    head = body[:512].lstrip().lower()
    return head.startswith((b"<!doctype html", b"<html", b"<body", b"<?xml"))


def web_fetch(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    url = validate_url(get_str(args, "url"))
    max_chars = get_int(args, "max_chars", 20_000, minimum=200, maximum=100_000)

    preview = Text("GET ", style="bold cyan")
    preview.append(url)
    if not ctx.approver.allow("URL getir", preview):
        preview_publish("fetch", f"{url} reddedildi", ctx.ui)
        return ToolResult(
            "Kullanici URL getirmeyi reddetti.",
            is_error=True,
            summary="reddedildi",
        )

    preview_publish("fetch", f"GET {url}", ctx.ui)
    try:
        with httpx.Client(
            timeout=httpx.Timeout(connect=15.0, read=FETCH_TIMEOUT, write=10.0, pool=15.0),
            follow_redirects=False,
            headers={"User-Agent": "Banana-Coder/1.0 (+terminal agent)"},
        ) as client:
            response = _get_redirected(client, url)
            body = _read_body(response)
    except httpx.HTTPError as exc:
        preview_publish("fetch", f"HATA {url} ({type(exc).__name__})", ctx.ui)
        raise ToolError(f"Baglanti hatasi: {exc}") from exc

    content_type = response.headers.get("content-type", "").lower()
    text = body.decode("utf-8", errors="replace")
    if _looks_html(content_type, body):
        content = html_to_text(text)
        title = html_title(text)
    else:
        content = text.strip()
        title = ""
    status = response.status_code
    preview_publish("fetch", f"{status} {url} ({len(content)} karakter)", ctx.ui)

    if status >= 400:
        return ToolResult(
            f"Hata: HTTP {status} {url}",
            is_error=True,
            summary=f"HTTP {status}",
        )
    header = [f"GET {response.url} -> HTTP {status}"]
    if title:
        header.append(f"baslik: {title}")
    header.append(f"icerik-tipi: {content_type or 'bilinmiyor'}")
    body_text = truncate_middle(content, max_chars)
    return ToolResult(
        "\n".join(header) + "\n\n" + body_text,
        summary=f"HTTP {status} · {len(content)} karakter",
    )


def _get_redirected(client: httpx.Client, url: str, max_hops: int = 5):
    response = client.get(url)
    hops = 0
    while response.is_redirect and hops < max_hops:
        location = response.headers.get("location", "")
        if not location:
            break
        next_url = str(httpx.URL(url).join(location))
        try:
            validate_url(next_url)
        except ToolError as exc:
            response.close()
            raise ToolError(f"Yonlendirme reddedildi: {exc}") from exc
        url = next_url
        response = client.get(url)
        hops += 1
    return response


def _read_body(response) -> bytes:
    response.read()
    if len(response.content) > MAX_FETCH_BYTES:
        raise ToolError(
            f"Yanit cok buyuk: {len(response.content)} bayt (limit {MAX_FETCH_BYTES})"
        )
    return response.content


WEB_HANDLERS = {"web_fetch": web_fetch}
