from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Any

from banana.approval import danger_note
from banana.models import ToolSpec
from banana.tools.common import (
    ToolContext,
    ToolError,
    ToolResult,
    get_int,
    get_str,
    resolve_path,
    truncate_middle,
)
from banana.ui import Text

BASH_SPEC = ToolSpec(
    name="bash",
    description=(
        "Execute a shell command in the working directory and return exit code, "
        "stdout and stderr. Commands are non-interactive: stdin is not available, "
        "so avoid pagers, editors and prompts. Requires user approval unless "
        "auto-approved. Use a generous timeout for builds or tests."
    ),
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Shell command to execute.",
            },
            "timeout": {
                "type": "integer",
                "minimum": 1,
                "maximum": 600,
                "description": "Timeout in seconds (default 120, max 600).",
            },
            "cwd": {
                "type": "string",
                "description": "Optional working directory for the command.",
            },
        },
        "required": ["command"],
    },
    read_only=False,
)


def _as_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def run_command(
    command: str, cwd: Path, timeout: int, output_limit: int
) -> ToolResult:
    env = os.environ.copy()
    env["BANANA_CODER"] = "1"
    env["PAGER"] = "cat"
    env["GIT_PAGER"] = "cat"
    env["GIT_TERMINAL_PROMPT"] = "0"
    started = time.monotonic()
    try:
        completed = subprocess.run(
            command,
            shell=True,
            cwd=str(cwd),
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
            env=env,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = truncate_middle(_as_text(exc.stdout), max(2000, output_limit // 2))
        stderr = truncate_middle(_as_text(exc.stderr), max(2000, output_limit // 2))
        parts = [f"Komut zaman asimina ugradi ({timeout} saniye)."]
        if stdout:
            parts.extend(["--- stdout ---", stdout])
        if stderr:
            parts.extend(["--- stderr ---", stderr])
        return ToolResult(
            "\n".join(parts),
            is_error=True,
            summary=f"zaman asimi ({timeout}s)",
        )
    except OSError as exc:
        raise ToolError(f"Komut baslatilamadi: {exc}") from exc

    duration = time.monotonic() - started
    stdout = completed.stdout or ""
    stderr = completed.stderr or ""
    stdout = truncate_middle(stdout, max(2000, output_limit // 2))
    stderr = truncate_middle(stderr, max(2000, output_limit // 2))
    parts = [
        f"exit_code: {completed.returncode}",
        f"sure: {duration:.2f}s",
    ]
    if stdout:
        parts.extend(["--- stdout ---", stdout.rstrip("\n")])
    if stderr:
        parts.extend(["--- stderr ---", stderr.rstrip("\n")])
    if not stdout and not stderr:
        parts.append("(cikti yok)")
    return ToolResult(
        "\n".join(parts),
        summary=f"exit {completed.returncode} · {duration:.1f}s",
    )


def bash(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    command = get_str(args, "command")
    timeout = get_int(args, "timeout", 120, minimum=1, maximum=600)
    raw_cwd = args.get("cwd")
    if isinstance(raw_cwd, str) and raw_cwd.strip():
        cwd = resolve_path(raw_cwd, ctx.cwd)
    else:
        cwd = ctx.cwd
    if not cwd.exists() or not cwd.is_dir():
        raise ToolError(f"Calisma dizini bulunamadi: {cwd}")

    preview = Text("$ ", style="bold")
    preview.append(command)
    note = danger_note(command)
    if note:
        preview.append("\n" + note, style="bold yellow")
    if not ctx.approver.allow("Komut calistirma", preview):
        return ToolResult(
            "Kullanici komutu calistirmayi reddetti.",
            is_error=True,
            summary="reddedildi",
        )
    return run_command(command, cwd, timeout, ctx.output_limit)


SHELL_HANDLERS = {"bash": bash}
