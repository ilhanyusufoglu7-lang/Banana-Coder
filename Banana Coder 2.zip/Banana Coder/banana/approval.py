from __future__ import annotations

import re

from banana.ui import Text, UI

_DANGEROUS = [
    (re.compile(r"\brm\s+-[a-zA-Z]*[rf][a-zA-Z]*\s+(/|~|\$HOME)\b"), "kok dizin veya ev dizininde silme"),
    (re.compile(r"\bsudo\b"), "yonetici yetkisi gerektiren komut"),
    (re.compile(r"\bgit\s+reset\s+--hard\b"), "commit edilmemis degisiklikleri siler"),
    (re.compile(r"\bgit\s+clean\s+-[a-zA-Z]*f"), "takip edilmeyen dosyalari siler"),
    (re.compile(r"\bmkfs\b|\bdd\s+if="), "diski dogrudan etkiler"),
    (re.compile(r">\s*/dev/(sd|disk|nvme)"), "disk cihazina yazar"),
    (re.compile(r":\(\)\s*\{"), "fork bomb deseni"),
]


def danger_note(command: str) -> str | None:
    notes = [reason for pattern, reason in _DANGEROUS if pattern.search(command)]
    if not notes:
        return None
    return "Dikkat: bu komut " + ", ".join(dict.fromkeys(notes)) + "."


class Approver:
    def __init__(self, ui: UI, mode: str = "ask") -> None:
        self.ui = ui
        self.mode = mode if mode in ("ask", "yolo", "readonly") else "ask"

    @property
    def readonly(self) -> bool:
        return self.mode == "readonly"

    def set_mode(self, mode: str) -> None:
        if mode in ("ask", "yolo", "readonly"):
            self.mode = mode

    def allow(self, title: str, preview: Text | str | None = None) -> bool:
        if self.mode == "readonly":
            self.ui.warn(f"{title} salt-okunur modda engellendi.")
            return False
        if self.mode == "yolo":
            return True
        if not self.ui.interactive:
            self.ui.warn(
                f"{title} icin onay gerekiyor ancak oturum etkilesimsiz. "
                "Otomatik onay icin --yolo kullan."
            )
            return False
        if preview is not None:
            self.ui.print(preview)
        answer = self.ui.ask_approval(
            "Onayla? [e]vet / [h]ayir / [t]umu (bu oturumda hep onayla): "
        )
        if answer == "all":
            self.mode = "yolo"
            self.ui.info("Bu oturum icin tum degisiklikler otomatik onaylanacak.")
            return True
        if answer == "yes":
            return True
        self.ui.info("Islem reddedildi.")
        return False
