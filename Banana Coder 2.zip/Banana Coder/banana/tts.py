from __future__ import annotations

import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import httpx

from banana.net import ProviderError, http_error_message

TTS_URL = "https://openrouter.ai/api/v1/audio/speech"
TTS_MODEL = "heygen/heygen-voice-1-turbo:free"
# HeyGen yalnizca response_format="pcm" kabul eder (44.1 kHz, 16-bit mono).
TTS_PCM_SAMPLE_RATE = 44100
TTS_VOICES = (
    "gareth",
    "nadine",
    "tabitha",
    "bram",
    "noelle",
    "meredith",
    "sabrina",
    "lucian",
    "weston",
    "vincent",
)
TTS_DEFAULT_VOICE = "gareth"


def _clean_for_speech(text: str, limit: int = 4000) -> str:
    """Kod bloklarini/indirme isaretlerini ayikla; konusmaya uygun duz metin."""
    lines: list[str] = []
    in_code = False
    for raw in (text or "").splitlines():
        stripped = raw.strip()
        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if stripped.startswith(("#", "|", "---")):
            continue
        lines.append(stripped)
    cleaned = " ".join(part for part in lines if part).strip()
    if len(cleaned) > limit:
        cleaned = cleaned[:limit].rsplit(" ", 1)[0] + "..."
    return cleaned


def synthesize(
    api_key: str,
    text: str,
    *,
    voice: str = TTS_DEFAULT_VOICE,
    model: str = TTS_MODEL,
    timeout: float = 120.0,
) -> Path:
    """Metni seslendir, gecici WAV dosyasinin yolunu dondur."""
    key = (api_key or "").strip()
    if not key:
        raise ProviderError(
            "Ses icin OpenRouter API anahtari gerekiyor. /api openrouter ile ekle.",
            provider="openrouter",
        )
    speech = _clean_for_speech(text)
    if not speech:
        raise ProviderError("Seslendirilecek metin bos.")
    payload = {
        "model": model,
        "input": speech,
        "voice": voice,
        "response_format": "pcm",
    }
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    with httpx.Client(timeout=timeout) as client:
        response = client.post(TTS_URL, headers=headers, json=payload)
    if response.status_code >= 400:
        raise ProviderError(
            http_error_message("openrouter", response.status_code, response.text),
            provider="openrouter",
            status_code=response.status_code,
        )
    content = response.content
    if not content:
        raise ProviderError("OpenRouter bos ses verisi dondurdu.", provider="openrouter")
    out = Path(tempfile.gettempdir()) / "banana_tts_output.wav"
    # Ham PCM'i afplay'in calabilecegi WAV kapsayicina sar (44.1 kHz, 16-bit mono).
    with wave.open(str(out), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(TTS_PCM_SAMPLE_RATE)
        wav.writeframes(content)
    return out


def player_command() -> list[str] | None:
    """Makinede mevcut bir WAV oynatici komutu bul."""
    for name, args in (
        ("afplay", ["afplay"]),
        ("ffplay", ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"]),
        ("mpv", ["mpv", "--really-quiet"]),
        ("aplay", ["aplay", "-q"]),
        ("paplay", ["paplay"]),
    ):
        if shutil.which(name):
            return args
    return None


def play(path: Path) -> bool:
    """Dosyayi arka planda degil, bloklayarak oynat. Oynatici yoksa False."""
    cmd = player_command()
    if cmd is None:
        return False
    try:
        subprocess.run(cmd + [str(path)], check=False)
    except OSError:
        return False
    return True
