"""Cikis katmani: Rich yok, ham ANSI.

Bu modull iki arayuzun ortak atasidir:
- ``UI``      : satir tabanli (boru/`-p`/TTY olmayan) mod
- ``TextualUI`` (banana/tui.py): tam ekran Textual arayuzu

Ayni yontem adlari kullanilir, boylece cli.py ve agent.py hangi arayuzle
calistigini bilmek zorunda degil.
"""

from __future__ import annotations

import difflib
import getpass
import sys
from typing import Iterable, Sequence

from banana import preview as _preview

BANANA = "#f5c542"

_COLORS = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
    "bright_black": 60,
    "grey": 60,
    "gray": 60,
}

_RESET = "\x1b[0m"


def _ansi(style: str, enabled: bool) -> str:
    """'bold dim cyan' gibi bir stili ANSI on-ekine cevir."""
    if not style or not enabled:
        return ""
    codes: list[str] = []
    for token in style.split():
        if token == "bold":
            codes.append("1")
        elif token == "dim":
            codes.append("2")
        elif token == "italic":
            codes.append("3")
        elif token == "underline":
            codes.append("4")
        elif token.startswith("#"):
            try:
                rgb = (int(token[1:3], 16), int(token[3:5], 16), int(token[5:7], 16))
            except ValueError:
                continue
            codes.append(f"38;2;{rgb[0]};{rgb[1]};{rgb[2]}")
        elif token in _COLORS:
            codes.append(str(_COLORS[token] + 30))
    if not codes:
        return ""
    return "\x1b[" + ";".join(codes) + "m"


class Text:
    """Stil parcalarindan olusan metin (Rich Text'in yerine geciyor)."""

    __slots__ = ("segments",)

    def __init__(self, text: str = "", style: str = "") -> None:
        self.segments: list[tuple[str, str]] = [(str(text), style)] if text else []

    def append(self, text: str, style: str = "") -> "Text":
        if text:
            self.segments.append((str(text), style))
        return self

    def __add__(self, other: "Text | str") -> "Text":
        merged = Text()
        merged.segments = list(self.segments)
        if isinstance(other, Text):
            merged.segments += other.segments
        elif other:
            merged.segments.append((str(other), ""))
        return merged

    def __bool__(self) -> bool:
        return bool(self.segments)

    def __str__(self) -> str:
        return "".join(part for part, _style in self.segments)

    def plain(self) -> str:
        return str(self)

    def render(self, color: bool = True) -> str:
        if not color:
            return str(self)
        out: list[str] = []
        for part, style in self.segments:
            prefix = _ansi(style, color)
            out.append(f"{prefix}{part}{_RESET}" if prefix else part)
        return "".join(out)

    def markup(self) -> str:
        """Textual markup dizisi ('[style]metin[/style]')."""
        out: list[str] = []
        for part, style in self.segments:
            body = part.replace("[", "\\[")
            if style:
                out.append(f"[{style}]{body}[/{style}]")
            else:
                out.append(body)
        return "".join(out)

    @classmethod
    def assemble(cls, *pairs: tuple[str, str]) -> "Text":
        text = cls()
        for part, style in pairs:
            text.append(part, style)
        return text

    @classmethod
    def join(cls, items: Sequence["Text"], sep: str = "\n") -> "Text":
        text = cls()
        for index, item in enumerate(items):
            if index:
                text.append(sep)
            text.segments += list(item.segments)
        return text


BANNER_ART = "\n".join(
    line.rstrip()
    for line in """
████   ███  █   █  ███  █   █  ███      ███   ███  ████  ████  █████ ████
█   █ █   █ ██  █ █   █ ██  █ █   █    █     █   █ █   █ █   █ █     █   █
████  █████ █ █ █ █████ █ █ █ █████    █     █   █ █   █ █   █ ████  ████
█   █ █   █ █  ██ █   █ █  ██ █   █    █     █   █ █   █ █   █ █     █  █
████  █   █ █   █ █   █ █   █ █   █     ███   ███  ████  ████  █████ █   █
""".strip(
        "\n"
    ).splitlines()
)

_WIDTH = 78


def _terminal_width() -> int:
    import shutil

    columns = shutil.get_terminal_size((90, 24)).columns
    return max(40, min(_WIDTH, columns - 2))


def _box(lines: Sequence[str], title: str = "", width: int | None = None) -> Text:
    """Kesikli kenarlikli bilgi kutusu (Freebuff tarzi)."""
    import textwrap

    inner = width or _terminal_width()
    out = Text()
    head = f"╭─ {title} " if title else "╭─"
    out.append(head + "╌" * max(0, inner - len(head) - 1) + "╮\n", style="yellow")
    body = inner - 4
    for line in lines:
        for chunk in textwrap.wrap(line, width=body) or [""]:
            out.append("╎ " + chunk.ljust(body) + " ╮\n", style="yellow")
    out.append("╰" + "╌" * (inner - 1) + "╯", style="yellow")
    return out


class UI:
    """Satir tabanli arayuz. Textual olmadiginda ya da akis TTY degilken kullanilir."""

    is_tui = False

    def __init__(
        self,
        *,
        color: bool = True,
        show_reasoning: bool = False,
        one_shot: bool = False,
        stream_output: bool = True,
        sink=None,
        err=None,
    ) -> None:
        self.color = color
        self.show_reasoning = show_reasoning
        self.one_shot = one_shot
        self.stream_output = stream_output
        self.sink = sink if sink is not None else sys.stdout
        self.err = err if err is not None else sys.stderr
        self.interactive = (
            sys.stdin.isatty() and getattr(self.sink, "isatty", lambda: False)()
        )
        self._wrote_text = False
        self._at_line_start = True
        self._thinking_open = False

    # ------------------------------------------------------------------ yardimcilar

    def _stream(self, to_err: bool = False):
        return self.err if to_err else self.sink

    def _emit(self, renderable, *, to_err: bool = False) -> None:
        text = renderable
        if isinstance(text, Text):
            body = text.render(self.color)
        else:
            body = str(text)
        stream = self._stream(to_err)
        stream.write(body + "\n")
        stream.flush()

    def _status_err(self) -> bool:
        return self.one_shot

    # ------------------------------------------------------------------ giris

    def print(self, renderable) -> None:
        self._emit(renderable, to_err=self._status_err())

    def info(self, message: str) -> None:
        self._emit(Text(message, style="dim"), to_err=self._status_err())

    def warn(self, message: str) -> None:
        self._emit(
            Text.assemble(("> UYARI ", "bold yellow"), (message, "")),
            to_err=self._status_err(),
        )

    def error(self, message: str) -> None:
        self._emit(
            Text.assemble(("> HATA ", "bold red"), (message, "")), to_err=True
        )

    def note(self, message: str) -> None:
        self._emit(Text(message, style="italic dim"), to_err=self._status_err())

    def table(self, headers: Sequence[str], rows: Iterable[Sequence[str]]) -> None:
        body = [[str(cell) for cell in row] for row in rows]
        heads = [str(header) for header in headers]
        widths = [len(head) for head in heads]
        for row in body:
            for index, cell in enumerate(row):
                if index < len(widths):
                    widths[index] = max(widths[index], len(cell))
        out = Text()
        out.append("  " + "  ".join(h.ljust(widths[i]) for i, h in enumerate(heads)).rstrip() + "\n", style="bold")
        out.append("  " + "  ".join("-" * width for width in widths).rstrip() + "\n", style="dim")
        for row in body:
            cells = [
                (row[index] if index < len(row) else "").ljust(widths[index])
                for index in range(len(heads))
            ]
            out.append("  " + "  ".join(cells).rstrip() + "\n")
        self._emit(out, to_err=self._status_err())

    def final(self, text: str) -> None:
        if not text:
            return
        if self.one_shot:
            self.sink.write(text if text.endswith("\n") else text + "\n")
            self.sink.flush()
            return
        self._emit(_box(text.splitlines(), title="banana"), to_err=False)

    def banner(
        self,
        version: str,
        model: str,
        provider_label: str,
        cwd: str,
        approval: str,
        session_note: str | None = None,
    ) -> None:
        width = _terminal_width()
        out = Text()
        for line in BANNER_ART.splitlines():
            out.append(line.center(width) + "\n", style=f"bold {BANANA}")
        out.append(f"v{version}".center(width) + "\n", style="dim italic")
        out.append("═" * width + "\n", style=BANANA)
        self._emit(out)
        lines = [
            f"model {model}   saglayici {provider_label}",
            f"dizin {cwd}   izin {approval}",
        ]
        if session_note:
            lines.append(session_note)
        self._emit(_box(lines))
        self._emit(
            Text("/help yazarak komutlari, /quit ile cikisi gorebilirsin.", style="dim")
        )

    def boost_preview(self, original: str, upgraded: str) -> None:
        if self.one_shot:
            return
        self._emit(_box(upgraded.splitlines(), title="prompt upgrade edildi"))

    def preview_line(self, line: str) -> None:
        if not _preview.should_print_inline():
            return
        self._emit(Text("PV " + line, style="dim cyan"))

    def show_panel(self, visible: bool = True) -> None:
        """Panel bu arayuzde widget degil; tmux/akis satirlari devrede."""
        return None

    def set_panel_width(self, percent: int) -> None:
        return None

    # ------------------------------------------------------------------ akis

    def assistant_start(self) -> None:
        if self.one_shot:
            return
        self._emit(
            Text.assemble(
                ("banana", f"bold {BANANA}"), (" ", ""), ("─" * 40, "dim")
            )
        )

    def assistant_end(self) -> None:
        self.break_thinking()
        if not self.one_shot:
            self._emit(Text("─" * 44, style="dim"))

    def finish_output(self) -> None:
        self.break_thinking()
        if self.one_shot and self._wrote_text and not self._at_line_start:
            self.sink.write("\n")
            self.sink.flush()
            self._at_line_start = True

    def stream_text(self, text: str) -> None:
        if not self.stream_output:
            return
        self.sink.write(text)
        self.sink.flush()
        self._wrote_text = True
        self._at_line_start = text.endswith("\n")

    def stream_thinking(self, text: str) -> None:
        if not self.show_reasoning or not self.stream_output:
            return
        if not self._thinking_open:
            self.sink.write("\n[ reasoning ] ")
            self._thinking_open = True
        self.sink.write(text)
        self.sink.flush()

    def break_thinking(self) -> None:
        if self._thinking_open:
            self.sink.write("\n")
            self.sink.flush()
            self._thinking_open = False

    def tool_call(self, name: str, summary: str) -> None:
        line = Text("  -> ")
        line.append(name, style="bold cyan")
        if summary:
            line.append(" ")
            line.append(summary, style="dim")
        self._emit(line, to_err=self._status_err())

    def tool_result(self, ok: bool, summary: str) -> None:
        line = Text("  ")
        line.append("+ " if ok else "x ", style="bold green" if ok else "bold red")
        line.append(summary, style="dim")
        self._emit(line, to_err=self._status_err())

    def usage(
        self,
        input_tokens: int,
        output_tokens: int,
        elapsed: float,
        cost: float | None = None,
    ) -> None:
        if self.one_shot:
            return
        parts = [f"{input_tokens} in", f"{output_tokens} out", f"{elapsed:.1f}s"]
        if cost is not None:
            parts.append(f"${cost:.4f}")
        self._emit(Text("  " + " / ".join(parts), style="dim italic"))

    def status(self, message: str):
        return _Status(self, message)

    def progress(self, label: str):
        return _Progress(self, label)

    # ------------------------------------------------------------------ girdi

    def ask_approval(self, prompt: str) -> str:
        try:
            answer = self._read_line(prompt)
        except (EOFError, KeyboardInterrupt):
            self._emit("")
            return "no"
        answer = answer.strip().lower()
        if answer in ("e", "evet", "y", "yes"):
            return "yes"
        if answer in ("t", "tumu", "tum", "a", "all"):
            return "all"
        return "no"

    def ask_line(self, prompt: str, default: str = "") -> str:
        try:
            return self._read_line(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            self._emit("")
            return default

    def ask_secret(self, prompt: str) -> str:
        try:
            if self.color:
                self.sink.write(f"\x1b[1m{prompt}\x1b[0m")
            else:
                self.sink.write(prompt)
            self.sink.flush()
            return getpass.getpass("").strip()
        except (EOFError, KeyboardInterrupt):
            self._emit("")
            return ""

    def prompt(self, text: str) -> str:
        return self._read_line(text)

    def ask_choice(
        self, prompt: str, choices: Sequence[str], default: str = ""
    ) -> str:
        self._emit(Text(prompt, style="bold"))
        for index, choice in enumerate(choices, start=1):
            self._emit(Text(f"  {index}. {choice}"))
        try:
            answer = self._read_line("Secim: ").strip()
        except (EOFError, KeyboardInterrupt):
            self._emit("")
            return default
        if answer.isdigit():
            idx = int(answer) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        for choice in choices:
            if answer.lower() == choice.lower():
                return choice
        return default

    def _read_line(self, prompt: str) -> str:
        if self.color:
            self.sink.write(f"\x1b[1m{prompt}\x1b[0m")
        else:
            self.sink.write(prompt)
        self.sink.flush()
        line = sys.stdin.readline()
        if not line:
            raise EOFError
        return line.rstrip("\n")


class _Status:
    """agent.py'deki `with ui.status(...)` icin sade baglam aygit."""

    def __init__(self, ui: UI, message: str) -> None:
        self.ui = ui
        self.message = message
        self._shown = False

    def start(self) -> None:
        if self.ui.one_shot or not self.ui.interactive:
            return None
        self.ui.sink.write(f"\x1b[2m… {self.message}\x1b[0m\r")
        self.ui.sink.flush()
        self._shown = True

    def stop(self) -> None:
        if self._shown:
            self.ui.sink.write("\x1b[2K")
            self.ui.sink.flush()
            self._shown = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_exc) -> None:
        self.stop()
        return None


class _Progress:
    """Indirmeler icin tek satirlik ilerleme cubugu (Rich Progress yerine)."""

    def __init__(self, ui: UI, label: str) -> None:
        self.ui = ui
        self.label = label
        self.total = 0
        self.done = 0
        self._active = False

    def __enter__(self):
        self._active = self.ui.interactive and not self.ui.one_shot
        return self

    def __exit__(self, *_exc) -> None:
        self.clear()
        return None

    def update(self, done: int, total: int) -> None:
        self.done = done
        self.total = total
        if not self._active:
            return
        if total:
            ratio = done / total
            filled = int(ratio * 28)
            bar = "#" * filled + "." * (28 - filled)
            line = f"{self.label[:24]:<24} [{bar}] {ratio * 100:3.0f}% {done / 1e6:.1f}/{total / 1e6:.1f} MB"
        else:
            line = f"{self.label[:24]:<24} {done / 1e6:.1f} MB"
        self.ui.sink.write("\r\x1b[2K" + line)
        self.ui.sink.flush()

    def clear(self) -> None:
        if self._active:
            self.ui.sink.write("\r\x1b[2K")
            self.ui.sink.flush()


def render_diff(
    path: str,
    old: str | None,
    new: str,
    *,
    max_lines: int = 240,
    context: int = 3,
) -> Text:
    old_lines = (old or "").splitlines()
    new_lines = new.splitlines()
    diff = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{path}" if old is not None else "/dev/null",
            tofile=f"b/{path}",
            lineterm="",
            n=context,
        )
    )
    text = Text()
    text.append(
        ("Duzenle: " if old is not None else "Olustur: ") + path + "\n", style="bold"
    )
    if not diff:
        text.append("(degisiklik yok)\n", style="dim")
        return text
    shown = 0
    for line in diff:
        if shown >= max_lines:
            text.append(f"... (diff {len(diff) - max_lines} satir daha)\n", style="yellow")
            break
        display = line if len(line) <= 500 else line[:500] + " ..."
        if line.startswith("+++") or line.startswith("---"):
            style = "bold"
        elif line.startswith("@@"):
            style = "cyan"
        elif line.startswith("+"):
            style = "green"
        elif line.startswith("-"):
            style = "red"
        else:
            style = "dim"
        text.append(display + "\n", style=style)
        shown += 1
    return text
