from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Union


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    raw_arguments: str = ""
    parse_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "arguments": self.arguments,
            "raw_arguments": self.raw_arguments,
            "parse_error": self.parse_error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ToolCall":
        arguments = data.get("arguments")
        return cls(
            id=str(data.get("id") or ""),
            name=str(data.get("name") or ""),
            arguments=arguments if isinstance(arguments, dict) else {},
            raw_arguments=str(data.get("raw_arguments") or ""),
            parse_error=data.get("parse_error"),
        )


@dataclass
class Message:
    role: str
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str | None = None
    tool_name: str | None = None
    is_error: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "tool_calls": [call.to_dict() for call in self.tool_calls],
            "tool_call_id": self.tool_call_id,
            "tool_name": self.tool_name,
            "is_error": self.is_error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Message":
        calls = data.get("tool_calls")
        return cls(
            role=str(data.get("role") or "user"),
            content=str(data.get("content") or ""),
            tool_calls=[
                ToolCall.from_dict(item) for item in calls if isinstance(item, dict)
            ]
            if isinstance(calls, list)
            else [],
            tool_call_id=data.get("tool_call_id"),
            tool_name=data.get("tool_name"),
            is_error=bool(data.get("is_error")),
        )

    def approx_chars(self) -> int:
        size = len(self.content) + 40
        for call in self.tool_calls:
            size += len(call.name) + len(call.raw_arguments) + 40
        return size


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    cost: float | None = None

    def add(self, other: "Usage") -> None:
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.cache_read_tokens += other.cache_read_tokens
        self.cache_write_tokens += other.cache_write_tokens
        if other.cost is not None:
            self.cost = (self.cost or 0.0) + other.cost

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_write_tokens": self.cache_write_tokens,
            "cost": self.cost,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Usage":
        return cls(
            input_tokens=int(data.get("input_tokens") or 0),
            output_tokens=int(data.get("output_tokens") or 0),
            cache_read_tokens=int(data.get("cache_read_tokens") or 0),
            cache_write_tokens=int(data.get("cache_write_tokens") or 0),
            cost=data.get("cost") if isinstance(data.get("cost"), (int, float)) else None,
        )


@dataclass
class TextDelta:
    text: str


@dataclass
class ThinkingDelta:
    text: str


@dataclass
class StreamDone:
    message: Message
    usage: Usage
    stop_reason: str | None = None
    model: str = ""


Event = Union[TextDelta, ThinkingDelta, StreamDone]


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]
    read_only: bool = False

    def as_openai(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    def as_anthropic(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }


MODEL_PRESETS: dict[str, str] = {
    "claude": "anthropic/claude-sonnet-5-5",
    "claude-opus": "anthropic/claude-opus-5-5",
    "claude-haiku": "anthropic/claude-haiku-5-5",
    "gpt": "openai/gpt-6.1-terra",
    "gpt-mini": "openai/gpt-6.1-sol",
    "gemini": "google/gemini-4-argon",
    "gemini-flash": "google/gemini-3.8-flash",
    "or-claude": "openrouter/anthropic/claude-sonnet-5.5",
    "or-gpt": "openrouter/openai/gpt-6.1-terra",
    "or-gemini": "openrouter/google/gemini-4-argon",
    "or-deepseek": "openrouter/deepseek/deepseek-v4-pro",
    "or-qwen": "openrouter/qwen/qwen3.8-flash",
    "or-free": "openrouter/openrouter/free",
    "or-free-gemma": "openrouter/google/gemma-4-31b-it:free",
    "or-free-nemotron": "openrouter/nvidia/nemotron-3-ultra-550b-a55b:free",
}

_PROVIDER_PREFIXES = {
    "openrouter": "openrouter",
    "or": "openrouter",
    "openai": "openai",
    "anthropic": "anthropic",
    "claude": "anthropic",
    "google": "gemini",
    "gemini": "gemini",
    "local": "local",
}


def parse_model(spec: str, default_provider: str | None = None) -> tuple[str, str]:
    spec = (spec or "").strip()
    if not spec:
        raise ValueError("Model adi bos olamaz.")
    spec = MODEL_PRESETS.get(spec, spec)

    lowered = spec.lower()
    if lowered == "local":
        return "local", ""

    if "/" in spec:
        prefix, rest = spec.split("/", 1)
        provider = _PROVIDER_PREFIXES.get(prefix.lower())
        if provider:
            if not rest.strip():
                raise ValueError(f"Model adi eksik: {spec}")
            return provider, rest
        if lowered.endswith(".gguf"):
            return "local", spec
        return "openrouter", spec

    if lowered.endswith(".gguf"):
        return "local", spec

    if lowered.startswith("claude"):
        provider = "anthropic"
    elif lowered.startswith(("gpt", "o1", "o3", "o4", "chatgpt")):
        provider = "openai"
    elif lowered.startswith("gemini"):
        provider = "gemini"
    else:
        provider = default_provider or "openrouter"
    return provider, spec
