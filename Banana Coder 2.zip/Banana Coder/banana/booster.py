from __future__ import annotations

from banana.config import Config
from banana.models import Message, MODEL_PRESETS, parse_model
from banana.net import ProviderError
from banana.providers import create_provider

# Upgrade sonrasi metnin basina konacak isaret; mock/izleme icin de kullanilir.
BOOST_MARKER = "[boost"

# /boost model seciminde onerilen kisayollar.
BOOST_MODEL_CHOICES = tuple(
    key for key in MODEL_PRESETS if key.startswith("or")
) + ("gpt-mini", "gemini-flash")

BOOST_SYSTEM = (
    "You are a prompt-upgrade assistant for a senior coding agent. "
    "Rewrite the user's raw request into a clearer, more specific and "
    "actionable prompt the coding agent can execute. Preserve the original "
    "intent and language. Add missing details (acceptance criteria, files, "
    "constraints) only when obvious. Reply with ONLY the upgraded prompt, no "
    "preamble, no quotes, no code fences."
)


def boost_available(config: Config) -> bool:
    if not config.boost_enabled:
        return False
    try:
        provider_name, _ = parse_model(config.boost_model)
    except ValueError:
        return False
    if provider_name == "local":
        return True
    return bool(config.api_key(provider_name))


def upgrade_prompt(config: Config, raw: str, *, max_tokens: int = 400) -> str:
    """Kullanici promptunu upgrade modeliyle yeniden yazdir.

    Hata olursa veya bos donerse orijinal metni aynen dondurur (gecisli).
    """
    raw = (raw or "").strip()
    if not raw or not config.boost_enabled:
        return raw
    try:
        provider_name, model = parse_model(config.boost_model)
        provider = create_provider(config, provider_name)
    except (ProviderError, ValueError):
        return raw
    try:
        message, _usage, _stop, _model = provider.complete(
            model=model,
            system=BOOST_SYSTEM,
            messages=[Message(role="user", content=raw)],
            max_tokens=max_tokens,
            temperature=0.3,
        )
    except ProviderError:
        return raw
    finally:
        provider.close()
    upgraded = (message.content or "").strip()
    if not upgraded or len(upgraded) < 3:
        return raw
    return upgraded
