"""Textual tabanli tam ekran arayuz.

Gorunum Freebuff'in terminal arayuzunden ilham alir: ustte piksel banner,
kesikli (dashed) kenarlikli bilgi kutusu, ortada konusma akisi, sagda canli
islem paneli, altta komut onerileri ve giris satiri, en altta durum cubugu.

Rich kullanilmaz; cikis Textual widget'lariyla yapilir. `banana.ui.UI`
arayuzunun ayni yontem adlarini karsilar, boylece cli.py'daki REPL dongusu
degismeden her iki arayuzle de calisir.
"""

from __future__ import annotations

from queue import Empty, Queue
from typing import Callable, Sequence

from textual import events
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Input, Static

from banana import preview as _preview
from banana.ui import BANANA, BANNER_ART, Text
from banana.ui import UI as PlainUI

QUIT = object()

CSS = """
Screen {
    background: $surface;
}

Vertical {
    width: 1fr;
    height: 1fr;
}

#banner {
    color: #f5c542;
    text-style: bold;
    height: auto;
    padding: 0 1;
}

#versionline {
    color: #f5c542;
    text-style: italic;
    text-align: center;
    height: 1;
}

#infobox {
    border: dashed #f5c542;
    border-title-align: left;
    padding: 0 1;
    height: auto;
    color: $text;
}

#body {
    height: 1fr;
}

#chat {
    width: 1fr;
    padding: 0 1;
}

#activity {
    width: 42;
    border: dashed #6ec7ff;
    border-title-align: left;
    padding: 0 1;
    margin: 0 1 0 0;
}

#activity.hidden {
    display: none;
}

#hints {
    border: dashed #6ec7ff;
    padding: 0 1;
    height: auto;
    max-height: 10;
}

#hints.hidden {
    display: none;
}

#prompt {
    border: tall #f5c542;
    padding: 0 1;
}

#statusbar {
    height: 1;
    background: #1c1c1e;
    color: #f5c542;
    padding: 0 1;
}

.chatline {
    height: auto;
}

.stream {
    height: auto;
}

.tool {
    color: #6ec7ff;
}

.muted {
    color: #888888;
}

.warn {
    color: #ffd75f;
}

.error {
    color: #ff6b6b;
}

.boxed {
    border: dashed #f5c542;
    padding: 0 1;
    height: auto;
}

.diff {
    height: auto;
}
"""


class ChatLine(Static):
    """Konusma akisindaki tek blok."""


class StreamLine(Static):
    """Akan model yanitini biriktiren blok."""

    def __init__(self) -> None:
        super().__init__("", classes="stream")
        self._buffer = ""

    def feed(self, text: str) -> None:
        self._buffer += text.replace("[", "\\[")
        self.update(self._buffer)

    @property
    def text(self) -> str:
        return self._buffer


class ActivityPanel(VerticalScroll):
    """Sag panel: preview olay akisi."""

    def __init__(self) -> None:
        super().__init__(id="activity", classes="hidden")
        self.border_title = "canli islem paneli"

    def add(self, line: str) -> None:
        if not line:
            self.remove_children()
            return
        if len(self.children) > 220:
            self.remove_children(self.children[:40])
        safe = line.replace("[", "\\[")
        self.mount(ChatLine(safe, classes="chatline muted"))
        self.scroll_end(animate=False)


class HintBar(Static):
    """Giris yazilirken slash komut onerileri."""

    def __init__(self) -> None:
        super().__init__("", id="hints", classes="hidden")
        self.border_title = "komutlar"


class BananaApp(App[None]):
    CSS = CSS
    BINDINGS = [
        ("ctrl+c", "quit", "Cikis"),
        ("ctrl+l", "clear_chat", "Ekrani temizle"),
        ("ctrl+p", "toggle_panel", "Paneli ac/kapat"),
        ("f1", "show_help", "Yardim"),
    ]

    def __init__(
        self,
        *,
        status_provider: Callable[[], str],
        info_provider: Callable[[], str],
        hints: Sequence[tuple[str, str]],
        repl: Callable[[], int],
        version: str = "",
    ) -> None:
        super().__init__()
        self.ui = TextualUI(self)
        self._answers: Queue = Queue()
        self._status_provider = status_provider
        self._info_provider = info_provider
        self._hints = list(hints)
        self._repl = repl
        self._version = version
        self._worker_started = False
        self._panel_enabled = False

    # ------------------------------------------------------------------ kurulum

    def compose(self) -> ComposeResult:
        yield Vertical(
            Static(BANNER_ART, id="banner"),
            Static(f"v{self._version}" if self._version else "", id="versionline"),
            Static("", id="infobox"),
            Horizontal(
                VerticalScroll(id="chat"),
                ActivityPanel(),
            ),
            HintBar(),
            Input(placeholder="mesaj yaz, /help ile komutlar", id="prompt"),
            Static("", id="statusbar"),
        )

    def on_mount(self) -> None:
        self.query_one("#prompt", Input).focus()
        self._refresh_chrome()
        self.set_interval(0.5, self._refresh_chrome)
        _preview.set_listener(self._on_preview_event)
        if not self._worker_started:
            self._worker_started = True
            self.run_worker(self._run_repl, thread=True, name="banana-repl")

    def on_unmount(self) -> None:
        _preview.set_listener(None)
        # Worker thread girdi bekliyorsa EOFError ile uyandir.
        self._answers.put(QUIT)

    def _run_repl(self) -> None:
        code = 0
        try:
            code = self._repl()
        finally:
            self._answers.put(QUIT)
            try:
                self.call_from_thread(self.exit, code or None)
            except RuntimeError:
                pass

    # ------------------------------------------------------------------ yardimcilar

    @property
    def on_ui_thread(self) -> bool:
        """Cagiran iplik Textual'in olay dongusunu calistiriyor mu?"""
        import asyncio

        loop = getattr(self, "_loop", None)
        if loop is None:
            return True
        try:
            return asyncio.get_running_loop() is loop
        except RuntimeError:
            return False

    def _refresh_chrome(self) -> None:
        try:
            self.query_one("#statusbar", Static).update(self._status_provider())
            self.query_one("#infobox", Static).update(self._info_provider())
        except Exception:
            pass

    def _on_preview_event(self, line: str) -> None:
        """preview.feed() tarafindan worker thread'inden cagrilir."""
        def apply() -> None:
            panel = self.query_one(ActivityPanel)
            if not self._panel_enabled:
                self._panel_enabled = True
                panel.remove_class("hidden")
            panel.add(line)

        self.safe_call(apply)

    def safe_call(self, action: Callable[[], None]) -> None:
        """Cagriyi her zaman UI ipliginde calistirir (worker'dan da guvenli)."""
        if not self.is_running:
            return
        if self.on_ui_thread:
            action()
            return
        try:
            self.call_from_thread(action)
        except Exception:
            pass

    # ------------------------------------------------------------------ giris

    def request_line(self, label: str, *, password: bool = False) -> str:
        """REPL dongusunun bekledigi girdi satiri (bloklayici, worker thread)."""

        def prepare() -> None:
            prompt = self.query_one("#prompt", Input)
            prompt.password = password
            prompt.prompt = label + " " if label else ""
            prompt.value = ""
            prompt.placeholder = ""
            prompt.focus()

        if self.on_ui_thread:
            prepare()
        else:
            self.call_from_thread(prepare)
        answer = self._answers.get()
        if answer is QUIT:
            raise EOFError
        return str(answer)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._answers.put(event.value)
        event.input.value = ""

    # ------------------------------------------------------------------ chat

    def add_chat(self, renderable, *, style: str = "") -> None:
        markup = _to_markup(renderable, style)
        chat = self.query_one("#chat", VerticalScroll)
        chat.mount(ChatLine(markup, classes="chatline"))
        chat.scroll_end(animate=False)

    def add_box(self, renderable, *, title: str = "") -> None:
        markup = _to_markup(renderable)
        widget = ChatLine(markup, classes="boxed")
        if title:
            widget.border_title = title
        chat = self.query_one("#chat", VerticalScroll)
        chat.mount(widget)
        chat.scroll_end(animate=False)

    def begin_stream(self) -> StreamLine:
        chat = self.query_one("#chat", VerticalScroll)
        widget = StreamLine()
        chat.mount(widget)
        chat.scroll_end(animate=False)
        return widget

    def clear_chat(self) -> None:
        chat = self.query_one("#chat", VerticalScroll)
        chat.remove_children()

    def set_hints(self, rows: Sequence[tuple[str, str]]) -> None:
        hints = self.query_one(HintBar)
        if not rows:
            hints.add_class("hidden")
            hints.update("")
            return
        hints.remove_class("hidden")
        width = max(len(name) for name, _ in rows)
        hints.update(
            "\n".join(
                f"[bold]{name.ljust(width)}[/bold]  [dim]{description}[/dim]"
                for name, description in rows
            )
        )

    def on_input_changed(self, event: Input.Changed) -> None:
        value = event.value.strip()
        if not value.startswith("/"):
            self.set_hints([])
            return
        token = value.split()[0]
        matches = [row for row in self._hints if row[0].startswith(token)]
        self.set_hints(matches[:8])

    # ------------------------------------------------------------------ aksiyonlar

    def action_clear_chat(self) -> None:
        self.clear_chat()

    def action_toggle_panel(self) -> None:
        panel = self.query_one(ActivityPanel)
        if panel.has_class("hidden"):
            panel.remove_class("hidden")
            self._panel_enabled = True
            for line in _preview.recent(40):
                panel.add(line)
        else:
            panel.add_class("hidden")
            self._panel_enabled = False

    def action_show_help(self) -> None:
        self._answers.put("/help")


class TextualUI(PlainUI):
    """PlainUI arayuzu; cikislari Textual widget'larina yazar."""

    is_tui = True

    def __init__(self, app: BananaApp) -> None:
        super().__init__(color=True, stream_output=False)
        self.app = app
        self.interactive = True
        self._stream: StreamLine | None = None
        self._thinking: StreamLine | None = None

    # ------------------------------------------------------------------ cikis

    def _emit(self, renderable, *, to_err: bool = False) -> None:
        self.close_stream()
        self.app.safe_call(lambda: self.app.add_chat(renderable))

    def print(self, renderable) -> None:
        self.close_stream()
        self.app.safe_call(lambda: self.app.add_chat(renderable))

    def info(self, message: str) -> None:
        self._emit(Text(message, style="dim"))

    def warn(self, message: str) -> None:
        self._emit(Text.assemble(("> UYARI ", "bold yellow"), (message, "")))

    def error(self, message: str) -> None:
        self._emit(Text.assemble(("> HATA ", "bold red"), (message, "")))

    def note(self, message: str) -> None:
        self._emit(Text(message, style="italic dim"))

    def boost_preview(self, original: str, upgraded: str) -> None:
        body = Text.assemble(("Gonderilen prompt:\n", f"bold {BANANA}"), (upgraded, ""))
        self.app.safe_call(lambda: self.app.add_box(body, title="prompt upgrade edildi"))

    def preview_line(self, line: str) -> None:
        return None

    def show_panel(self, visible: bool = True) -> None:
        def apply() -> None:
            panel = self.app.query_one(ActivityPanel)
            self.app._panel_enabled = bool(visible)
            if visible:
                panel.remove_class("hidden")
                if not len(panel.children):
                    for line in _preview.recent(40):
                        panel.add(line)
            else:
                panel.add_class("hidden")

        self.app.safe_call(apply)

    def set_panel_width(self, percent: int) -> None:
        """Panel genisligini ekran yuzdesi olarak ayarla."""

        def apply() -> None:
            panel = self.app.query_one(ActivityPanel)
            width = max(20, min(70, int(percent)))
            panel.styles.width = ("1fr" if width >= 50 else f"{width}%")

        self.app.safe_call(apply)

    def final(self, text: str) -> None:
        if text:
            self.app.safe_call(lambda: self.app.add_box(text, title="banana"))

    def table(self, headers, rows) -> None:
        body = [[str(cell) for cell in row] for row in rows]
        heads = [str(header) for header in headers]
        widths = [len(head) for head in heads]
        for row in body:
            for index, cell in enumerate(row):
                if index < len(widths):
                    widths[index] = max(widths[index], len(cell))
        lines = ["  ".join(heads[index].ljust(widths[index]) for index in range(len(heads))).rstrip()]
        lines.append("  ".join("-" * width for width in widths))
        for row in body:
            lines.append(
                "  ".join(
                    (row[index] if index < len(row) else "").ljust(widths[index])
                    for index in range(len(heads))
                ).rstrip()
            )
        self._emit("\n".join(lines))

    def banner(
        self,
        version: str,
        model: str,
        provider_label: str,
        cwd: str,
        approval: str,
        session_note: str | None = None,
    ) -> None:
        self.app._version = version
        self.app.safe_call(self.app._refresh_chrome)

    # ------------------------------------------------------------------ akis

    def assistant_start(self) -> None:
        self.close_stream()
        self._stream = None
        header = Text.assemble(
            ("● ", f"bold {BANANA}"), ("banana", f"bold {BANANA}")
        )
        self.app.safe_call(lambda: self.app.add_chat(header))

    def assistant_end(self) -> None:
        self.close_stream()

    def finish_output(self) -> None:
        self.close_stream()

    def stream_text(self, text: str) -> None:
        if self._stream is None:
            self._stream = self.app.call_from_thread(self.app.begin_stream)
        widget = self._stream
        self.app.safe_call(lambda: widget.feed(text))

    def stream_thinking(self, text: str) -> None:
        if not self.show_reasoning:
            return
        if self._thinking is None:
            def start() -> StreamLine:
                chat = self.app.query_one("#chat", VerticalScroll)
                widget = StreamLine()
                chat.mount(widget)
                widget.feed("[ reasoning ] ")
                return widget

            self._thinking = self.app.call_from_thread(start)
        widget = self._thinking
        self.app.safe_call(lambda: widget.feed(text))

    def break_thinking(self) -> None:
        self._thinking = None

    def close_stream(self) -> None:
        self._stream = None
        self._thinking = None

    def tool_call(self, name: str, summary: str) -> None:
        line = Text("  -> ")
        line.append(name, style="bold cyan")
        if summary:
            line.append(" ")
            line.append(summary, style="dim")
        self._emit(line)

    def tool_result(self, ok: bool, summary: str) -> None:
        line = Text("  ")
        line.append("+ " if ok else "x ", style="bold green" if ok else "bold red")
        line.append(summary, style="dim")
        self._emit(line)

    def usage(
        self,
        input_tokens: int,
        output_tokens: int,
        elapsed: float,
        cost: float | None = None,
    ) -> None:
        parts = [f"{input_tokens} in", f"{output_tokens} out", f"{elapsed:.1f}s"]
        if cost is not None:
            parts.append(f"${cost:.4f}")
        self._emit(Text("  " + " / ".join(parts), style="dim italic"))
        self.app.safe_call(self.app._refresh_chrome)

    def status(self, message: str):
        return _AppStatus(self.app, message)

    def progress(self, label: str):
        return _AppProgress(self.app, label)

    # ------------------------------------------------------------------ girdi

    def prompt(self, text: str) -> str:
        answer = self.app.request_line(text)
        line = answer.strip()
        if line and not line.startswith(("/", "!")) and line not in ("exit", "quit"):
            echo = Text.assemble(("sen ", f"bold {BANANA}"), (line, ""))
            self.app.safe_call(lambda: self.app.add_chat(echo))
        return answer

    def ask_line(self, prompt: str, default: str = "") -> str:
        try:
            return self.app.request_line(prompt).strip()
        except EOFError:
            return default

    def ask_secret(self, prompt: str) -> str:
        try:
            return self.app.request_line(prompt, password=True).strip()
        except EOFError:
            return ""

    def ask_approval(self, prompt: str) -> str:
        try:
            answer = self.app.request_line(prompt).strip().lower()
        except EOFError:
            return "no"
        if answer in ("e", "evet", "y", "yes"):
            return "yes"
        if answer in ("t", "tumu", "tum", "a", "all"):
            return "all"
        return "no"

    def ask_choice(
        self, prompt: str, choices: Sequence[str], default: str = ""
    ) -> str:
        numbered = "\n".join(f"  {i}. {choice}" for i, choice in enumerate(choices, 1))
        self._emit(f"{prompt}\n{numbered}")
        try:
            answer = self.app.request_line("Secim:").strip()
        except EOFError:
            return default
        if answer.isdigit():
            index = int(answer) - 1
            if 0 <= index < len(choices):
                return choices[index]
        for choice in choices:
            if answer.lower() == choice.lower():
                return choice
        return default


class _AppStatus:
    def __init__(self, app: BananaApp, message: str) -> None:
        self.app = app
        self.message = message

    def start(self) -> None:
        self.app.safe_call(self._show)

    def _show(self) -> None:
        try:
            self.app.query_one("#statusbar", Static).update(f"... {self.message}")
        except Exception:
            pass

    def stop(self) -> None:
        self.app.safe_call(self.app._refresh_chrome)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_exc) -> None:
        self.stop()
        return None


class _AppProgress:
    def __init__(self, app: BananaApp, label: str) -> None:
        self.app = app
        self.label = label

    def __enter__(self):
        return self

    def __exit__(self, *_exc) -> None:
        self.app.safe_call(self.app._refresh_chrome)
        return None

    def update(self, done: int, total: int) -> None:
        if total:
            text = f"{self.label}: {done / 1e6:.1f}/{total / 1e6:.1f} MB (%{done * 100 // total})"
        else:
            text = f"{self.label}: {done / 1e6:.1f} MB"

        def show() -> None:
            try:
                self.app.query_one("#statusbar", Static).update(text)
            except Exception:
                pass

        self.app.safe_call(show)


def _to_markup(renderable, style: str = "") -> str:
    if isinstance(renderable, Text):
        return renderable.markup()
    text = str(renderable).replace("[", "\\[")
    return f"[{style}]{text}[/{style}]" if style else text
