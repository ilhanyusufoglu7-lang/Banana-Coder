from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from banana.config import SESSIONS_DIR
from banana.models import Message, Usage

SESSION_VERSION = 1


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".session-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def project_hash(cwd: Path) -> str:
    return hashlib.sha256(str(cwd.resolve()).encode("utf-8")).hexdigest()[:16]


def _sanitize_name(name: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-")
    return slug or "session"


def named_session_path(name: str) -> Path:
    return SESSIONS_DIR / f"{_sanitize_name(name)}.json"


def new_session_path(cwd: Path) -> Path:
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    base = f"{project_hash(cwd)}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    path = SESSIONS_DIR / f"{base}.json"
    counter = 1
    while path.exists():
        path = SESSIONS_DIR / f"{base}-{counter}.json"
        counter += 1
    return path


@dataclass
class Session:
    path: Path
    cwd: Path
    provider: str
    model: str
    messages: list[Message] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)

    def save(self) -> None:
        self.updated_at = _now()
        _atomic_json(self.path, self.to_payload())

    def to_payload(self) -> dict[str, Any]:
        return {
            "version": SESSION_VERSION,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "cwd": str(self.cwd),
            "provider": self.provider,
            "model": self.model,
            "usage": self.usage.to_dict(),
            "messages": [message.to_dict() for message in self.messages],
        }

    def clear(self) -> None:
        self.messages = []
        self.usage = Usage()
        self.created_at = _now()
        self.updated_at = self.created_at
        self.save()

    @classmethod
    def from_payload(cls, path: Path, raw: dict[str, Any], fallback_cwd: Path) -> "Session | None":
        if raw.get("version") != SESSION_VERSION:
            return None
        messages = raw.get("messages")
        usage = raw.get("usage")
        loaded_cwd = raw.get("cwd")
        return cls(
            path=path,
            cwd=Path(loaded_cwd).expanduser()
            if isinstance(loaded_cwd, str) and loaded_cwd
            else fallback_cwd,
            provider=str(raw.get("provider") or ""),
            model=str(raw.get("model") or ""),
            messages=[
                Message.from_dict(item) for item in messages if isinstance(item, dict)
            ]
            if isinstance(messages, list)
            else [],
            usage=Usage.from_dict(usage) if isinstance(usage, dict) else Usage(),
            created_at=str(raw.get("created_at") or _now()),
            updated_at=str(raw.get("updated_at") or _now()),
        )

    @classmethod
    def create(
        cls,
        cwd: Path,
        provider: str,
        model: str,
        name: str | None = None,
    ) -> "Session":
        path = named_session_path(name) if name else new_session_path(cwd)
        return cls(path=path, cwd=cwd, provider=provider, model=model)

    @classmethod
    def load_file(cls, path: Path, fallback_cwd: Path) -> "Session | None":
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(raw, dict):
            return None
        return cls.from_payload(path, raw, fallback_cwd)

    @classmethod
    def load_named(cls, name: str, cwd: Path) -> "Session | None":
        path = named_session_path(name)
        if not path.exists():
            return None
        return cls.load_file(path, cwd)

    @classmethod
    def load_latest(cls, cwd: Path) -> "Session | None":
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        prefix = project_hash(cwd)
        candidates = sorted(
            SESSIONS_DIR.glob(f"{prefix}*.json"),
            key=lambda item: item.stat().st_mtime if item.exists() else 0,
            reverse=True,
        )
        best: Session | None = None
        for path in candidates[:50]:
            session = cls.load_file(path, cwd)
            if session is None:
                continue
            if best is None or session.updated_at > best.updated_at:
                best = session
        return best

    @classmethod
    def recent(cls, cwd: Path, limit: int = 10) -> list["Session"]:
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        prefix = project_hash(cwd)
        candidates = sorted(
            SESSIONS_DIR.glob(f"{prefix}*.json"),
            key=lambda item: item.stat().st_mtime if item.exists() else 0,
            reverse=True,
        )
        sessions: list[Session] = []
        for path in candidates[: limit * 3]:
            session = cls.load_file(path, cwd)
            if session is not None:
                sessions.append(session)
        sessions.sort(key=lambda item: item.updated_at, reverse=True)
        return sessions[:limit]
