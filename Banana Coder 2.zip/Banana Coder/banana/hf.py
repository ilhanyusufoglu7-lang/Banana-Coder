from __future__ import annotations

from pathlib import Path
from typing import Callable

import httpx

from banana.net import ProviderError

HF_BASE = "https://huggingface.co"

# (label, repo, dosya, yaklaşık GB, not) - HF API ile dogrulanmis gecarli yollar
GGUF_OFFERS: tuple[tuple[str, str, str, float, str], ...] = (
    (
        "Qwen3-4B-Instruct-2507 Q4_K_M",
        "unsloth/Qwen3-4B-Instruct-2507-GGUF",
        "Qwen3-4B-Instruct-2507-Q4_K_M.gguf",
        2.5,
        "8GB RAM icin ideal: kod + sohbet",
    ),
    (
        "Llama-3.2-3B-Instruct Q4_K_M",
        "bartowski/Llama-3.2-3B-Instruct-GGUF",
        "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        2.0,
        "Dengeli ve hizli",
    ),
    (
        "Qwen2.5-Coder-1.5B Q4_K_M",
        "Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF",
        "qwen2.5-coder-1.5b-instruct-q4_k_m.gguf",
        1.0,
        "Kucuk, kod odakli",
    ),
    (
        "TinyLlama-1.1B-Chat Q4_K_M",
        "TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF",
        "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        0.7,
        "En hafif secenek",
    ),
)


def offer_url(offer: tuple[str, str, str, float, str]) -> str:
    return f"{HF_BASE}/{offer[1]}/resolve/main/{offer[2]}"


def filename_from_url(url: str) -> str:
    tail = url.split("?", 1)[0].rstrip("/").rsplit("/", 1)[-1]
    name = Path(tail).name
    if not name or "." not in name:
        raise ProviderError(f"Gecerli bir GGUF indirme URL'si degil: {url}")
    return name


def download_gguf(
    url: str,
    dest_dir: Path,
    on_progress: Callable[[int, int], None] | None = None,
) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename_from_url(url)
    if dest.exists():
        return dest
    part = dest.with_name(dest.name + ".part")
    client = httpx.Client(
        follow_redirects=True,
        timeout=httpx.Timeout(connect=20.0, read=60.0, write=30.0, pool=20.0),
    )
    done = 0
    try:
        with client, client.stream("GET", url) as response:
            if response.status_code >= 400:
                body = response.read().decode("utf-8", errors="replace")
                raise ProviderError(
                    f"Indirme hatasi (HTTP {response.status_code}): {body[:300]}"
                )
            total = int(response.headers.get("content-length") or 0)
            with open(part, "wb") as handle:
                for chunk in response.iter_bytes(chunk_size=262_144):
                    handle.write(chunk)
                    done += len(chunk)
                    if on_progress is not None:
                        on_progress(done, total)
        part.replace(dest)
    except BaseException:
        part.unlink(missing_ok=True)
        raise
    return dest
