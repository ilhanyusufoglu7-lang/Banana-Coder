from __future__ import annotations

import json
import sys
import time
from typing import Any, Callable, Iterator

import httpx

from banana import __version__
from banana.config import PROVIDER_LABELS
from banana.models import Event

RETRY_STATUS = {408, 409, 425, 429, 500, 502, 503, 504, 529}


class ProviderError(Exception):
    def __init__(
        self,
        message: str,
        *,
        provider: str = "",
        status_code: int | None = None,
        body: str = "",
    ) -> None:
        super().__init__(message)
        self.provider = provider
        self.status_code = status_code
        self.body = body


def _snippet(body: str, limit: int = 800) -> str:
    body = " ".join((body or "").split())
    if len(body) > limit:
        body = body[:limit] + "..."
    return body


def _remedy_hint(body: str) -> str | None:
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return None
    error = data.get("error") if isinstance(data, dict) else None
    if not isinstance(error, dict):
        return None
    hint = error.get("metadata", {}).get("remedy_hint") if isinstance(error.get("metadata"), dict) else None
    if isinstance(hint, str) and hint:
        return hint
    return None


def http_error_message(provider: str, status: int, body: str) -> str:
    label = PROVIDER_LABELS.get(provider, provider)
    detail = _snippet(body)
    remedy = _remedy_hint(body)
    if status in (401, 403):
        reason = "API anahtari gecersiz veya bu islem icin yetkisiz."
    elif status == 402:
        reason = "Hesapta yeterli kredi/bakiye yok."
    elif status == 404:
        reason = "Model veya endpoint bulunamadi. Model adini kontrol et."
    elif status == 429:
        reason = "Hiz limiti asildi."
    elif status in (400, 422):
        reason = "Istek parametreleri saglayici tarafindan reddedildi."
    elif status >= 500:
        reason = "Saglayici tarafinda gecici bir hata olustu."
    else:
        reason = "Istek basarisiz oldu."
    message = f"{label}: {reason} (HTTP {status})"
    if detail:
        message += f"\nSaglayici yaniti: {detail}"
    if remedy:
        message += f"\nOneri: {remedy}"
    return message


def _retry_delay(response: httpx.Response | None, attempt: int) -> float:
    if response is not None:
        header = response.headers.get("retry-after")
        if header:
            try:
                return min(max(float(header), 0.5), 30.0)
            except ValueError:
                pass
    return min(2.0 ** attempt, 8.0)


def _notify_retry(provider: str, attempt: int, retries: int, delay: float, status: int) -> None:
    label = PROVIDER_LABELS.get(provider, provider)
    if status == 429:
        text = f"{label}: Hiz limiti asildi, {delay:.0f}s sonra tekrar deneniyor... ({attempt + 1}/{retries})"
    else:
        text = f"{label}: Gecici hata, {delay:.0f}s sonra tekrar deneniyor... ({attempt + 1}/{retries})"
    sys.stderr.write(text + "\n")
    sys.stderr.flush()


def iter_sse(response: httpx.Response) -> Iterator[tuple[str | None, str]]:
    event: str | None = None
    data: list[str] = []
    for raw_line in response.iter_lines():
        line = raw_line.strip("\r")
        if line == "":
            if data:
                yield event, "\n".join(data)
            event = None
            data = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        yield event, "\n".join(data)


def stream_request(
    client: httpx.Client,
    provider: str,
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    parse: Callable[[httpx.Response], Iterator[Event]],
    *,
    retries: int = 3,
) -> Iterator[Event]:
    last_error: ProviderError | None = None
    for attempt in range(retries + 1):
        emitted = False
        try:
            with client.stream("POST", url, headers=headers, json=payload) as response:
                if response.status_code >= 400:
                    body = response.read().decode("utf-8", errors="replace")
                    error = ProviderError(
                        http_error_message(provider, response.status_code, body),
                        provider=provider,
                        status_code=response.status_code,
                        body=body,
                    )
                    if response.status_code in RETRY_STATUS and attempt < retries:
                        last_error = error
                        delay = _retry_delay(response, attempt)
                        _notify_retry(provider, attempt, retries, delay, response.status_code)
                        time.sleep(delay)
                        continue
                    raise error
                for event in parse(response):
                    emitted = True
                    yield event
                return
        except httpx.TimeoutException as exc:
            label = PROVIDER_LABELS.get(provider, provider)
            error = ProviderError(
                f"{label}: istek zaman asimina ugradi. Ag baglantisini kontrol et.",
                provider=provider,
            )
            if emitted or attempt >= retries:
                raise error from exc
            last_error = error
            delay = _retry_delay(None, attempt)
            _notify_retry(provider, attempt, retries, delay, 0)
            time.sleep(delay)
        except httpx.HTTPError as exc:
            label = PROVIDER_LABELS.get(provider, provider)
            error = ProviderError(
                f"{label}: baglanti hatasi: {exc}",
                provider=provider,
            )
            if emitted or attempt >= retries:
                raise error from exc
            last_error = error
            delay = _retry_delay(None, attempt)
            _notify_retry(provider, attempt, retries, delay, 0)
            time.sleep(delay)
    raise last_error or ProviderError(f"{provider}: istek tamamlanamadi.")


def make_client(timeout: float = 600) -> httpx.Client:
    return httpx.Client(
        timeout=httpx.Timeout(connect=20.0, read=timeout, write=60.0, pool=20.0),
        limits=httpx.Limits(max_connections=8, max_keepalive_connections=4),
        headers={"User-Agent": f"banana-coder/{__version__}"},
        follow_redirects=True,
    )


def fetch_openrouter_models(timeout: float = 30) -> list[dict[str, Any]]:
    url = "https://openrouter.ai/api/v1/models"
    with make_client(timeout=timeout) as client:
        response = client.get(url)
        if response.status_code >= 400:
            raise ProviderError(
                http_error_message("openrouter", response.status_code, response.text),
                provider="openrouter",
                status_code=response.status_code,
            )
        data = response.json()
    models = data.get("data") if isinstance(data, dict) else None
    if not isinstance(models, list):
        raise ProviderError("OpenRouter: model listesi beklenmeyen bir formatta dondu.")
    return [item for item in models if isinstance(item, dict)]
