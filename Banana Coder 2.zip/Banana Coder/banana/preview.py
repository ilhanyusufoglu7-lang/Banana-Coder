from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path

PREVIEW_PANE_TITLE = "banana-preview"
_MAX_LOG_BYTES = 1_000_000
_TAIL_LINES = 400

_active = False
_tmux_attached = False
_path: Path | None = None
_display_lines: list[str] = []
_pane_percent = 45
_listener = None


def set_listener(callback) -> None:
    """Canli arayuz (Textual paneli) icin olay dinleyicisi kaydet."""
    global _listener
    _listener = callback


def init(config_path: Path, *, enabled: bool, pane_percent: int = 45) -> None:
    """Ayar dosyasindan preview hedefini ve acik/kapali durumunu ayarlar."""
    global _active, _path, _pane_percent
    _path = config_path.parent / "preview.log"
    _active = bool(enabled)
    _pane_percent = max(20, min(70, int(pane_percent)))


def path() -> Path | None:
    return _path


def is_active() -> bool:
    return _active


def tmux_attached() -> bool:
    return _tmux_attached


def should_print_inline() -> bool:
    if _listener is not None:
        return False
    return _active and not _tmux_attached and not os.environ.get("BANANA_ONE_SHOT")


def feed(kind: str, text: str) -> str:
    """Etkinligi kuyruk dosyasina yazar ve gosterilecek satiri dondurur."""
    if not text:
        return ""
    line = f"{time.strftime('%H:%M:%S')} [{kind}] {text}".rstrip()
    _append(line)
    _display_lines.append(line)
    del _display_lines[:-200]
    if _listener is not None:
        try:
            _listener(line)
        except Exception:
            pass
    return line


def recent(count: int = 20) -> list[str]:
    return _display_lines[-count:]


def publish(kind: str, text: str, ui=None) -> None:
    """feed + (panel yoksa) anlik UI satiri."""
    line = feed(kind, text)
    if line and ui is not None:
        ui.preview_line(line)


def _append(line: str) -> None:
    if _path is None:
        return
    try:
        _path.parent.mkdir(parents=True, exist_ok=True)
        if _path.exists() and _path.stat().st_size > _MAX_LOG_BYTES:
            data = _path.read_bytes()[-(_MAX_LOG_BYTES // 2) :]
            _path.write_bytes(data)
        with _path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except OSError:
        pass


def tmux_available() -> bool:
    return shutil.which("tmux") is not None


def _run(*args: str) -> str:
    completed = subprocess.run(
        ["tmux", *args], capture_output=True, text=True, timeout=10
    )
    return (completed.stdout or "").strip()


def _tail_command() -> str:
    target = _path or Path("~/.banana/preview.log")
    return f"clear; echo 'Banana Coder - canli islem paneli'; tail -n {_TAIL_LINES} -f {target!r}"


def find_preview_pane() -> str:
    if not tmux_available():
        return ""
    try:
        return _run("find-window", "-ip", PREVIEW_PANE_TITLE)
    except (OSError, subprocess.SubprocessError):
        return ""


def _split_pane(target: str) -> str:
    return _run(
        "split-window",
        "-h",
        "-t",
        target,
        "-p",
        str(_pane_percent),
        _tail_command(),
    )


def attach_pane() -> bool:
    """tmux ile ekrani dikey böler ve kuyruk dosyasini yan panele baglar."""
    global _tmux_attached
    if not tmux_available() or _path is None:
        return False
    try:
        if os.environ.get("TMUX"):
            current = _run("display-message", "-p", "#S:#I")
            if not current:
                return False
            pane = _split_pane(current)
            if not pane:
                return False
            _run("select-pane", "-t", pane, "-T", PREVIEW_PANE_TITLE)
            _tmux_attached = True
            return True
        session = "banana-preview"
        if _run("has-session", "-t", session):
            if find_preview_pane():
                _tmux_attached = True
                return True
            window = _run("list-windows", "-t", session, "-F", "#{window_id}")
            first = window.splitlines()[0] if window else ""
            if not first:
                return False
            pane = _split_pane(f"{first}.0")
            _run("select-pane", "-t", pane or f"{first}.1", "-T", PREVIEW_PANE_TITLE)
            _tmux_attached = bool(pane)
            return _tmux_attached
        _run("new-session", "-d", "-s", session, "bash", "-lc", "sleep infinity")
        window = _run("list-windows", "-t", session, "-F", "#{window_id}")
        first = window.splitlines()[0] if window else ""
        if not first:
            return False
        pane = _split_pane(f"{first}.0")
        _run("select-pane", "-t", pane or f"{first}.1", "-T", PREVIEW_PANE_TITLE)
        _tmux_attached = bool(pane)
        return _tmux_attached
    except (OSError, subprocess.SubprocessError):
        return False


def detach_pane() -> bool:
    global _tmux_attached
    if not _tmux_attached or not tmux_available():
        _tmux_attached = False
        return False
    killed = False
    try:
        pane = find_preview_pane()
        if pane:
            _run("kill-pane", "-t", pane)
            killed = True
        if not os.environ.get("TMUX") and _run("has-session", "-t", "banana-preview"):
            _run("kill-session", "-t", "banana-preview")
    except (OSError, subprocess.SubprocessError):
        pass
    _tmux_attached = False
    return killed


def clear() -> None:
    if _path is not None:
        try:
            _path.write_text("", encoding="utf-8")
        except OSError:
            pass
    _display_lines.clear()
    if _listener is not None:
        try:
            _listener("")
        except Exception:
            pass
