models/ - yerel GGUF klasoru

Bu klasordeki .gguf dosyalari bilerek git disinda tutulur (bkz. .gitignore);
boylece repoya buysuk model dosyasi gonderilmez. Buraya indirdigin her sey
yalnizca senin makinende kalir.

Nasil model koyulur:

  /model indir                 # banana icinden HuggingFace listesinden sec
  /model indir https://huggingface.co/.../model.gguf
  ya da dosyayi elinle bu klasore surukle

Secim komutu:

  /model local                 # bu klasordeki GGUF'lari listeler

Onerilen quant: Q4_K_M (yaklasik 1-2.5 GB). Cok dusuk RAM icin Q2_K.
Yerel modeller yalnizca sohbet modunda calisir; dosya ve kabuk araclari kapali.

Bu klasordeki tek takip edilen dosya budur (README.txt).
