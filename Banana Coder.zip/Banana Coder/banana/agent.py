from __future__ import annotations

import json
import platform
import re
import time
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from banana.approval import Approver
from banana.booster import upgrade_prompt
from banana.config import Config
from banana.models import (
    Message,
    StreamDone,
    TextDelta,
    ThinkingDelta,
    ToolCall,
    Usage,
)
from banana.net import ProviderError
from banana import preview
from banana.providers.base import Provider
from banana.session import Session
from banana.tools import ToolContext, execute_tool, tool_specs
from banana.tools.common import ToolResult
from banana.ui import UI

_TERMINATION_REASONS = {"length", "max_tokens", "MAX_TOKENS"}

_URL_RE = re.compile(r"https?://[\x21-\x7e]+")


def _urls_in(text: str) -> list[str]:
    seen: list[str] = []
    for match in _URL_RE.finditer(text or ""):
        url = match.group(0).rstrip(".,;:'\"` ")
        if url not in seen:
            seen.append(url)
    return seen[:5]


@dataclass
class TurnResult:
    text: str
    usage: Usage
    elapsed: float
    stop_reason: str | None = None
    tool_rounds: int = 0


def _read_project_instructions(cwd: Path) -> str:
    for name in ("BANANA.md", "AGENTS.md"):
        path = cwd / name
        try:
            if path.is_file():
                text = path.read_text(encoding="utf-8", errors="replace")
                if len(text) > 20_000:
                    text = text[:20_000] + "\n... [proje talimatlari kisaltildi]"
                return text
        except OSError:
            continue
    return ""


def build_system_prompt(cwd: Path) -> str:
    instructions = _read_project_instructions(cwd)
    prompt = f"""You are Banana Coder, an expert software engineering agent working in a terminal.

Environment:
- Working directory: {cwd}
- Platform: {platform.system()} {platform.release()} ({platform.machine()})
- Date: {date.today().isoformat()}
- The user has granted full filesystem access. Paths may be absolute or outside the working directory.
- Shell commands start in the working directory unless a cwd argument is given.

Available tools:
- read_file: read text files with line numbers.
- write_file: create or fully overwrite a file.
- edit_file: exact-string replacement in an existing file.
- list_dir: list a directory.
- glob: find files by pattern.
- grep: search file contents by regex.
- bash: run a non-interactive shell command.
- web_fetch: fetch a public http(s) URL and get its content as plain text.

Working rules:
- Inspect the relevant files before changing anything. Never invent file contents or command output.
- Make focused changes. Do not refactor or reformat unrelated code.
- Prefer edit_file for targeted changes and write_file for new files or full rewrites.
- Verify your work by running tests, type checks, or the project's own commands when practical.
- Never claim that a command or test passed unless you actually ran it and saw the result.
- Mutating tools and bash may require user approval. If approval is denied, stop and propose an alternative.
- Do not reveal secrets found in files. Apart from the configured model provider, the only other network access is the read-only web_fetch tool; never post user data to third-party services.
- When finished, respond concisely: what changed, which files, and how it was verified. Use the user's language.
"""
    if instructions:
        prompt += (
            "\n<project_instructions>\n"
            f"{instructions}\n"
            "</project_instructions>\n"
        )
    return prompt


def _summarize_args(call: ToolCall) -> str:
    parts: list[str] = []
    for key in ("path", "url", "command", "pattern", "glob", "cwd", "offset"):
        if key in call.arguments:
            value = call.arguments[key]
            if isinstance(value, (str, int, float, bool)):
                text = str(value).replace("\n", " ").strip()
                if len(text) > 90:
                    text = text[:90] + "..."
                parts.append(f"{key}={text}")
    if not parts and call.arguments:
        try:
            text = json.dumps(call.arguments, ensure_ascii=False)
        except (TypeError, ValueError):
            text = str(call.arguments)
        parts.append(text[:120])
    return " ".join(parts)


def trim_messages(
    messages: list[Message], max_chars: int
) -> tuple[list[Message], bool]:
    total = sum(message.approx_chars() for message in messages)
    if total <= max_chars:
        return messages, False

    start: int | None = None
    running = 0
    for index in range(len(messages) - 1, -1, -1):
        running += messages[index].approx_chars()
        if messages[index].role == "user":
            if running <= max_chars:
                start = index
            elif start is None:
                start = index
            break
    if start is None:
        start = len(messages) - 1
    return messages[start:], start > 0


class Agent:
    def __init__(
        self,
        *,
        provider: Provider,
        provider_name: str,
        model: str,
        config: Config,
        ui: UI,
        approver: Approver,
        session: Session,
        cwd: Path,
        persist: bool = True,
    ) -> None:
        self.provider = provider
        self.provider_name = provider_name
        self.model = model
        self.config = config
        self.ui = ui
        self.approver = approver
        self.session = session
        self.cwd = cwd
        self.persist = persist
        self.ctx = ToolContext(
            cwd=cwd,
            approver=approver,
            output_limit=config.tool_output_limit,
            ui=ui,
        )
        self._trim_warned = False

    def set_cwd(self, cwd: Path) -> None:
        self.cwd = cwd
        self.ctx.cwd = cwd

    def switch_model(self, provider: Provider, provider_name: str, model: str) -> None:
        self.provider = provider
        self.provider_name = provider_name
        self.model = model
        self.session.provider = provider_name
        self.session.model = model
        if self.persist:
            self.session.save()

    def _save(self) -> None:
        if self.persist:
            self.session.save()

    def _pv(self, kind: str, text: str) -> None:
        preview.publish(kind, text, self.ui)

    def _record_partial(self, partial_text: list[str]) -> None:
        content = "".join(partial_text).strip()
        if content:
            self.session.messages.append(
                Message(role="assistant", content=content)
            )
        self._save()

    def _execute_call(self, call: ToolCall) -> ToolResult:
        if call.parse_error:
            message = f"Arac argumanlari okunamadi: {call.parse_error}"
            return ToolResult(f"Hata: {message}", is_error=True, summary=message)
        spec = next((item for item in tool_specs() if item.name == call.name), None)
        if spec is None:
            message = f"Bilinmeyen arac: {call.name}"
            return ToolResult(f"Hata: {message}", is_error=True, summary=message)
        return execute_tool(call.name, call.arguments, self.ctx)

    def run_turn(self, user_text: str) -> TurnResult:
        started = time.monotonic()
        self._trim_warned = False
        original = user_text
        if self.config.boost_enabled and user_text.strip():
            self.ui.info("Prompt upgrade ediliyor...")
            user_text = upgrade_prompt(self.config, user_text)
            if user_text != original:
                self.ui.boost_preview(original, user_text)
                self._pv("boost", f"{self.config.boost_model} -> {user_text[:160]}")
        self.session.messages.append(Message(role="user", content=user_text))
        turn_usage = Usage()
        tool_rounds = 0
        last_text = ""
        last_stop: str | None = None

        for step in range(self.config.max_tool_rounds + 1):
            messages, trimmed = trim_messages(
                self.session.messages, self.config.max_context_chars
            )
            if trimmed and not self._trim_warned:
                self.ui.info(
                    "Baglam siniri asildigi icin konusmanin eski kismi atlandi."
                )
                self._trim_warned = True

            system = build_system_prompt(self.ctx.cwd)
            self.ui.assistant_start()
            status = self.ui.status("yanit bekleniyor...")
            status.start()
            status_active = True
            done: StreamDone | None = None
            partial_text: list[str] = []
            call_started = time.monotonic()

            try:
                for event in self.provider.stream(
                    model=self.model,
                    system=system,
                    messages=messages,
                    tools=tool_specs(),
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature,
                ):
                    if status_active:
                        status.stop()
                        status_active = False
                    if isinstance(event, TextDelta):
                        partial_text.append(event.text)
                        self.ui.stream_text(event.text)
                    elif isinstance(event, ThinkingDelta):
                        self.ui.stream_thinking(event.text)
                    elif isinstance(event, StreamDone):
                        done = event
            except KeyboardInterrupt:
                self.ui.break_thinking()
                self.ui.assistant_end()
                self._record_partial(partial_text)
                raise
            except ProviderError:
                self.ui.break_thinking()
                self.ui.assistant_end()
                self._record_partial(partial_text)
                raise
            finally:
                if status_active:
                    status.stop()

            self.ui.break_thinking()
            self.ui.assistant_end()
            if done is None:
                raise ProviderError(
                    f"{self.provider.label}: yanit tamamlanmadan akis kesildi."
                )

            call_elapsed = time.monotonic() - call_started
            turn_usage.add(done.usage)
            self.session.usage.add(done.usage)
            last_stop = done.stop_reason
            last_text = done.message.content
            self.ui.usage(
                done.usage.input_tokens,
                done.usage.output_tokens,
                call_elapsed,
                done.usage.cost,
            )

            if done.stop_reason in _TERMINATION_REASONS:
                self.ui.warn(
                    "Model cikti sinirina (max_tokens) takildi; yanit eksik olabilir."
                )

            self.session.messages.append(done.message)
            self._save()

            if not done.message.tool_calls:
                elapsed = time.monotonic() - started
                return TurnResult(
                    text=done.message.content,
                    usage=turn_usage,
                    elapsed=elapsed,
                    stop_reason=last_stop,
                    tool_rounds=tool_rounds,
                )

            for call in done.message.tool_calls:
                summary = _summarize_args(call)
                self.ui.tool_call(call.name, summary)
                self._pv("call", f"{call.name} {summary}".strip())
                for url in _urls_in(summary):
                    self._pv("url", f"{call.name} -> {url}")
                try:
                    result = self._execute_call(call)
                except KeyboardInterrupt:
                    self.ui.warn("Arac calistirilirken durduruldu.")
                    self._save()
                    raise
                display = result.summary or (
                    result.content.splitlines()[0][:120] if result.content else ""
                )
                self.ui.tool_result(not result.is_error, display)
                self._pv(
                    "done" if not result.is_error else "error",
                    f"{call.name}: {display}",
                )
                self.session.messages.append(
                    Message(
                        role="tool",
                        content=result.content,
                        tool_call_id=call.id,
                        tool_name=call.name,
                        is_error=result.is_error,
                    )
                )
                tool_rounds += 1
            self._save()

            if step >= self.config.max_tool_rounds:
                self.ui.warn(
                    f"Maksimum arac turu ({self.config.max_tool_rounds}) asildi. "
                    "Devam etmek icin yeni bir mesaj yaz."
                )
                break

        elapsed = time.monotonic() - started
        self._save()
        return TurnResult(
            text=last_text,
            usage=turn_usage,
            elapsed=elapsed,
            stop_reason=last_stop,
            tool_rounds=tool_rounds,
        )
