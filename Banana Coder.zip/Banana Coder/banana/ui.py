from __future__ import annotations

import difflib
import getpass
import sys
from typing import Iterable, Sequence

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from banana import preview as _preview

BANANA = "#f5c542"

BANNER_ART = "\n".join(
    line.rstrip()
    for line in """
████   ███  █   █  ███  █   █  ███      ███   ███  ████  ████  █████ ████
█   █ █   █ ██  █ █   █ ██  █ █   █    █     █   █ █   █ █   █ █     █   █
████  █████ █ █ █ █████ █ █ █ █████    █     █   █ █   █ █   █ ████  ████
█   █ █   █ █  ██ █   █ █  ██ █   █    █     █   █ █   █ █   █ █     █  █
████  █   █ █   █ █   █ █   █ █   █     ███   ███  ████  ████  █████ █   █
""".strip(
        "\n"
    ).splitlines()
)


class UI:
    def __init__(
        self,
        *,
        color: bool = True,
        show_reasoning: bool = False,
        one_shot: bool = False,
        stream_output: bool = True,
    ) -> None:
        self.console = Console(
            no_color=not color, highlight=False, emoji=False, soft_wrap=False
        )
        self.err_console = Console(
            stderr=True, no_color=not color, highlight=False, emoji=False
        )
        self.show_reasoning = show_reasoning
        self.one_shot = one_shot
        self.stream_output = stream_output
        self.interactive = sys.stdin.isatty() and sys.stdout.isatty()
        self._at_line_start = True
        self._wrote_text = False
        self._thinking_open = False

    def banner(
        self,
        version: str,
        model: str,
        provider_label: str,
        cwd: str,
        approval: str,
        session_note: str | None = None,
    ) -> None:
        art = Text(BANNER_ART, style=f"bold {BANANA}")
        self.console.print(Align.center(art))
        self.console.print(
            Align.center(Text(f"v{version}", style="dim italic"))
        )
        self.console.print(Rule(style=BANANA))

        info_lines = [
            Text.assemble(
                ("model ", "dim"), (model, "bold white"), ("  ", ""),
                ("saglayici ", "dim"), (provider_label, "cyan"),
            ),
            Text.assemble(
                ("dizin ", "dim"), (cwd, ""), ("  ", ""),
                ("izin ", "dim"), (approval, "magenta"),
            ),
        ]
        if session_note:
            info_lines.append(Text(session_note, style="dim"))
        info = Text("\n").join(info_lines)
        self.console.print(Panel(info, border_style=BANANA, padding=(0, 2)))
        self.console.print(
            Align.center(
                Text("/help yazarak komutlari, /quit ile cikisi gorebilirsin.", style="dim")
            )
        )
        self.console.print()

    def _status_console(self) -> Console:
        return self.err_console if self.one_shot else self.console

    def info(self, message: str) -> None:
        self._status_console().print(Text(message, style="dim"))

    def warn(self, message: str) -> None:
        self._status_console().print(
            Text("> UYARI ", style="bold yellow") + Text(message)
        )

    def error(self, message: str) -> None:
        self.err_console.print(Text("> HATA ", style="bold red") + Text(message))

    def note(self, message: str) -> None:
        self._status_console().print(Text(message, style="italic dim"))

    def boost_preview(self, original: str, upgraded: str) -> None:
        if self.one_shot:
            return
        body = Text.assemble(
            ("Gonderilen prompt:\n", f"bold {BANANA}"),
            (upgraded, ""),
        )
        self.console.print(Panel(body, title="prompt upgrade edildi", border_style=BANANA))

    def preview_line(self, line: str) -> None:
        if not _preview.should_print_inline():
            return
        self.console.print(Text("PV " + line, style="dim cyan"))

    def assistant_start(self) -> None:
        if self.one_shot:
            return
        self.console.print()
        self.console.print(
            Text.assemble(
                ("● ", f"bold {BANANA}"),
                ("banana", f"bold {BANANA}"),
                (" ", ""),
                ("─" * 40, "dim"),
            )
        )

    def assistant_end(self) -> None:
        if self._thinking_open:
            sys.stdout.write("\n")
            self._thinking_open = False
        if not self.one_shot:
            self.console.print(Text("─" * 44, style="dim"))
            self.console.print()

    def finish_output(self) -> None:
        self.break_thinking()
        if self.one_shot and self._wrote_text and not self._at_line_start:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._at_line_start = True

    def stream_text(self, text: str) -> None:
        if not self.stream_output:
            return
        sys.stdout.write(text)
        sys.stdout.flush()
        self._wrote_text = True
        self._at_line_start = text.endswith("\n")

    def stream_thinking(self, text: str) -> None:
        if not self.show_reasoning or not self.stream_output:
            return
        if not self._thinking_open:
            sys.stdout.write("\n[ reasoning ] ")
            self._thinking_open = True
        sys.stdout.write(text)
        sys.stdout.flush()

    def break_thinking(self) -> None:
        if self._thinking_open:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._thinking_open = False

    def tool_call(self, name: str, summary: str) -> None:
        stream = self.err_console if self.one_shot else self.console
        line = Text("  → ", style="dim")
        line.append(name, style="bold cyan")
        if summary:
            line.append(" ")
            line.append(summary, style="dim")
        stream.print(line)

    def tool_result(self, ok: bool, summary: str) -> None:
        stream = self.err_console if self.one_shot else self.console
        line = Text("  ")
        if ok:
            line.append("✓ ", style="bold green")
        else:
            line.append("✗ ", style="bold red")
        line.append(summary, style="dim")
        stream.print(line)

    def usage(
        self,
        input_tokens: int,
        output_tokens: int,
        elapsed: float,
        cost: float | None = None,
    ) -> None:
        if self.one_shot:
            return
        parts = [f"{input_tokens} in", f"{output_tokens} out", f"{elapsed:.1f}s"]
        if cost is not None:
            parts.append(f"${cost:.4f}")
        self.console.print(
            Text("  " + " / ".join(parts), style="dim italic")
        )

    def status(self, message: str):
        if not self.interactive:
            return _NullStatus()
        return self.console.status(Text(message, style="dim"), spinner="dots")

    def ask_approval(self, prompt: str) -> str:
        try:
            answer = self.console.input(
                Text(prompt, style="bold"), markup=False, emoji=False
            )
        except (EOFError, KeyboardInterrupt):
            self.console.print()
            return "no"
        answer = answer.strip().lower()
        if answer in ("e", "evet", "y", "yes"):
            return "yes"
        if answer in ("t", "tumu", "tum", "a", "all"):
            return "all"
        return "no"

    def ask_line(self, prompt: str, default: str = "") -> str:
        try:
            text = self.console.input(
                Text(prompt, style="bold"), markup=False, emoji=False
            )
        except (EOFError, KeyboardInterrupt):
            self.console.print()
            return default
        return text.strip()

    def ask_secret(self, prompt: str) -> str:
        try:
            self.console.print(Text(prompt, style="bold"), end="")
            secret = getpass.getpass("")
        except (EOFError, KeyboardInterrupt):
            self.console.print()
            return ""
        return secret.strip()

    def prompt(self, text: str) -> str:
        return self.console.input(
            Text(text, style=f"bold {BANANA}"), markup=False, emoji=False
        )

    def ask_choice(
        self, prompt: str, choices: Sequence[str], default: str = ""
    ) -> str:
        self.console.print(Text(prompt, style="bold"))
        for index, choice in enumerate(choices, start=1):
            self.console.print(Text(f"  {index}. {choice}"))
        try:
            answer = self.console.input(
                Text("Secim: ", style="bold"), markup=False, emoji=False
            )
        except (EOFError, KeyboardInterrupt):
            self.console.print()
            return default
        answer = answer.strip()
        if answer.isdigit():
            idx = int(answer) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        for choice in choices:
            if answer.lower() == choice.lower():
                return choice
        return default

    def table(self, headers: Sequence[str], rows: Iterable[Sequence[str]]) -> None:
        table = Table(show_header=True, header_style="bold")
        for header in headers:
            table.add_column(Text(str(header)))
        for row in rows:
            table.add_row(*[Text(str(cell)) for cell in row])
        self.console.print(table)

    def final(self, text: str) -> None:
        if not text:
            return
        if self.one_shot:
            sys.stdout.write(text)
            if not text.endswith("\n"):
                sys.stdout.write("\n")
            sys.stdout.flush()
        else:
            self.console.print(Panel(Text(text), border_style=BANANA, padding=(0, 1)))

    def print(self, renderable) -> None:
        self.console.print(renderable)


class _NullStatus:
    def start(self) -> None:
        return None

    def stop(self) -> None:
        return None

    def __enter__(self):
        return self

    def __exit__(self, *_exc) -> None:
        return None


def render_diff(
    path: str,
    old: str | None,
    new: str,
    *,
    max_lines: int = 240,
    context: int = 3,
) -> Text:
    old_lines = (old or "").splitlines()
    new_lines = new.splitlines()
    diff = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{path}" if old is not None else "/dev/null",
            tofile=f"b/{path}",
            lineterm="",
            n=context,
        )
    )
    text = Text()
    text.append(("Duzenle: " if old is not None else "Olustur: ") + path + "\n", style="bold")
    if not diff:
        text.append("(degisiklik yok)\n", style="dim")
        return text
    shown = 0
    for line in diff:
        if shown >= max_lines:
            text.append(f"... (diff {len(diff) - max_lines} satir daha)\n", style="dim yellow")
            break
        display = line if len(line) <= 500 else line[:500] + " ..."
        if line.startswith("+++") or line.startswith("---"):
            style = "bold"
        elif line.startswith("@@"):
            style = "cyan"
        elif line.startswith("+"):
            style = "green"
        elif line.startswith("-"):
            style = "red"
        else:
            style = "dim"
        text.append(display + "\n", style=style)
        shown += 1
    return text
