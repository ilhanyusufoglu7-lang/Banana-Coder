from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

APP_HOME = Path(os.environ.get("BANANA_HOME", str(Path.home() / ".banana"))).expanduser()
CONFIG_PATH = APP_HOME / "config.json"
SESSIONS_DIR = APP_HOME / "sessions"
HISTORY_PATH = APP_HOME / "history"

PROVIDERS = ("openrouter", "anthropic", "openai", "gemini", "local")

PROVIDER_LABELS = {
    "openrouter": "OpenRouter",
    "anthropic": "Anthropic",
    "openai": "OpenAI",
    "gemini": "Google Gemini",
    "local": "Yerel (GGUF)",
}

KEY_ENV = {
    "openrouter": ("OPENROUTER_API_KEY",),
    "anthropic": ("ANTHROPIC_API_KEY",),
    "openai": ("OPENAI_API_KEY",),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "local": (),
}

DEFAULT_MODELS = {
    "openrouter": "openrouter/openrouter/free",
    "anthropic": "claude-sonnet-5-5",
    "openai": "gpt-6.1-terra",
    "gemini": "gemini-4-argon",
    "local": "local",
}

BASE_URLS = {
    "openrouter": "https://openrouter.ai/api/v1",
    "anthropic": "https://api.anthropic.com",
    "openai": "https://api.openai.com/v1",
    "gemini": "https://generativelanguage.googleapis.com/v1beta",
    "local": "",
}

BASE_URL_ENV = {
    "openrouter": "OPENROUTER_BASE_URL",
    "anthropic": "ANTHROPIC_BASE_URL",
    "openai": "OPENAI_BASE_URL",
    "gemini": "GEMINI_BASE_URL",
    "local": "BANANA_LOCAL_MODEL",
}

DEFAULT_CONFIG = {
    "model": None,
    "approval": "ask",
    "max_tokens": 8192,
    "temperature": None,
    "max_context_chars": 320_000,
    "request_timeout": 600,
    "tool_output_limit": 30_000,
    "max_tool_rounds": 40,
    "show_reasoning": False,
    "voice_enabled": False,
    "voice_name": "gareth",
    "boost_enabled": False,
    "boost_model": "or-free",
    "preview_enabled": False,
    "preview_pane_percent": 45,
    "base_urls": {},
    "api_keys": {},
    "local_model_path": None,
}


def _parse_dotenv(path: Path) -> None:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value[:1] == value[-1:] and value[:1] in ("'", '"') and len(value) >= 2:
            value = value[1:-1]
        if key and key not in os.environ:
            os.environ[key] = value


def bootstrap_env(cwd: Path | None = None) -> None:
    if cwd is not None:
        _parse_dotenv(cwd / ".env")
    _parse_dotenv(APP_HOME / ".env")


def mask_key(key: str | None) -> str:
    if not key:
        return "-"
    if len(key) <= 12:
        return key[:3] + "***"
    return f"{key[:6]}...{key[-4:]}"


def _as_int(value, fallback: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(value))
    except (TypeError, ValueError):
        return fallback


def _as_float(value, fallback: float | None) -> float | None:
    if value is None or value == "":
        return fallback
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _as_bool(value, fallback: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on", "evet")
    return fallback


@dataclass
class Config:
    model: str | None = None
    approval: str = "ask"
    max_tokens: int = 8192
    temperature: float | None = None
    max_context_chars: int = 320_000
    request_timeout: float = 600
    tool_output_limit: int = 30_000
    max_tool_rounds: int = 40
    show_reasoning: bool = False
    voice_enabled: bool = False
    voice_name: str = "gareth"
    boost_enabled: bool = False
    boost_model: str = "or-free"
    preview_enabled: bool = False
    preview_pane_percent: int = 45
    base_urls: dict[str, str] = field(default_factory=dict)
    api_keys: dict[str, str] = field(default_factory=dict)
    local_model_path: str | None = None
    config_path: Path = field(default=CONFIG_PATH, repr=False, compare=False)

    @classmethod
    def load(cls, path: Path | None = None) -> "Config":
        path = path or CONFIG_PATH
        raw: dict = {}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            pass
        except (OSError, json.JSONDecodeError):
            pass
        if not isinstance(raw, dict):
            raw = {}

        approval = str(raw.get("approval", DEFAULT_CONFIG["approval"])).lower()
        if approval not in ("ask", "yolo", "readonly"):
            approval = "ask"

        base_urls = raw.get("base_urls")
        if not isinstance(base_urls, dict):
            base_urls = {}
        base_urls = {
            str(k): str(v)
            for k, v in base_urls.items()
            if k in PROVIDERS and isinstance(v, str) and v.strip()
        }

        api_keys = raw.get("api_keys")
        if not isinstance(api_keys, dict):
            api_keys = {}
        api_keys = {
            str(k): str(v)
            for k, v in api_keys.items()
            if k in PROVIDERS and isinstance(v, str) and v.strip()
        }

        return cls(
            model=raw.get("model") or None,
            approval=approval,
            max_tokens=_as_int(raw.get("max_tokens"), 8192),
            temperature=_as_float(raw.get("temperature"), None),
            max_context_chars=_as_int(raw.get("max_context_chars"), 320_000, 20_000),
            request_timeout=float(_as_int(raw.get("request_timeout"), 600, 30)),
            tool_output_limit=_as_int(raw.get("tool_output_limit"), 30_000, 2_000),
            max_tool_rounds=_as_int(raw.get("max_tool_rounds"), 40, 1),
            show_reasoning=_as_bool(raw.get("show_reasoning"), False),
            voice_enabled=_as_bool(raw.get("voice_enabled"), False),
            voice_name=str(raw.get("voice_name") or "gareth").strip() or "gareth",
            boost_enabled=_as_bool(raw.get("boost_enabled"), False),
            boost_model=str(raw.get("boost_model") or "or-free").strip() or "or-free",
            preview_enabled=_as_bool(raw.get("preview_enabled"), False),
            preview_pane_percent=_as_int(raw.get("preview_pane_percent"), 45, minimum=20),
            base_urls=base_urls,
            api_keys=api_keys,
            local_model_path=raw.get("local_model_path") or None,
            config_path=path,
        )

    def save(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "model": self.model,
            "approval": self.approval,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "max_context_chars": self.max_context_chars,
            "request_timeout": self.request_timeout,
            "tool_output_limit": self.tool_output_limit,
            "max_tool_rounds": self.max_tool_rounds,
            "show_reasoning": self.show_reasoning,
            "voice_enabled": self.voice_enabled,
            "voice_name": self.voice_name,
            "boost_enabled": self.boost_enabled,
            "boost_model": self.boost_model,
            "preview_enabled": self.preview_enabled,
            "preview_pane_percent": self.preview_pane_percent,
            "base_urls": self.base_urls,
            "api_keys": self.api_keys,
            "local_model_path": self.local_model_path,
        }
        fd, tmp = tempfile.mkstemp(
            dir=str(self.config_path.parent), prefix=".config-", suffix=".json"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            os.replace(tmp, self.config_path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def api_key(self, provider: str) -> str | None:
        for name in KEY_ENV.get(provider, ()):
            value = os.environ.get(name, "").strip()
            if value:
                return value
        return self.api_keys.get(provider, "").strip() or None

    def set_api_key(self, provider: str, key: str) -> None:
        provider = provider.lower()
        if provider not in PROVIDERS:
            raise ValueError(f"Bilinmeyen saglayici: {provider}")
        key = key.strip()
        if key:
            self.api_keys[provider] = key
        else:
            self.api_keys.pop(provider, None)

    def has_any_key(self) -> bool:
        return any(self.api_key(p) for p in PROVIDERS)

    def base_url(self, provider: str) -> str:
        env_name = BASE_URL_ENV.get(provider)
        if env_name:
            value = os.environ.get(env_name, "").strip()
            if value:
                return value
        return self.base_urls.get(provider) or BASE_URLS[provider]

    def available_providers(self) -> list[str]:
        return [p for p in PROVIDERS if self.api_key(p)]

    def default_model(self) -> str | None:
        if self.model:
            return self.model
        for provider in ("openrouter", "anthropic", "openai", "gemini"):
            if self.api_key(provider):
                return f"{provider}/{DEFAULT_MODELS[provider]}"
        return None

    def ensure_dirs(self) -> None:
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
