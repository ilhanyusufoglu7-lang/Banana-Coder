from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.text import Text

from banana import __version__
from banana import preview
from banana.agent import Agent
from banana.approval import Approver
from banana.config import (
    APP_HOME,
    CONFIG_PATH,
    DEFAULT_MODELS,
    KEY_ENV,
    PROVIDER_LABELS,
    PROVIDERS,
    SESSIONS_DIR,
    Config,
    bootstrap_env,
    mask_key,
)
from banana.models import Message, MODEL_PRESETS, parse_model
from banana.net import ProviderError, fetch_openrouter_models
from banana.hf import GGUF_OFFERS, download_gguf, offer_url
from banana.providers import MissingKeyError, create_provider, local_model_path
from banana.providers.base import Provider
from banana.session import Session
from banana.tools.shell import run_command
from banana.tts import TTS_MODEL, TTS_URL, TTS_VOICES, play, synthesize
from banana.ui import UI

FILE_REF = re.compile(r"(?<!\S)@([^\s]+)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="banana",
        description=(
            "Banana Coder: OpenRouter, Anthropic, OpenAI ve Gemini modelleriyle "
            "calisan terminal kodlama ajani."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Ornekler:\n"
            "  banana                          etkilesimli oturum baslat\n"
            "  banana -m or-claude             OpenRouter uzerinden Claude ile baslat\n"
            "  banana -p 'hatayi duzelt'       tek seferlik calistir\n"
            "  banana -p 'testleri calistir' --yolo\n"
            "  banana test                     yapilandirilmis saglayicilari test et\n"
            "  banana models --remote          OpenRouter model listesini getir\n"
            "  banana config --init            varsayilan ayar dosyasini olustur\n"
            "\nModel secenekleri: "
            + ", ".join(sorted(MODEL_PRESETS))
        ),
    )
    parser.add_argument(
        "--version", action="version", version=f"Banana Coder {__version__}"
    )
    parser.add_argument(
        "-p", "--prompt", help="Etkilesimli moda girmeden tek bir gorev calistir."
    )
    parser.add_argument(
        "-m",
        "--model",
        help=(
            "Model veya hazir kisayol. Ornek: or-claude, claude, gpt, gemini, "
            "openrouter/qwen/qwen3-coder"
        ),
    )
    parser.add_argument(
        "-C", "--dir", dest="workdir", help="Calisma dizini (varsayilan: mevcut dizin)."
    )
    approval = parser.add_mutually_exclusive_group()
    approval.add_argument(
        "--yolo",
        dest="approval",
        action="store_const",
        const="yolo",
        help="Dosya degisikliklerini ve komutlari onaysiz calistir.",
    )
    approval.add_argument(
        "--read-only",
        dest="approval",
        action="store_const",
        const="readonly",
        help="Yalnizca okuma araclarini kullan.",
    )
    approval.add_argument(
        "--ask",
        dest="approval",
        action="store_const",
        const="ask",
        help="Degisiklikler icin onay iste (varsayilan).",
    )
    parser.add_argument(
        "-c",
        "--continue",
        dest="continue_",
        action="store_true",
        help="Bu dizindeki en son oturumu devam ettir.",
    )
    parser.add_argument(
        "--new", action="store_true", help="Yeni oturum baslat (devam ettirme)."
    )
    parser.add_argument(
        "--session", metavar="AD", help="Belirli bir isimle oturum kullan."
    )
    parser.add_argument(
        "--max-tokens", type=int, help="Yanit basina maksimum cikti token sayisi."
    )
    parser.add_argument(
        "--temperature", type=float, help="Model sicakligi (0-2)."
    )
    parser.add_argument(
        "--show-reasoning",
        action="store_true",
        help="Modelin dusunme/reasoning akisini goster.",
    )
    parser.add_argument("--no-color", action="store_true", help="Renkleri kapat.")
    parser.add_argument(
        "--json",
        action="store_true",
        help="Tek seferlik modda sonucu JSON olarak yaz (yalnizca -p ile).",
    )

    subparsers = parser.add_subparsers(dest="command")

    test_parser = subparsers.add_parser(
        "test", help="Yapilandirilmis saglayicilarda baglanti testi yap."
    )
    test_parser.add_argument(
        "providers",
        nargs="*",
        help="Test edilecek saglayicilar: openrouter anthropic openai gemini",
    )

    models_parser = subparsers.add_parser(
        "models", help="Hazir model kisayollarini veya OpenRouter modellerini listele."
    )
    models_parser.add_argument(
        "--remote",
        action="store_true",
        help="OpenRouter'in canli model listesini getir.",
    )
    models_parser.add_argument(
        "--free",
        action="store_true",
        help="Yalnizca ucretsiz OpenRouter modellerini listele.",
    )
    models_parser.add_argument(
        "--limit", type=int, default=100, help="Uzak listede en fazla model (varsayilan 100)."
    )

    config_parser = subparsers.add_parser(
        "config", help="Yapilandirmayi ve API anahtari durumunu goster."
    )
    config_parser.add_argument(
        "--init", action="store_true", help="Varsayilan yapilandirma dosyasini olustur."
    )
    config_parser.add_argument(
        "--force", action="store_true", help="--init ile mevcut dosyanin uzerine yaz."
    )
    return parser


@dataclass
class Runtime:
    config: Config
    ui: UI
    approver: Approver
    session: Session
    provider: Provider
    provider_name: str
    model: str
    agent: Agent
    persist: bool


def _color_enabled(no_color: bool) -> bool:
    return not no_color and not os.environ.get("NO_COLOR")


PROJECT_DIR = Path(__file__).resolve().parent.parent
LOCAL_MODELS_DIR = PROJECT_DIR / "models"

GGUF_DIRS = (LOCAL_MODELS_DIR, PROJECT_DIR, APP_HOME / "models", Path.home() / "models")


def _format_size(path: Path) -> str:
    try:
        size = path.stat().st_size
    except OSError:
        return "?"
    return f"{size / (1024 ** 3):.1f} GB"


def _find_gguf_files() -> list[Path]:
    found: list[Path] = []
    seen: set[str] = set()
    for directory in GGUF_DIRS:
        if not directory.is_dir():
            continue
        if directory == PROJECT_DIR:
            candidates = directory.glob("*")
        else:
            candidates = directory.rglob("*")
        for path in sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True):
            if not path.is_file():
                continue
            if path.suffix.lower() != ".gguf":
                continue
            key = str(path)
            if key not in seen:
                seen.add(key)
                found.append(path)
            if len(found) >= 50:
                return found
    return found


def _model_choices() -> list[tuple[str, str]]:
    choices = [(f"{alias} -> {spec}", alias) for alias, spec in sorted(MODEL_PRESETS.items())]
    for path in _find_gguf_files():
        label = f"GGUF {path.name} ({_format_size(path)})"
        choices.append((f"{label} -> local/{path}", f"local/{path}"))
    return choices


def _download_gguf(runtime: Runtime, url: str) -> None:
    ui = runtime.ui
    name = url.rsplit("/", 1)[-1]
    ui.info(f"Indiriliyor: {name} -> {LOCAL_MODELS_DIR}")
    preview.publish("dl", f"GET {url}", ui)
    try:
        with Progress(
            SpinnerColumn(),
            BarColumn(bar_width=30),
            "[progress.percentage]{task.percentage:>3.0f}%",
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=ui.console,
        ) as progress:
            task = progress.add_task(name, total=None)

            def on_progress(done: int, total: int) -> None:
                progress.update(task, total=total or None, completed=done)

            dest = download_gguf(url, LOCAL_MODELS_DIR, on_progress)
    except KeyboardInterrupt:
        ui.warn("Indirme iptal edildi.")
        return
    except (ProviderError, OSError) as exc:
        ui.error(str(exc))
        return
    if dest.exists() and dest.stat().st_size == 0:
        ui.error("Indirme bos dosya uretti; URL'yi kontrol et.")
        return
    ui.info(f"Kaydedildi: {dest}")
    preview.publish("dl", f"kaydedildi {dest.name}", ui)
    try:
        _switch_model(runtime, f"local/{dest}")
    except ProviderError as exc:
        ui.error(str(exc))
        return
    ui.info(
        f"Yerel model aktif: {dest.name} "
        "(ilk istekte model diske yuklenir, biraz bekleyebilirsin)"
    )


def _model_download_flow(runtime: Runtime, rest: str) -> None:
    ui = runtime.ui
    rest = rest.strip()
    if not rest:
        rows = [
            (str(index), label, f"{size:.1f} GB", note)
            for index, (label, _repo, _file, size, note) in enumerate(GGUF_OFFERS, start=1)
        ]
        ui.table(["#", "Model", "Boyut", "Not"], rows)
        if not ui.interactive:
            ui.info("Indirmek icin: /model indir <no>  veya  /model indir <HF-URL>")
            return
        answer = ui.ask_choice(
            "Hangi modeli indirmek istiyorsun? (bos: iptal)",
            [f"{label} ({size:.1f} GB)" for label, _r, _f, size, _n in GGUF_OFFERS],
        )
        if not answer:
            return
        index = next(
            (
                i
                for i, (label, _r, _f, size, _n) in enumerate(GGUF_OFFERS)
                if answer == f"{label} ({size:.1f} GB)"
            ),
            None,
        )
        if index is None:
            return
        _download_gguf(runtime, offer_url(GGUF_OFFERS[index]))
        return
    if rest.startswith("http://") or rest.startswith("https://"):
        _download_gguf(runtime, rest)
        return
    if rest.isdigit():
        index = int(rest) - 1
        if 0 <= index < len(GGUF_OFFERS):
            _download_gguf(runtime, offer_url(GGUF_OFFERS[index]))
        else:
            ui.warn(f"Gecersiz secim. 1-{len(GGUF_OFFERS)} arasi bir numara ver.")
        return
    _download_gguf(runtime, rest)


def _model_label(provider_name: str, model: str) -> str:
    if provider_name == "local":
        return f"local/{Path(model).name if model else '?'}"
    return f"{provider_name}/{model}"


def _alias_for_model(provider_name: str, model: str) -> str | None:
    spec = f"{provider_name}/{model}"
    for alias, target in MODEL_PRESETS.items():
        if target == spec:
            return alias
    return None


def _prompt_text(runtime: Runtime) -> str:
    alias = _alias_for_model(runtime.provider_name, runtime.model)
    label = alias or runtime.provider_name
    return f"banana({label})> "


def _apply_overrides(config: Config, args: argparse.Namespace) -> None:
    if args.approval:
        config.approval = args.approval
    if args.max_tokens is not None:
        config.max_tokens = max(1, min(args.max_tokens, 200_000))
    if args.temperature is not None:
        config.temperature = max(0.0, min(args.temperature, 2.0))
    if args.show_reasoning:
        config.show_reasoning = True


def _print_setup_help(ui: UI) -> None:
    ui.console.print(Text("API anahtari gerekli", style="bold yellow"))
    ui.console.print(
        Text(
            "REPL icinde bir anahtar kaydet:\n"
            "  /api openai sk-...\n"
            "  /api claude sk-...\n\n"
            "Veya ortam degiskeni / .env kullan:\n"
            "  OPENROUTER_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY",
            style="",
        )
    )


def _key_source(config: Config, provider: str) -> str:
    for name in KEY_ENV.get(provider, ()):
        if os.environ.get(name, "").strip():
            return f"env:{name}"
    if config.api_keys.get(provider, "").strip():
        return "config.json"
    return "yok"


def _prompt_api_key(config: Config, ui: UI, provider: str) -> bool:
    label = PROVIDER_LABELS.get(provider, provider)
    ui.console.print(Text(f"{label} icin API anahtari gerekiyor.", style="bold yellow"))
    ui.console.print(
        Text(
            "Anahtar ~/.banana/config.json dosyasinda saklanacak. "
            "Bos birakmak veya Ctrl+C ile iptal etmek anahtari degistirmez.",
            style="dim",
        )
    )
    secret = ui.ask_secret(f"{label} API anahtari: ")
    if not secret:
        return False
    config.set_api_key(provider, secret)
    config.save()
    ui.info(f"{label} anahtari kaydedildi.")
    return True


def _prompt_default_model(config: Config, ui: UI) -> bool:
    ui.console.print(Text("Varsayilan model secilmemis.", style="bold yellow"))
    choices = _model_choices()
    answer = ui.ask_choice(
        "Hangi modeli kullanmak istiyorsun?", [c[0] for c in choices]
    )
    if not answer:
        return False
    index = next((i for i, c in enumerate(choices) if c[0] == answer), None)
    if index is None:
        return False
    spec = choices[index][1]
    if spec.startswith("local/"):
        config.local_model_path = spec[len("local/") :]
        spec = "local"
    config.model = spec
    config.save()
    ui.info(f"Varsayilan model: {spec}")
    return True


def _resolve_target(
    args: argparse.Namespace, config: Config, session: Session
) -> tuple[str, str]:
    if args.model:
        return parse_model(args.model)
    if session.provider in PROVIDERS and session.model:
        return session.provider, session.model
    spec = config.model or config.default_model()
    if not spec:
        raise MissingKeyError("API anahtari bulunamadi.")
    return parse_model(spec)


def _build_session(
    args: argparse.Namespace, workdir: Path
) -> tuple[Session, bool]:
    started_new = False
    if args.session:
        session = None if args.new else Session.load_named(args.session, workdir)
        if session is None:
            session = Session.create(workdir, "", "", name=args.session)
            started_new = True
    elif args.continue_:
        session = Session.load_latest(workdir)
        if session is None:
            session = Session.create(workdir, "", "")
            started_new = True
    else:
        session = Session.create(workdir, "", "")
        started_new = True
    return session, started_new


def _switch_model(runtime: Runtime, spec: str) -> None:
    provider_name, model = parse_model(spec, runtime.provider_name)
    if provider_name == "local":
        path = local_model_path(runtime.config, model)
        new_provider = create_provider(runtime.config, "local", model=path)
        runtime.config.local_model_path = str(path)
        runtime.config.model = "local"
        runtime.config.save()
    else:
        new_provider = create_provider(runtime.config, provider_name)
    old_provider = runtime.provider
    runtime.provider = new_provider
    runtime.provider_name = provider_name
    runtime.model = Path(model).name if provider_name == "local" else model
    runtime.agent.switch_model(new_provider, provider_name, model)
    try:
        old_provider.close()
    except Exception:
        pass


def _show_presets(ui: UI) -> None:
    rows = [(alias, spec) for alias, spec in sorted(MODEL_PRESETS.items())]
    ui.table(["Kisayol", "Yonlendirme"], rows)
    ui.info("Uzak OpenRouter listesi icin: /models remote")


def _format_context(value) -> str:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return "-"
    if number >= 1_000_000:
        return f"{number / 1_000_000:.1f}M"
    if number >= 1000:
        return f"{number / 1000:.0f}K"
    return str(number)


def _per_million(value) -> str:
    try:
        number = float(value) * 1_000_000
    except (TypeError, ValueError):
        return "-"
    if number == 0:
        return "0"
    if number < 0.01:
        return f"{number:.4f}"
    return f"{number:.2f}"


def _is_free_model(item: dict[str, Any]) -> bool:
    pricing = item.get("pricing") if isinstance(item.get("pricing"), dict) else {}
    try:
        prompt = float(pricing.get("prompt") or 0)
        completion = float(pricing.get("completion") or 0)
        return prompt == 0 and completion == 0
    except (TypeError, ValueError):
        return False


def _show_remote_models(ui: UI, limit: int = 100, free_only: bool = False) -> None:
    models = fetch_openrouter_models()
    models.sort(key=lambda item: str(item.get("id") or ""))
    if free_only:
        models = [item for item in models if _is_free_model(item)]
    shown = models[: max(1, limit)]
    rows = []
    for item in shown:
        pricing = item.get("pricing") if isinstance(item.get("pricing"), dict) else {}
        rows.append(
            (
                str(item.get("id") or "?"),
                _format_context(item.get("context_length")),
                _per_million(pricing.get("prompt")),
                _per_million(pricing.get("completion")),
            )
        )
    label = "ucretsiz " if free_only else ""
    ui.table(["Model", "Baglam", "$/M giris", "$/M cikis"], rows)
    ui.info(
        f"{len(shown)} {label}model gosteriliyor (toplam {len(models)}). "
        "Kullanmak icin: -m openrouter/<model>"
    )


def _show_help(ui: UI) -> None:
    rows = [
        ("/model [ad]", "Model degistir (ornek: /model or-claude)"),
        ("/model local", "Model klasorindeki GGUF dosyalarindan sec"),
        ("/model indir [no|URL]", "HuggingFace'den GGUF modeli indir"),
        ("/models", "Hazir model kisayollarini listele"),
        ("/models remote", "OpenRouter canli model listesini getir"),
        ("/models free", "OpenRouter ucretsiz modelleri listele"),
        ("/api", "API anahtarlarini goruntule"),
        ("/api <saglayici>", "Anahtar ekle/sil (ornek: /api openai)"),
        ("/api <saglayici> <anahtar>", "Anahtari dogrudan kaydet"),
        ("/menu", "Etkilesimli komut menusu"),
        ("/new, /clear", "Konusmayi temizle ve yeni oturum baslat"),
        ("/cd <dizin>", "Calisma dizinini degistir"),
        ("/pwd", "Calisma dizinini goster"),
        ("/yolo", "Tum islemleri otomatik onayla"),
        ("/ask", "Islemler icin onay iste (varsayilan)"),
        ("/readonly", "Yalnizca okuma modu"),
        ("/reasoning on|off", "Dusunme akisini goster/gizle"),
        ("/usage", "Token ve maliyet ozeti"),
        ("/keys", "API anahtari durumu"),
        ("/config", "Etkin ayarlar"),
        ("/voice on|off", "AI yanitlarini sesli oku (OpenRouter TTS)"),
        ("/voice voice <ad>", "Ses degistir (gareth, nadine, tabitha, bram, ...)"),
        ("/boost on|off", "Promptu once upgrade modeline yeniden yazdir"),
        ("/boost model [ad]", "Upgrade modelini sec veya degistir"),
        ("/preview on|off", "Islemlerin aktigi yan panel/canli akis"),
        ("/preview log", "Olay kuyruk dosyasini goster (tail -f icin)"),
        ("/session", "Oturum dosyasi bilgisi"),
        ("/sessions", "Bu dizindeki son oturumlar"),
        ("/quit", "Cikis"),
        ("!komut", "Kabuk komutunu dogrudan calistir"),
        ("@dosya", "Mesaja dosya icerigi ekle"),
    ]
    ui.table(["Komut", "Aciklama"], rows)


MENU_ITEMS = [
    ("1", "/model", "Model degistir"),
    ("2", "/api", "API anahtari ekle/sil"),
    ("3", "/models free", "Ucretsiz modeller"),
    ("4", "/keys", "Anahtar durumu"),
    ("5", "/usage", "Token kullanimi"),
    ("6", "/config", "Ayarlar"),
    ("7", "/sessions", "Oturumlar"),
    ("8", "/voice", "Sesli yanit ac/kapat"),
    ("9", "/boost", "Prompt upgrade ac/kapat"),
    ("10", "/preview", "Canli islem paneli ac/kapat"),
    ("11", "/help", "Tum komutlar"),
    ("12", "/quit", "Cikis"),
]


def _show_menu(runtime: Runtime) -> None:
    ui = runtime.ui
    alias = _alias_for_model(runtime.provider_name, runtime.model)
    label = alias or _model_label(runtime.provider_name, runtime.model)
    ui.info(f"Aktif model: {label}")
    rows = [(num, cmd, desc) for num, cmd, desc in MENU_ITEMS]
    ui.table(["No", "Komut", "Aciklama"], rows)
    answer = ui.ask_line("Secim (numara/komut, bos birak iptal): ")
    if not answer:
        return None
    chosen = None
    if answer.isdigit():
        for num, cmd, _desc in MENU_ITEMS:
            if num == answer:
                chosen = cmd
                break
    else:
        chosen = answer if answer.startswith("/") else f"/{answer}"
    if chosen:
        _handle_slash(runtime, chosen)
    return None


def _expand_file_refs(
    text: str, cwd: Path, *, per_file: int = 20_000, total: int = 60_000
) -> str:
    if "@" not in text:
        return text
    seen: set[str] = set()
    blocks: list[str] = []
    used = 0
    for match in FILE_REF.finditer(text):
        raw = match.group(1).strip("'\"`.,;:)]}")
        if not raw or raw in seen:
            continue
        seen.add(raw)
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = cwd / path
        try:
            path = path.resolve()
            if not path.is_file():
                continue
            with path.open("rb") as handle:
                head = handle.read(4096)
            if b"\x00" in head:
                blocks.append(f'<file path="{html.escape(raw)}" skipped="binary"/>')
                continue
            data = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        truncated = False
        if len(data) > per_file:
            data = data[:per_file]
            truncated = True
        remaining = total - used
        if remaining <= 0:
            blocks.append("<attachments_truncated/>")
            break
        if len(data) > remaining:
            data = data[:remaining]
            truncated = True
        used += len(data)
        flag = ' truncated="true"' if truncated else ""
        blocks.append(
            f'<file path="{html.escape(raw)}"{flag}>\n{data}\n</file>'
        )
        if used >= total:
            break
    if not blocks:
        return text
    return text + "\n\n<attached_files>\n" + "\n".join(blocks) + "\n</attached_files>"


def _run_bang(runtime: Runtime, command: str) -> None:
    if not command:
        runtime.ui.warn("Bos komut.")
        return
    result = run_command(
        command,
        runtime.agent.ctx.cwd,
        timeout=120,
        output_limit=runtime.config.tool_output_limit,
    )
    runtime.ui.print(Text(result.content))
    if result.is_error:
        runtime.ui.warn(result.summary)


def _speak_turn(runtime: Runtime, text: str) -> None:
    """AI'in son mesajini seslendir (yalnizca /voice acikken)."""
    ui = runtime.ui
    if not runtime.config.voice_enabled or not text.strip():
        return
    key = runtime.config.api_key("openrouter")
    if not key:
        ui.warn("Ses acik ama OpenRouter anahtari yok. /api openrouter ile ekle.")
        runtime.config.voice_enabled = False
        runtime.config.save()
        return
    try:
        preview.publish("tts", f"GET {TTS_URL} (voice={runtime.config.voice_name})", ui)
        path = synthesize(key, text, voice=runtime.config.voice_name)
    except ProviderError as exc:
        ui.warn(f"Seslendirme baarisiz: {exc}")
        return
    preview.publish("tts", f"okundu {path.name}", ui)
    if not play(path):
        ui.info(f"Ses dosyasi hazir (oynatici bulunamadi): {path}")


def _handle_voice(runtime: Runtime, argument: str) -> None:
    ui = runtime.ui
    config = runtime.config
    arg = argument.strip().lower()
    if arg in ("on", "acik", "ac", "true", "1"):
        if not config.api_key("openrouter"):
            ui.warn("Once OpenRouter anahtarini ekle: /api openrouter")
            return
        config.voice_enabled = True
        config.save()
        ui.info(f"Sesli yanit acik (ses: {config.voice_name}).")
        return
    if arg in ("off", "kapali", "kapat", "false", "0"):
        config.voice_enabled = False
        config.save()
        ui.info("Sesli yanit kapali.")
        return
    if arg.startswith("voice "):
        name = arg[len("voice ") :].strip()
        if name in TTS_VOICES:
            config.voice_name = name
            config.save()
            ui.info(f"Ses: {name}")
        else:
            ui.info(f"Gecerli sesler: {', '.join(TTS_VOICES)}")
        return
    if arg in ("test", "dene"):
        _speak_turn(runtime, "Merhaba, Banana Coder sesli yanit hazir.")
        return
    state = "acik" if config.voice_enabled else "kapali"
    ui.info(
        f"Sesli yanit: {state}  |  ses: {config.voice_name}  |  model: {TTS_MODEL}\n"
        "Kullan: /voice on | /voice off | /voice voice <ad> | /voice test\n"
        f"Sesler: {', '.join(TTS_VOICES)}"
    )


def _handle_boost(runtime: Runtime, argument: str) -> None:
    from banana.booster import BOOST_MODEL_CHOICES, boost_available

    ui = runtime.ui
    config = runtime.config
    parts = argument.strip().lower().split(maxsplit=1)
    arg = parts[0] if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""
    if arg in ("on", "acik", "ac", "true", "1"):
        config.boost_enabled = True
        config.save()
        if boost_available(config):
            ui.info(f"Prompt upgrade acik (model: {config.boost_model}).")
        else:
            ui.warn(
                f"Prompt upgrade acik ama upgrade modeli hazir degil: {config.boost_model}. "
                "Anahtar eksikse prompt oldugu gibi gonderilir. Modeli degistirmek icin: /boost model"
            )
        return
    if arg in ("off", "kapali", "kapat", "false", "0"):
        config.boost_enabled = False
        config.save()
        ui.info("Prompt upgrade kapali.")
        return
    if arg == "model":
        if not rest:
            choices = [
                f"{key} -> {MODEL_PRESETS[key]}" for key in BOOST_MODEL_CHOICES
            ]
            answer = ui.ask_choice(
                "Promptu upgrade edecek modeli sec:", choices
            )
            if not answer:
                return None
            index = choices.index(answer) if answer in choices else None
            if index is None:
                return None
            rest = BOOST_MODEL_CHOICES[index]
        try:
            provider_name, _model = parse_model(rest)
        except ValueError as exc:
            ui.error(str(exc))
            return
        if provider_name != "local" and not config.api_key(provider_name):
            try:
                create_provider(config, provider_name)
            except ProviderError as exc:
                ui.error(f"Upgrade modeli icin anahtar gerekli: {exc}")
                return
        config.boost_model = rest
        config.save()
        ui.info(f"Upgrade modeli: {rest}")
        return
    state = "acik" if config.boost_enabled else "kapali"
    ui.info(
        f"Prompt upgrade: {state}  |  model: {config.boost_model}\n"
        "Kullan: /boost on | /boost off | /boost model <ad> | /boost model\n"
        f"Onerilen modeller: {', '.join(BOOST_MODEL_CHOICES)}"
    )


def _handle_preview(runtime: Runtime, argument: str) -> None:
    ui = runtime.ui
    config = runtime.config
    parts = argument.strip().lower().split(maxsplit=1)
    arg = parts[0] if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""

    if arg in ("on", "acik", "ac", "true", "1"):
        config.preview_enabled = True
        config.save()
        preview.init(
            config.config_path,
            enabled=True,
            pane_percent=config.preview_pane_percent,
        )
        if preview.attach_pane():
            ui.info(
                "Canli islem paneli acik: tmux bölmesi baglandi, olaylar yan panelde akacak."
            )
        else:
            ui.info(
                "Canli islem paneli acik (tmux bulunamadl): islemler akista 'PV' satiri olarak gorunur.\n"
                f"Kuyruk dosyasi: {preview.path()}\n"
                "Ayri terminalde izlemek icin: tail -f "
                + str(preview.path())
            )
        return
    if arg in ("off", "kapali", "kapat", "false", "0"):
        config.preview_enabled = False
        config.save()
        preview.detach_pane()
        preview.init(config.config_path, enabled=False)
        ui.info("Canli islem paneli kapali.")
        return
    if arg == "height":
        if not rest.isdigit():
            ui.info("Kullan: /preview height <20-70> (tmux bolme genisligi)")
            return
        config.preview_pane_percent = max(20, min(70, int(rest)))
        config.save()
        preview.init(
            config.config_path,
            enabled=config.preview_enabled,
            pane_percent=config.preview_pane_percent,
        )
        ui.info(f"Panel genisligi: %{config.preview_pane_percent} (tmux bolmesi icin)")
        return
    if arg in ("log", "dosya", "tail"):
        target = preview.path()
        if rest in ("ac", "open"):
            if target is not None and sys.platform == "darwin":
                subprocess.run(["open", "-R", str(target)], check=False)
            else:
                ui.info(f"Log dosyasi: {target}")
            return
        if rest in ("temizle", "clear"):
            preview.clear()
            ui.info("Kuyruk dosyasi temizlendi.")
            return
        ui.info(
            f"Kuyruk dosyasi: {target}\n"
            "Ayri terminalde canli izlemek icin: tail -f " + str(target) + "\n"
            "Log: /preview log ac | Temizle: /preview log temizle"
        )
        return

    state = "acik" if config.preview_enabled else "kapali"
    mode = (
        "tmux bolmesi"
        if preview.tmux_attached()
        else ("canli akis satirlari" if config.preview_enabled else "-")
    )
    ui.info(
        f"Canli islem paneli: {state}  |  yontem: {mode}  |  tmux: "
        + ("var" if preview.tmux_available() else "yok")
        + f"\nKuyruk: {preview.path()}\n"
        "Kullan: /preview on | /preview off | /preview height <20-70> | /preview log\n"
        "Panelde araclar, komutlar, GET url'leri, indirmeler, boost ve onaylar gorunur."
    )
    if config.preview_enabled:
        recent = preview.recent(8)
        if recent:
            for line in recent:
                ui.info(line)


def _handle_slash(runtime: Runtime, line: str) -> str | None:
    parts = line.split(maxsplit=1)
    command = parts[0].lower()
    argument = parts[1].strip() if len(parts) > 1 else ""
    ui = runtime.ui

    if command in ("/quit", "/exit"):
        return "quit"
    if command == "/help":
        _show_help(ui)
        return None
    if command in ("/voice", "/tts", "/ses"):
        _handle_voice(runtime, argument)
        return None
    if command == "/boost":
        _handle_boost(runtime, argument)
        return None
    if command in ("/preview", "/panel"):
        _handle_preview(runtime, argument)
        return None
    if command == "/model":
        low = argument.lower()
        if low.startswith(("indir", "download", "dl")):
            _model_download_flow(runtime, argument.split(maxsplit=1)[1] if " " in argument else "")
            return None
        if argument.startswith("http"):
            _model_download_flow(runtime, argument)
            return None
        if argument.lower() in ("local", "gguf", "yerel"):
            ggufs = _find_gguf_files()
            if not ggufs:
                ui.info(
                    "Model klasorlerinde .gguf bulunamadi.\n"
                    f"GGUF dosyalarini su klasore koy: {LOCAL_MODELS_DIR}\n"
                    "Ya da haziindan model indir: /model indir\n"
                    "Dosya yolunu dogrudan da verebilirsin: /model local/<model.gguf>"
                )
                return None
            choices = [
                f"{path.name} ({_format_size(path)}) -> local/{path}" for path in ggufs
            ]
            answer = ui.ask_choice("Hangi yerel GGUF modeli kullanmak istiyorsun?", choices)
            if not answer:
                return None
            index = choices.index(answer) if answer in choices else None
            if index is None:
                return None
            argument = f"local/{ggufs[index]}"
        elif not argument:
            current = _model_label(runtime.provider_name, runtime.model)
            alias = _alias_for_model(runtime.provider_name, runtime.model)
            if alias:
                current = f"{current} (kisayol: {alias})"
            ui.info(f"Etkin model: {current}")
            choices = _model_choices()
            answer = ui.ask_choice("Hangi modeli kullanmak istiyorsun?", [c[0] for c in choices])
            if not answer:
                return None
            index = next((i for i, c in enumerate(choices) if c[0] == answer), None)
            if index is None:
                return None
            argument = choices[index][1]
        elif argument.isdigit():
            choices = _model_choices()
            index = int(argument) - 1
            if 0 <= index < len(choices):
                argument = choices[index][1]
        try:
            _switch_model(runtime, argument)
        except MissingKeyError as exc:
            provider_name, model = parse_model(argument, runtime.provider_name)
            if ui.interactive and _prompt_api_key(runtime.config, ui, provider_name):
                try:
                    _switch_model(runtime, argument)
                except ProviderError as exc2:
                    ui.error(str(exc2))
                    return None
            else:
                ui.error(str(exc))
                return None
        except ProviderError as exc:
            ui.error(str(exc))
            return None
        ui.info(
            f"Model degistirildi: {_model_label(runtime.provider_name, runtime.model)}"
        )
        return None
    if command == "/models":
        arg = argument.lower()
        if arg in ("remote", "uzak"):
            try:
                _show_remote_models(ui)
            except ProviderError as exc:
                ui.error(str(exc))
            return None
        if arg in ("free", "ucretsiz"):
            try:
                _show_remote_models(ui, free_only=True)
            except ProviderError as exc:
                ui.error(str(exc))
            return None
        _show_presets(ui)
        return None
    if command in ("/new", "/clear"):
        runtime.session.clear()
        ui.info(f"Yeni oturum: {runtime.session.path.name}")
        return None
    if command == "/cd":
        if not argument:
            ui.info(str(runtime.agent.ctx.cwd))
            return None
        path = Path(argument).expanduser()
        if not path.is_absolute():
            path = runtime.agent.ctx.cwd / path
        try:
            path = path.resolve()
        except OSError as exc:
            ui.error(f"Yol cozumlenemedi: {exc}")
            return None
        if not path.is_dir():
            ui.error(f"Dizin bulunamadi: {path}")
            return None
        os.chdir(path)
        runtime.agent.set_cwd(path)
        runtime.session.cwd = path
        if runtime.persist:
            runtime.session.save()
        ui.info(f"Calisma dizini: {path}")
        return None
    if command == "/pwd":
        ui.info(str(runtime.agent.ctx.cwd))
        return None
    if command in ("/yolo", "/ask", "/readonly"):
        mode = {"/yolo": "yolo", "/ask": "ask", "/readonly": "readonly"}[command]
        runtime.approver.set_mode(mode)
        runtime.config.approval = mode
        ui.info(f"Izin modu: {mode}")
        return None
    if command == "/reasoning":
        if argument.lower() in ("on", "ac", "aç"):
            ui.show_reasoning = True
        elif argument.lower() in ("off", "kapat"):
            ui.show_reasoning = False
        ui.info(f"Reasoning gosterimi: {'acik' if ui.show_reasoning else 'kapali'}")
        return None
    if command == "/usage":
        usage = runtime.session.usage
        rows = [
            ("Giris token", str(usage.input_tokens)),
            ("Cikis token", str(usage.output_tokens)),
            ("Cache okuma", str(usage.cache_read_tokens)),
            ("Cache yazma", str(usage.cache_write_tokens)),
            ("Maliyet", f"${usage.cost:.4f}" if usage.cost is not None else "-"),
            ("Mesaj", str(len(runtime.session.messages))),
        ]
        ui.table(["Metrik", "Deger"], rows)
        return None
    if command == "/menu":
        _show_menu(runtime)
        return None
    if command == "/api":
        if not argument:
            rows = []
            for provider in PROVIDERS:
                key = runtime.config.api_key(provider)
                rows.append(
                    (
                        PROVIDER_LABELS[provider],
                        _key_source(runtime.config, provider),
                        "hazir" if key else "yok",
                        mask_key(key),
                    )
                )
            ui.table(["Saglayici", "Kaynak", "Durum", "Anahtar"], rows)
            return None
        parts = argument.split(maxsplit=1)
        provider = parts[0].lower()
        if provider not in PROVIDERS:
            ui.error(f"Bilinmeyen saglayici: {provider}")
            return None
        key_arg = parts[1].strip() if len(parts) > 1 else ""
        if key_arg.lower() in ("clear", "sil", "delete"):
            runtime.config.set_api_key(provider, "")
            runtime.config.save()
            ui.info(f"{PROVIDER_LABELS[provider]} anahtari silindi.")
            return None
        if key_arg:
            runtime.config.set_api_key(provider, key_arg)
            runtime.config.save()
            ui.info(f"{PROVIDER_LABELS[provider]} anahtari kaydedildi.")
            return None
        if _prompt_api_key(runtime.config, ui, provider):
            try:
                runtime.provider = create_provider(
                    runtime.config, runtime.provider_name
                )
                runtime.agent.provider = runtime.provider
            except ProviderError as exc:
                ui.error(str(exc))
        return None
    if command == "/keys":
        rows = []
        for provider in PROVIDERS:
            key = runtime.config.api_key(provider)
            env_names = " / ".join(KEY_ENV[provider])
            rows.append(
                (
                    PROVIDER_LABELS[provider],
                    env_names,
                    _key_source(runtime.config, provider),
                    "hazir" if key else "yok",
                    mask_key(key),
                )
            )
        ui.table(
            ["Saglayici", "Ortam degiskeni", "Kaynak", "Durum", "Anahtar"], rows
        )
        return None
    if command == "/config":
        rows = [
            ("Model", _model_label(runtime.provider_name, runtime.model)),
            ("Izin modu", runtime.approver.mode),
            ("Max tokens", str(runtime.config.max_tokens)),
            ("Temperature", str(runtime.config.temperature)),
            ("Baglam siniri", f"{runtime.config.max_context_chars} karakter"),
            ("Istek zaman asimi", f"{runtime.config.request_timeout:.0f}s"),
            ("Arac cikti limiti", str(runtime.config.tool_output_limit)),
            ("Max arac turu", str(runtime.config.max_tool_rounds)),
            ("Sesli yanit", "acik" if runtime.config.voice_enabled else "kapali"),
            ("Prompt upgrade", f"{'acik' if runtime.config.boost_enabled else 'kapali'} ({runtime.config.boost_model})"),
            ("Canli panel", "acik" if runtime.config.preview_enabled else "kapali"),
            ("Ayar dosyasi", str(runtime.config.config_path)),
        ]
        ui.table(["Ayar", "Deger"], rows)
        return None
    if command == "/session":
        rows = [
            ("Dosya", str(runtime.session.path)),
            ("Olusturuldu", runtime.session.created_at),
            ("Guncellendi", runtime.session.updated_at),
            ("Mesaj", str(len(runtime.session.messages))),
            ("Kalici", "evet" if runtime.persist else "hayir"),
        ]
        ui.table(["Alan", "Deger"], rows)
        return None
    if command == "/sessions":
        sessions = Session.recent(runtime.agent.ctx.cwd, 10)
        if not sessions:
            ui.info("Kayitli oturum yok.")
            return None
        rows = [
            (
                item.updated_at[:19].replace("T", " "),
                str(len(item.messages)),
                item.model or "-",
                item.path.stem,
            )
            for item in sessions
        ]
        ui.table(["Guncellendi", "Mesaj", "Model", "Oturum"], rows)
        ui.info("Devam etmek icin: banana --continue veya banana --session <oturum>")
        return None
    ui.warn(f"Bilinmeyen komut: {command}. /help yazabilirsin.")
    return None


SLASH_COMMANDS = [
    "/api",
    "/ask",
    "/boost",
    "/cd",
    "/clear",
    "/config",
    "/help",
    "/keys",
    "/model",
    "/models",
    "/new",
    "/preview",
    "/pwd",
    "/quit",
    "/readonly",
    "/reasoning",
    "/session",
    "/sessions",
    "/usage",
    "/voice",
    "/yolo",
]


def _setup_readline():
    try:
        import readline
    except ImportError:
        return None
    try:
        APP_HOME.mkdir(parents=True, exist_ok=True)
        readline.read_history_file(str(APP_HOME / "history"))
    except OSError:
        pass
    readline.set_history_length(2000)

    def completer(text: str, state: int) -> str | None:
        if not text.startswith("/"):
            return None
        matches = [cmd for cmd in SLASH_COMMANDS if cmd.startswith(text)]
        if state < len(matches):
            return matches[state]
        return None

    readline.set_completer(completer)
    readline.parse_and_bind("tab: complete")
    return readline


def _save_readline(readline_module) -> None:
    if readline_module is None:
        return
    try:
        APP_HOME.mkdir(parents=True, exist_ok=True)
        readline_module.write_history_file(str(APP_HOME / "history"))
    except OSError:
        pass


def _run_repl(runtime: Runtime, session_note: str) -> int:
    ui = runtime.ui
    ui.banner(
        __version__,
        _model_label(runtime.provider_name, runtime.model),
        PROVIDER_LABELS[runtime.provider_name],
        str(runtime.agent.ctx.cwd),
        runtime.approver.mode,
        session_note,
    )
    readline_module = _setup_readline()
    try:
        while True:
            try:
                line = ui.prompt(_prompt_text(runtime))
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print()
                continue

            line = line.strip()
            if not line:
                continue
            if line in ("exit", "quit"):
                break
            if line.startswith("!"):
                _run_bang(runtime, line[1:].strip())
                continue
            if line.startswith("/"):
                if _handle_slash(runtime, line) == "quit":
                    break
                continue

            prompt = _expand_file_refs(line, runtime.agent.ctx.cwd)
            try:
                result = runtime.agent.run_turn(prompt)
            except KeyboardInterrupt:
                ui.warn("Durduruldu.")
                continue
            except ProviderError as exc:
                ui.error(str(exc))
                ui.info(
                    f"Aktif model: {_model_label(runtime.provider_name, runtime.model)}"
                )
                if exc.status_code == 429:
                    ui.info("Baska bir model dene: /model veya /models free")
                continue
            except Exception as exc:
                ui.error(f"Beklenmeyen hata: {type(exc).__name__}: {exc}")
                ui.info(
                    f"Aktif model: {_model_label(runtime.provider_name, runtime.model)}"
                )
                continue
            if not result.text and result.tool_rounds == 0:
                ui.info("(model bos yanit dondurdu)")
            _speak_turn(runtime, result.text)
    finally:
        _save_readline(readline_module)
        if runtime.persist and runtime.session.messages:
            runtime.session.save()
    return 0


def _run_one_shot(runtime: Runtime, prompt: str, as_json: bool) -> int:
    expanded = _expand_file_refs(prompt, runtime.agent.ctx.cwd)
    try:
        result = runtime.agent.run_turn(expanded)
    except KeyboardInterrupt:
        runtime.ui.warn("Durduruldu.")
        return 130
    except ProviderError as exc:
        runtime.ui.error(str(exc))
        runtime.ui.info(
            f"Aktif model: {_model_label(runtime.provider_name, runtime.model)}"
        )
        if exc.status_code == 429:
            runtime.ui.info("Baska bir model dene: /model veya /models free")
        return 1
    except Exception as exc:
        runtime.ui.error(f"Beklenmeyen hata: {type(exc).__name__}: {exc}")
        runtime.ui.info(
            f"Aktif model: {_model_label(runtime.provider_name, runtime.model)}"
        )
        return 1
    runtime.ui.finish_output()
    if as_json:
        payload = {
            "text": result.text,
            "provider": runtime.provider_name,
            "model": runtime.model,
            "usage": result.usage.to_dict(),
            "elapsed": round(result.elapsed, 3),
            "stop_reason": result.stop_reason,
            "tool_rounds": result.tool_rounds,
        }
        print(json.dumps(payload, ensure_ascii=False))
    else:
        _speak_turn(runtime, result.text)
    return 0


def _cmd_test(config: Config, args: argparse.Namespace, color: bool) -> int:
    console = Console(no_color=not color, highlight=False, emoji=False)
    ui = UI(color=color)
    requested = [item.lower() for item in args.providers]
    invalid = [item for item in requested if item not in PROVIDERS]
    if invalid:
        ui.error(f"Gecersiz saglayici: {', '.join(invalid)}")
        return 2
    providers = requested or config.available_providers()
    if not providers:
        _print_setup_help(ui)
        return 1

    rows = []
    failures = 0
    configured_model: tuple[str, str] | None = None
    if config.model:
        try:
            configured_model = parse_model(config.model)
        except ValueError:
            configured_model = None
    for provider in providers:
        model = (
            configured_model[1]
            if configured_model and configured_model[0] == provider
            else DEFAULT_MODELS[provider]
        )
        if not config.api_key(provider):
            rows.append((PROVIDER_LABELS[provider], model, "ANAHTAR YOK", "-", "-"))
            failures += 1
            continue
        client = None
        try:
            client = create_provider(config, provider)
            started = time.monotonic()
            message, usage, _stop, used_model = client.complete(
                model=model,
                system="You are a connectivity test. Keep the answer extremely short.",
                messages=[Message(role="user", content="Reply with exactly: OK")],
                tools=[],
                max_tokens=512,
            )
            elapsed = time.monotonic() - started
            text = " ".join((message.content or "(bos)").split())[:80]
            rows.append(
                (
                    PROVIDER_LABELS[provider],
                    used_model or model,
                    "CALISIYOR",
                    f"{elapsed:.2f}s",
                    f"{text} [{usage.input_tokens}/{usage.output_tokens}]",
                )
            )
        except ProviderError as exc:
            failures += 1
            rows.append(
                (
                    PROVIDER_LABELS[provider],
                    model,
                    "BASARISIZ",
                    "-",
                    str(exc).splitlines()[0][:100],
                )
            )
        finally:
            if client is not None:
                client.close()
    ui.table(["Saglayici", "Model", "Durum", "Sure", "Yanit"], rows)
    console.print()
    if failures:
        ui.error(f"{failures} saglayici basarisiz.")
        return 1
    ui.info(f"{len(rows)} saglayici basariyla test edildi.")
    return 0


def _cmd_models(args: argparse.Namespace, color: bool) -> int:
    ui = UI(color=color)
    if not args.remote and not args.free:
        _show_presets(ui)
        return 0
    try:
        _show_remote_models(ui, args.limit, free_only=args.free)
    except ProviderError as exc:
        ui.error(str(exc))
        return 1
    return 0


def _cmd_config(config: Config, args: argparse.Namespace, color: bool) -> int:
    ui = UI(color=color)
    if args.init:
        if CONFIG_PATH.exists() and not args.force:
            ui.warn(
                f"Ayar dosyasi zaten var: {CONFIG_PATH}. Uzerine yazmak icin --force kullan."
            )
            return 0
        Config(config_path=CONFIG_PATH).save()
        ui.info(f"Ayar dosyasi olusturuldu: {CONFIG_PATH}")
        return 0

    rows = [
        ("Ayar dosyasi", str(CONFIG_PATH)),
        ("Oturum dizini", str(SESSIONS_DIR)),
        ("Varsayilan model", config.model or "(otomatik)"),
        ("Izin modu", config.approval),
        ("Max tokens", str(config.max_tokens)),
        ("Temperature", str(config.temperature)),
        ("Baglam siniri", f"{config.max_context_chars} karakter"),
        ("Istek zaman asimi", f"{config.request_timeout:.0f}s"),
        ("Max arac turu", str(config.max_tool_rounds)),
        ("Reasoning", "acik" if config.show_reasoning else "kapali"),
    ]
    ui.table(["Ayar", "Deger"], rows)
    key_rows = []
    for provider in PROVIDERS:
        key = config.api_key(provider)
        key_rows.append(
            (
                PROVIDER_LABELS[provider],
                " / ".join(KEY_ENV[provider]),
                "hazir" if key else "yok",
                mask_key(key),
                config.base_url(provider),
            )
        )
    ui.table(["Saglayici", "Ortam degiskeni", "Durum", "Anahtar", "Base URL"], key_rows)
    return 0


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.json and not args.prompt:
        parser.error("--json yalnizca -p/--prompt ile kullanilabilir.")

    workdir = Path(args.workdir or os.getcwd()).expanduser()
    if not workdir.exists() or not workdir.is_dir():
        print(f"HATA: Calisma dizini bulunamadi: {workdir}", file=sys.stderr)
        raise SystemExit(2)
    workdir = workdir.resolve()
    os.chdir(workdir)
    bootstrap_env(workdir)
    config = Config.load()
    _apply_overrides(config, args)
    color = _color_enabled(args.no_color)

    if args.command == "test":
        raise SystemExit(_cmd_test(config, args, color))
    if args.command == "models":
        raise SystemExit(_cmd_models(args, color))
    if args.command == "config":
        raise SystemExit(_cmd_config(config, args, color))

    one_shot = args.prompt is not None
    ui = UI(
        color=color,
        show_reasoning=config.show_reasoning,
        one_shot=one_shot,
        stream_output=not (one_shot and args.json),
    )
    config.ensure_dirs()

    if one_shot:
        os.environ["BANANA_ONE_SHOT"] = "1"
    preview.init(
        config.config_path,
        enabled=config.preview_enabled,
        pane_percent=config.preview_pane_percent,
    )
    if config.preview_enabled and not one_shot:
        preview.attach_pane()

    session, started_new = _build_session(args, workdir)

    if not args.model and not (session.provider in PROVIDERS and session.model):
        if not config.model:
            if ui.interactive:
                if not _prompt_default_model(config, ui):
                    ui.warn("Model secilmedi; cikiliyor.")
                    raise SystemExit(1)
            else:
                _print_setup_help(ui)
                raise SystemExit(1)

    try:
        provider_name, model = _resolve_target(args, config, session)
    except MissingKeyError:
        _print_setup_help(ui)
        raise SystemExit(1)
    except (ValueError, ProviderError) as exc:
        ui.error(str(exc))
        raise SystemExit(1)

    if provider_name == "local":
        try:
            path = local_model_path(config, model)
            provider = create_provider(config, "local", model=path)
        except ProviderError as exc:
            ui.error(str(exc))
            raise SystemExit(1)
        model = Path(provider.model_path).name
        config.local_model_path = str(provider.model_path)
        config.save()
    else:
        if not config.api_key(provider_name):
            if ui.interactive:
                if not _prompt_api_key(config, ui, provider_name):
                    ui.warn("API anahtari girilmedi; cikiliyor.")
                    raise SystemExit(1)
            else:
                try:
                    create_provider(config, provider_name)
                except MissingKeyError as exc:
                    ui.error(str(exc))
                    _print_setup_help(ui)
                    raise SystemExit(1)

        try:
            provider = create_provider(config, provider_name)
        except MissingKeyError as exc:
            ui.error(str(exc))
            _print_setup_help(ui)
            raise SystemExit(1)
        except ProviderError as exc:
            ui.error(str(exc))
            raise SystemExit(1)

    session.cwd = workdir
    session.provider = provider_name
    session.model = model
    persist = (not one_shot) or bool(args.session or args.continue_)
    approver = Approver(ui, config.approval)
    agent = Agent(
        provider=provider,
        provider_name=provider_name,
        model=model,
        config=config,
        ui=ui,
        approver=approver,
        session=session,
        cwd=workdir,
        persist=persist,
    )
    runtime = Runtime(
        config=config,
        ui=ui,
        approver=approver,
        session=session,
        provider=provider,
        provider_name=provider_name,
        model=model,
        agent=agent,
        persist=persist,
    )

    if one_shot:
        if args.continue_ and not session.messages and not started_new:
            ui.info("Devam edilecek oturum bulunamadi; yeni oturum baslatildi.")
        try:
            code = _run_one_shot(runtime, args.prompt or "", args.json)
        finally:
            if runtime.persist and runtime.session.messages:
                runtime.session.save()
            provider.close()
        raise SystemExit(code)

    if args.continue_ and started_new:
        ui.info("Devam edilecek oturum bulunamadi; yeni oturum baslatildi.")
    if session.messages:
        note = f"Oturum: {session.path.name} · {len(session.messages)} mesaj"
    else:
        note = f"Yeni oturum: {session.path.name}"
    try:
        code = _run_repl(runtime, note)
    finally:
        provider.close()
    raise SystemExit(code)
