from __future__ import annotations

import io
import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("BANANA_HOME", tempfile.mkdtemp(prefix="banana-test-home-"))

from rich.console import Console

from banana.agent import Agent, trim_messages
from banana.approval import Approver
from banana.config import Config
from banana.models import Message
from banana.providers.anthropic import AnthropicProvider
from banana.providers.gemini import GeminiProvider
from banana.providers.openai_compat import OpenAIProvider
from banana.session import Session
from banana.ui import UI
from tests.mock_api import MockAPI

QUIET = dict(file=io.StringIO(), no_color=True, highlight=False, emoji=False)


class AgentLoopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.mock = MockAPI().start()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.mock.stop()

    def _provider(self, kind: str):
        base = f"http://127.0.0.1:{self.mock.port}"
        if kind == "openai":
            return OpenAIProvider("test-openai", base + "/v1"), "openai"
        if kind == "anthropic":
            return AnthropicProvider("test-anthropic", base), "anthropic"
        return GeminiProvider("test-gemini", base + "/v1beta"), "gemini"

    def test_agent_reads_file_and_answers_for_each_provider(self) -> None:
        for kind in ("openai", "anthropic", "gemini"):
            with self.subTest(provider=kind), tempfile.TemporaryDirectory() as raw:
                cwd = Path(raw)
                (cwd / "sample.txt").write_text(
                    "BANANA_FILE_CONTENT\n", encoding="utf-8"
                )
                provider, provider_name = self._provider(kind)
                ui = UI(color=False, one_shot=True, stream_output=False)
                ui.console = Console(**QUIET)
                ui.err_console = Console(**QUIET)
                approver = Approver(ui, "yolo")
                config = Config()
                session = Session.create(cwd, provider_name, "test-model")
                agent = Agent(
                    provider=provider,
                    provider_name=provider_name,
                    model="test-model",
                    config=config,
                    ui=ui,
                    approver=approver,
                    session=session,
                    cwd=cwd,
                    persist=False,
                )
                try:
                    result = agent.run_turn("sample.txt dosyasini oku")
                finally:
                    provider.close()

                self.assertEqual(result.tool_rounds, 1)
                self.assertIn("BANANA_FILE_CONTENT", result.text)
                self.assertGreater(result.usage.input_tokens, 0)
                roles = [message.role for message in session.messages]
                self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])
                tool_message = session.messages[2]
                self.assertEqual(tool_message.tool_name, "read_file")
                self.assertIn("BANANA_FILE_CONTENT", tool_message.content)
                self.assertFalse(tool_message.is_error)
                self.assertFalse(session.path.exists())


class ContextTrimTests(unittest.TestCase):
    def test_trimming_starts_at_a_user_message(self) -> None:
        old_user = Message(role="user", content="x" * 400)
        old_assistant = Message(
            role="assistant", content="y" * 400
        )
        new_user = Message(role="user", content="yeni soru")
        trimmed, did_trim = trim_messages(
            [old_user, old_assistant, new_user], 200
        )
        self.assertTrue(did_trim)
        self.assertEqual(trimmed[0].role, "user")
        self.assertEqual(trimmed[0].content, "yeni soru")

    def test_trimming_keeps_tool_pairs_consistent(self) -> None:
        messages = [
            Message(role="user", content="ilk " + "x" * 400),
            Message(role="assistant", content="", tool_calls=[]),
            Message(role="tool", content="sonuc", tool_call_id="call_1"),
            Message(role="user", content="ikinci"),
        ]
        trimmed, did_trim = trim_messages(messages, 120)
        self.assertTrue(did_trim)
        self.assertEqual(trimmed[0].role, "user")
        self.assertEqual(trimmed[0].content, "ikinci")


if __name__ == "__main__":
    unittest.main()
